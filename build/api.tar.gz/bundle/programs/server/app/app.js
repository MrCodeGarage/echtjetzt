var require = meteorInstall({"server":{"meteorMethods":{"general":{"index.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/meteorMethods/general/index.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var Future = require("fibers/future");
var needle = require("needle");
var moment = require("moment");
var collections_1 = require("../../collections");
var accounts_base_1 = require("meteor/accounts-base");
meteor_1.Meteor.methods({
    loginOverApp: function (access_token) {
        var fut = new Future();
        needle.get("https://www.googleapis.com/oauth2/v2/userinfo?access_token=" +
            access_token, meteor_1.Meteor.bindEnvironment(function (error, response) {
            if (error === null && response.statusCode == 200) {
                var email = response.body.email;
                var stampedLoginToken = accounts_base_1.Accounts["_generateStampedLoginToken"]();
                var posts = collections_1.Users.findOne({ "services.google.email": email });
                if (typeof posts === "undefined") {
                    fut.return({ err: true, data: null });
                }
                else {
                    accounts_base_1.Accounts["_insertLoginToken"](posts._id, stampedLoginToken);
                    fut.return({ err: false, data: stampedLoginToken });
                }
            }
            else {
                fut.return({ err: true, data: null });
            }
        }));
        return fut.wait();
    },
    changePasswordUser: function (password) {
        accounts_base_1.Accounts.setPassword(this.userId, password);
    },
    changeAccessToken: function () {
        var random = makeid(20);
        var user = collections_1.Users.findOne({ _id: this.userId });
        user.profile.apiToken = random;
        collections_1.Users.update({
            _id: this.userId
        }, {
            $set: user
        });
    },
    searchUser: function (filter) {
        var objA = {};
        if (filter !== "") {
            var and = filter.split(" ");
            var obj = {
                $and: []
            };
            for (var l = 0; l < and.length; l++) {
                var reg = new RegExp(".*" + and[l] + ".*", "i");
                obj["$and"].push({
                    $or: [
                        { "emails.address": reg },
                        { "profile.firstName": reg },
                        { "profile.lastName": reg }
                    ]
                });
            }
            objA = obj;
        }
        return collections_1.Users.find(objA, {
            fields: {
                profile: 1,
                emails: 1,
                _id: 1
            }
        }).cursor.fetch();
    }
});
function makeid(length) {
    var result = "";
    var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"office365":{"index.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/meteorMethods/office365/index.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var Future = require("fibers/future");
var needle = require("needle");
var moment = require("moment");
var office365_1 = require("/server/libModules/office365");
var index_1 = require("../../collections/index");
meteor_1.Meteor.methods({
    uploadtest: function (file) {
        if (!this.userId) {
            return;
        }
        var fut = new Future();
        office365_1.uploadDataToSpreadsheet("", "", "").then(function (data) {
            fut.return(data);
        });
        return fut.wait();
    },
    readDataFromSpreadSheet: function (file) {
        if (!this.userId) {
            return;
        }
        var fut = new Future();
        office365_1.readDataFromSpreadsheet("").then(function (data) {
            fut.return(data);
        });
        return fut.wait();
    },
    sendEmail: function (to, cc, subject, body) {
        if (!this.userId) {
            return;
        }
        var fut = new Future();
        office365_1.sendEmail(to, cc, subject, body).then(function () {
            fut.return();
        });
        return fut.wait();
    },
    createEvent: function (data) {
        if (!this.userId) {
            return;
        }
        var fut = new Future();
        index_1.Events.insert(data)
            .toPromise()
            .then(function () {
            fut.return();
        });
        return fut.wait();
    },
    getGroups: function () {
        if (!this.userId) {
            return;
        }
        var fut = new Future();
        office365_1.getGroupList().then(function (groupList) {
            fut.return(groupList);
        });
        return fut.wait();
    },
    startSyncGroupsUsers: function () {
        if (!this.userId) {
            return;
        }
        var fut = new Future();
        office365_1.syncUserAndGroups().then(function (groupList) {
            fut.return(groupList);
        });
        return fut.wait();
    },
    createEventAndInvite: function (title, description, start, end, email) {
        var fut = new Future();
        office365_1.createEvent(title, description, start, end, email).then(function (data) {
            fut.return(data);
        });
        return fut.wait();
    }
});
/*

"Test Home Office",
      "Test Asan",
      new Date(2019, 11, 4, 1, 0, 0, 0).toISOString(),
      new Date(2019, 11, 5, 1, 0, 0, 0).toISOString(),
      "asan.stefanski@advisori.de"

*/

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"teams":{"index.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/meteorMethods/teams/index.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var needle = require("needle");
var moment = require("moment");
var collections_1 = require("../../collections");
meteor_1.Meteor.methods({
    getTeams: function () {
        if (!this.userId) {
            return;
        }
        return collections_1.Teams.find({}).cursor.fetch();
    },
    updateMyTeam: function (id) {
        if (!this.userId) {
            return;
        }
        collections_1.Users.update({ _id: this.userId }, {
            $set: {
                myTeam: id
            }
        });
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"collections":{"index.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/collections/index.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
var meteor_1 = require("meteor/meteor");
var mongo_1 = require("meteor/mongo");
exports.Users = meteor_rxjs_1.MongoObservable.fromExisting(meteor_1.Meteor.users);
exports.mongoTeams = new mongo_1.Mongo.Collection("teams");
exports.Teams = new meteor_rxjs_1.MongoObservable.Collection(exports.mongoTeams);
exports.mongoEventTypes = new mongo_1.Mongo.Collection("eventtypes");
exports.EventTypes = new meteor_rxjs_1.MongoObservable.Collection(exports.mongoEventTypes);
exports.mongoChalanges = new mongo_1.Mongo.Collection("challange");
exports.Chalanges = new meteor_rxjs_1.MongoObservable.Collection(exports.mongoChalanges);
exports.mongoEvents = new mongo_1.Mongo.Collection("events");
exports.Events = new meteor_rxjs_1.MongoObservable.Collection(exports.mongoEvents);
exports.mongoSyncer = new mongo_1.Mongo.Collection("syncer");
exports.Syncer = new meteor_rxjs_1.MongoObservable.Collection(exports.mongoSyncer);
exports.Syncer.allow({
    insert: function (userId, doc) {
        if (!this.userId) {
            return;
        }
        return true;
    },
    update: function (userId, doc, fields, modifier) {
        if (!this.userId) {
            return;
        }
        return true;
    },
    remove: function (userId, doc) {
        if (!this.userId) {
            return;
        }
        return true;
    }
});
exports.Users.allow({
    insert: function (userId, doc) {
        if (!this.userId) {
            return;
        }
        return true;
    },
    update: function (userId, doc, fields, modifier) {
        if (!this.userId) {
            return;
        }
        return true;
    },
    remove: function (userId, doc) {
        if (!this.userId) {
            return;
        }
        return true;
    }
});
exports.Teams.allow({
    insert: function (userId, doc) {
        if (!this.userId) {
            return;
        }
        return true;
    },
    update: function (userId, doc, fields, modifier) {
        if (!this.userId) {
            return;
        }
        return true;
    },
    remove: function (userId, doc) {
        if (!this.userId) {
            return;
        }
        return true;
    }
});
exports.EventTypes.allow({
    insert: function (userId, doc) {
        if (!this.userId) {
            return;
        }
        return true;
    },
    update: function (userId, doc, fields, modifier) {
        if (!this.userId) {
            return;
        }
        return true;
    },
    remove: function (userId, doc) {
        if (!this.userId) {
            return;
        }
        return true;
    }
});
exports.Chalanges.allow({
    insert: function (userId, doc) {
        if (!this.userId) {
            return;
        }
        return true;
    },
    update: function (userId, doc, fields, modifier) {
        if (!this.userId) {
            return;
        }
        return true;
    },
    remove: function (userId, doc) {
        if (!this.userId) {
            return;
        }
        return true;
    }
});
exports.Events.allow({
    insert: function (userId, doc) {
        console.log(userId);
        if (!this.userId) {
            return;
        }
        console.log("juhu");
        return true;
    },
    update: function (userId, doc, fields, modifier) {
        if (!this.userId) {
            return;
        }
        return true;
    },
    remove: function (userId, doc) {
        if (!this.userId) {
            return;
        }
        return true;
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"libModules":{"datagridmongohelper.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/libModules/datagridmongohelper.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
function generateFilter(filter, defaultFilter) {
    var filt = {};
    if (typeof filter !== "undefined") {
        if (filter !== null) {
            if (filter.filters.length > 0) {
                if (filter.filters.length === 1) {
                    switch (filter.filters[0].operator) {
                        case "contains":
                            var vals = filter.filters[0].value.split(" ");
                            if (vals.length > 1) {
                                filt["$and"] = [];
                                for (var k = 0; k < vals.length; k++) {
                                    var obj = {};
                                    obj[filter.filters[0].field] = new RegExp(".*" + vals[k] + ".*", 'i');
                                    filt["$and"].push(obj);
                                }
                            }
                            else {
                                filt[filter.filters[0].field] = new RegExp(".*" + filter.filters[0].value + ".*", 'i');
                            }
                            break;
                        case "eq":
                            filt[filter.filters[0].field] = filter.filters[0].value;
                            break;
                        //.....
                    }
                }
                else {
                    filt["$and"] = [];
                    for (var j = 0; j < filter.filters.length; j++) {
                        switch (filter.filters[j].operator) {
                            case "contains":
                                var vals = filter.filters[j].value.split(" ");
                                for (var k = 0; k < vals.length; k++) {
                                    var obj = {};
                                    obj[filter.filters[j].field] = new RegExp(".*" + vals[k] + ".*", 'i');
                                    filt["$and"].push(obj);
                                }
                                break;
                            case "eq":
                                filt[filter.filters[j].field] = filter.filters[j].value;
                                break;
                            //.....
                        }
                    }
                }
            }
        }
    }
    if (defaultFilter !== null) {
        return defaultFilter;
    }
    else {
        return filt;
    }
}
exports.generateFilter = generateFilter;
function generateSorting(sort) {
    var mySorting = {};
    if (typeof sort[0].dir !== "undefined") {
        if (sort[0].dir === "asc") {
            mySorting[sort[0].field] = 1;
        }
        else {
            mySorting[sort[0].field] = -1;
        }
    }
    else {
        mySorting[sort[0].field] = 1;
    }
    return mySorting;
}
exports.generateSorting = generateSorting;
function initFilter(searchText, fieldsArr) {
    var filt = [];
    var sp = searchText.split(" ");
    for (var i = 0; i < fieldsArr.length; i++) {
        var or = {};
        or["$or"] = [];
        for (var g = 0; g < sp.length; g++) {
            var query = {};
            query[fieldsArr[i]] = { '$regex': ".*" + sp[g] + ".*", '$options': 'i' };
            or["$or"].push(query);
        }
        filt.push(or);
    }
    return filt;
}
exports.initFilter = initFilter;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"loginHandler.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/libModules/loginHandler.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var accounts_base_1 = require("meteor/accounts-base");
var _ = require("underscore");
var needle = require('needle');
var Future = require("fibers/future");
accounts_base_1.Accounts['registerLoginHandler']('google', function (serviceData) {
    console.log("huhu 1");
    var fut = new Future();
    var loginRequest = serviceData['google'];
    if (!loginRequest) {
        return undefined;
    }
    var serviceConfig = ServiceConfiguration.configurations.findOne({ service: 'google' });
    if (!serviceConfig)
        throw new ServiceConfiguration.ConfigError();
    getScopes(loginRequest.access_token).then(function (profile) {
        if (profile === null) {
            throw new meteor_1.Meteor.Error(401, 'Access Token is invalid');
        }
        console.log("huhu 2");
        var expiresAt = (+new Date) + (1000 * parseInt(profile.expires_in, 10));
        getIdentity(loginRequest.access_token).then(function (identity) {
            serviceData = {
                accessToken: loginRequest.access_token,
                expiresAt: expiresAt,
                scope: profile.scope,
            };
            console.log("huhu 3");
            _.extend(loginRequest, identity);
            var existingUser = meteor_1.Meteor.users.findOne({ 'services.google.email': loginRequest.email });
            console.log(existingUser);
            var userId = null;
            if (existingUser) {
                userId = existingUser._id;
                var prefixedServiceData_1 = {};
                _.each(serviceData, function (val, key) {
                    prefixedServiceData_1["services.google." + key] = val;
                });
                if (typeof existingUser['dashboard'] === "undefined") {
                    prefixedServiceData_1['dashboard'] = [];
                }
                meteor_1.Meteor.users.update({ _id: userId }, {
                    $set: prefixedServiceData_1,
                });
            }
            else {
                userId = null;
            }
            console.log("huhu 4");
            fut.return({ userId: userId });
        });
    });
    return fut.wait();
});
var getIdentity = function (accessToken) {
    return new Promise(function (res, rej) {
        needle.get("https://www.googleapis.com/oauth2/v1/userinfo?access_token=" + accessToken, function (error, response) {
            if (!error && response.statusCode == 200) {
                res(response.body);
            }
            else {
                res(null);
            }
        });
    });
};
var getScopes = function (accessToken) {
    return new Promise(function (res, rej) {
        needle.get("https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=" + accessToken, function (error, response) {
            if (!error && response.statusCode == 200) {
                res(response.body);
            }
            else {
                res(null);
            }
        });
    });
};
var exchangeAuthCode = function (authCode, config) {
    return new Promise(function (res, rej) {
        needle.post("https://www.googleapis.com/oauth2/v4/token", {
            code: authCode,
            client_id: config.clientId,
            client_secret: OAuth.openSecret(config.secret),
            grant_type: 'authorization_code'
        }, function (error, response) {
            if (!error && response.statusCode == 200) {
                res(response.body);
            }
            else {
                res(null);
            }
        });
    });
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"office365.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/libModules/office365.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
require("isomorphic-fetch");
var ms = require("@microsoft/microsoft-graph-client");
var scopeBackend = "openid offline_access email profile Group.Read.All GroupMember.Read.All User.Read.All Calendars.ReadWrite.Shared";
var credentials = {
    client: {
        id: "59bc226d-08b4-4204-a68d-4d4b88f5d1ae",
        secret: "BsaEYXahwPvHcwF9p51Z3Cos?M]fFd:=" //mMj.Ncno1luE@J1TFFsc:Ka6gY3e@VaG
    },
    auth: {
        tokenHost: "https://login.microsoftonline.com",
        authorizePath: "1f9a148d-183c-409c-8f6b-778be43b5a82/oauth2/v2.0/authorize",
        tokenPath: "1f9a148d-183c-409c-8f6b-778be43b5a82/oauth2/v2.0/token"
    }
};
var oauth2 = require("simple-oauth2").create(credentials);
var index_1 = require("../collections/index");
var index_2 = require("../collections/index");
var needle = require("needle");
function readDataFromSpreadsheet(sprID) {
    return new Promise(function (resp, rej) {
        var obj = {};
        var tz = index_2.Syncer.find({}).cursor.fetch();
        oauth2.accessToken
            .create({ refresh_token: tz[0].refresh_token })
            .refresh()
            .then(function (data) {
            var client = ms.Client.init({
                defaultVersion: "v1.0",
                debugLogging: false,
                authProvider: function (done) {
                    done(null, data.token.access_token);
                }
            });
            client
                .api("/me/drive/items/01UTEUECGN3DIWRFXIQ5GZHSI52WXUQSOL/workbook/worksheets")
                .get()
                .then(function (res) {
                resp(res);
            })
                .catch(function (err) {
                resp(err);
            });
        });
    });
}
exports.readDataFromSpreadsheet = readDataFromSpreadsheet;
function getPhotoFromId(id) {
    return new Promise(function (res, rej) {
        ///me/photos/120x120/$value
        var tz = index_2.Syncer.find({}).cursor.fetch();
        oauth2.accessToken
            .create({ refresh_token: tz[0].refresh_token })
            .refresh()
            .then(function (data) {
            var options = {
                headers: { authorization: "bearer " + data.token.access_token }
            };
            //
            needle.get("https://graph.microsoft.com/v1.0/users/" +
                id +
                "/photos/120x120/$value", options, Meteor.bindEnvironment(function (err, resp) {
                if (typeof resp.body.error !== "undefined") {
                    res({
                        error: true,
                        contentType: null,
                        data: null
                    });
                }
                else {
                    res({
                        error: false,
                        contentType: resp.headers["content-type"],
                        data: resp.body.toString("base64")
                    });
                }
            }));
        });
    });
}
exports.getPhotoFromId = getPhotoFromId;
function createDataToSpreadsheetOneDrive(sprID, Workbook, Data, ColumnsLength, DataLength) {
    return new Promise(function (resp, rej) {
        var obj = {
            values: [Data]
        };
        console.log(obj);
        var tz = index_2.Syncer.find({}).cursor.fetch();
        oauth2.accessToken
            .create({ refresh_token: tz[0].refresh_token })
            .refresh()
            .then(function (data) {
            var client = ms.Client.init({
                defaultVersion: "v1.0",
                debugLogging: false,
                authProvider: function (done) {
                    done(null, data.token.access_token);
                }
            });
            client
                .api("/me/drive/items/" +
                sprID +
                "/workbook/worksheets/" +
                Workbook +
                "/usedRange")
                .get()
                .then(function (range) {
                client
                    .api("/me/drive/items/" + sprID + "/workbook/createSession")
                    .post({
                    persistChanges: true
                })
                    .then(function (res) {
                    console.log("/me/drive/items/" +
                        sprID +
                        "/workbook/worksheets/" +
                        Workbook +
                        "/range(address='A" +
                        (range.rowCount + 1) +
                        ":" +
                        calcBuchstabe(ColumnsLength) +
                        (DataLength + range.rowCount) +
                        "')");
                    client
                        .api("/me/drive/items/" +
                        sprID +
                        "/workbook/worksheets/" +
                        Workbook +
                        "/range(address='A" +
                        (range.rowCount + 1) +
                        ":" +
                        calcBuchstabe(ColumnsLength) +
                        (1 + range.rowCount) +
                        "')")
                        .header("workbook-session-id", res.id)
                        .patch(obj)
                        .then(function (res) {
                        resp(res);
                    })
                        .catch(function (err) {
                        resp(err);
                    });
                })
                    .catch(function (err) {
                    resp(err);
                });
            })
                .catch(function (err) {
                resp(err);
            });
        });
    });
}
exports.createDataToSpreadsheetOneDrive = createDataToSpreadsheetOneDrive;
function uploadDataToSpreadsheetOneDrive(sprID, Workbook, Data, DataLength, ColumnsLength) {
    return new Promise(function (resp, rej) {
        var obj = {
            values: Data
        };
        console.log(calcBuchstabe(ColumnsLength) + DataLength);
        var tz = index_2.Syncer.find({}).cursor.fetch();
        oauth2.accessToken
            .create({ refresh_token: tz[0].refresh_token })
            .refresh()
            .then(function (data) {
            var client = ms.Client.init({
                defaultVersion: "v1.0",
                debugLogging: false,
                authProvider: function (done) {
                    done(null, data.token.access_token);
                }
            });
            client
                .api("/me/drive/items/" + sprID + "/workbook/createSession")
                .post({
                persistChanges: true
            })
                .then(function (res) {
                client
                    .api("/me/drive/items/" +
                    sprID +
                    "/workbook/worksheets/" +
                    Workbook +
                    "/range(address='A1:" +
                    calcBuchstabe(ColumnsLength) +
                    DataLength +
                    "')")
                    .header("workbook-session-id", res.id)
                    .patch(obj)
                    .then(function (res) {
                    resp(res);
                })
                    .catch(function (err) {
                    resp(err);
                });
            })
                .catch(function (err) {
                resp(err);
            });
        });
    });
}
exports.uploadDataToSpreadsheetOneDrive = uploadDataToSpreadsheetOneDrive;
function calcBuchstabe(ColumnsLength) {
    var al = [
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "I",
        "J",
        "K",
        "L",
        "M",
        "N",
        "O",
        "P",
        "Q",
        "R",
        "S",
        "T",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z"
    ];
    if (ColumnsLength < al.length) {
        return al[ColumnsLength - 1];
    }
    else {
        var tester = ColumnsLength % al.length;
        var teil = Math.round(ColumnsLength / al.length);
        var rt = "";
        for (var o = 0; o < teil; o++) {
            if (o === teil - 1) {
                rt = rt + al[tester - 1];
            }
            else {
                rt = rt + "Z";
            }
        }
    }
}
function uploadDataToSpreadsheet(sprID, Workbook, Data) {
    return new Promise(function (resp, rej) {
        var obj = {
            values: [
                ["Test", "Value"],
                ["For", "Update"]
            ]
        };
        var tz = index_2.Syncer.find({}).cursor.fetch();
        oauth2.accessToken
            .create({ refresh_token: tz[0].refresh_token })
            .refresh()
            .then(function (data) {
            var client = ms.Client.init({
                defaultVersion: "v1.0",
                debugLogging: false,
                authProvider: function (done) {
                    done(null, data.token.access_token);
                }
            });
            client
                .api("/me/drive/items/01RNJGBERZNFA6DGZWM5DL7UKFH62TWIGD/workbook/createSession")
                .post({
                persistChanges: true
            })
                .then(function (res) {
                console.log(res);
                client
                    .api("/me/drive/items/01RNJGBERZNFA6DGZWM5DL7UKFH62TWIGD/workbook/worksheets/data/range(address='A1:B2')")
                    .header("workbook-session-id", res.id)
                    .patch(obj)
                    .then(function (res) {
                    resp(res);
                })
                    .catch(function (err) {
                    resp(err);
                });
            })
                .catch(function (err) {
                resp(err);
            });
        });
    });
}
exports.uploadDataToSpreadsheet = uploadDataToSpreadsheet;
function sendEmail(to, cc, subjet, body) {
    return new Promise(function (resp, rej) {
        var obj = {
            message: {
                subject: subjet,
                body: {
                    contentType: "HTML",
                    content: body
                },
                toRecipients: [],
                ccRecipients: []
            },
            saveToSentItems: "false"
        };
        for (var l = 0; l < to.length; l++) {
            obj.message.toRecipients.push({
                emailAddress: {
                    address: to[l]
                }
            });
        }
        for (var p = 0; p < cc.length; p++) {
            obj.message.ccRecipients.push({
                emailAddress: {
                    address: cc[l]
                }
            });
        }
        var tz = index_2.Syncer.find({}).cursor.fetch();
        oauth2.accessToken
            .create({ refresh_token: tz[0].refresh_token })
            .refresh()
            .then(function (data) {
            var client = ms.Client.init({
                defaultVersion: "v1.0",
                debugLogging: false,
                authProvider: function (done) {
                    done(null, data.token.access_token);
                }
            });
            client
                .api("/me/sendMail")
                .post(obj)
                .then(function (res) {
                resp(res);
            })
                .catch(function (err) {
                resp(err);
            });
        });
    });
}
exports.sendEmail = sendEmail;
function createEvent(title, description, start, end, email) {
    return new Promise(function (resp, rej) {
        var obj = {
            subject: title,
            body: {
                contentType: "HTML",
                content: description
            },
            start: {
                dateTime: start,
                timeZone: "Europa/Berlin"
            },
            end: {
                dateTime: end,
                timeZone: "Europa/Berlin"
            },
            isAllDay: true,
            attendees: [
                {
                    emailAddress: {
                        address: email
                    },
                    type: "required"
                }
            ]
        };
        var tz = index_2.Syncer.find({}).cursor.fetch();
        oauth2.accessToken
            .create({ refresh_token: tz[0].refresh_token })
            .refresh()
            .then(function (data) {
            var client = ms.Client.init({
                defaultVersion: "v1.0",
                debugLogging: false,
                authProvider: function (done) {
                    done(null, data.token.access_token);
                }
            });
            client
                .api("/me/events")
                .post(obj)
                .then(function (res) {
                resp(res);
            })
                .catch(function (err) {
                resp(err);
            });
        });
    });
}
exports.createEvent = createEvent;
function delteEvent(id) {
    return new Promise(function (resp, rej) {
        var tz = index_2.Syncer.find({}).cursor.fetch();
        oauth2.accessToken
            .create({ refresh_token: tz[0].refresh_token })
            .refresh()
            .then(function (data) {
            var client = ms.Client.init({
                defaultVersion: "v1.0",
                debugLogging: false,
                authProvider: function (done) {
                    done(null, data.token.access_token);
                }
            });
            client
                .api("/me/events/" + id)
                .delete()
                .then(function (res) {
                resp(res);
            })
                .catch(function (err) {
                resp(err);
            });
        });
    });
}
exports.delteEvent = delteEvent;
function updateEvent(id, title, description, start, end, email) {
    return new Promise(function (resp, rej) {
        var obj = {
            subject: title,
            body: {
                contentType: "HTML",
                content: description
            },
            start: {
                dateTime: start,
                timeZone: "Europa/Berlin"
            },
            end: {
                dateTime: end,
                timeZone: "Europa/Berlin"
            },
            isAllDay: true,
            attendees: [
                {
                    emailAddress: {
                        address: email
                    },
                    type: "required"
                }
            ]
        };
        var tz = index_2.Syncer.find({}).cursor.fetch();
        oauth2.accessToken
            .create({ refresh_token: tz[0].refresh_token })
            .refresh()
            .then(function (data) {
            var client = ms.Client.init({
                defaultVersion: "v1.0",
                debugLogging: false,
                authProvider: function (done) {
                    done(null, data.token.access_token);
                }
            });
            client
                .api("/me/events/" + id)
                .put(obj)
                .then(function (res) {
                resp(res);
            })
                .catch(function (err) {
                resp(err);
            });
        });
    });
}
exports.updateEvent = updateEvent;
function getGroupList() {
    return new Promise(function (resp, rej) {
        var tz = index_2.Syncer.find({}).cursor.fetch();
        oauth2.accessToken
            .create({ refresh_token: tz[0].refresh_token })
            .refresh()
            .then(function (data) {
            var client = ms.Client.init({
                defaultVersion: "v1.0",
                debugLogging: false,
                authProvider: function (done) {
                    done(null, data.token.access_token);
                }
            });
            client
                .api("/groups")
                .get()
                .then(function (res) {
                var tempValue = res.value;
                var prom = [];
                for (var l = 0; l < tempValue.length; l++) {
                    if (tempValue[l].displayName.indexOf("team") !== -1 ||
                        tempValue[l].displayName.indexOf("Team") !== -1)
                        prom.push(getGroupDatail(tempValue[l], client));
                }
                Promise.all(prom).then(function (data) {
                    resp(data);
                });
            })
                .catch(function (err) {
                resp(err);
            });
        });
    });
}
exports.getGroupList = getGroupList;
function getGroupDatail(group, client) {
    return new Promise(function (res, rej) {
        client
            .api("/groups/" + group.id + "/members")
            .get()
            .then(function (userIds) {
            var tzu = [];
            var tzuadmin = [];
            console.log(userIds);
            for (var o = 0; o < userIds.value.length; o++) {
                if (typeof userIds.value[o] !== "undefined") {
                    tzu.push(userIds.value[o]);
                    if (userIds.value[o].jobTitle === "Team Lead") {
                        tzuadmin.push(userIds.value[o]);
                    }
                }
            }
            group.userList = tzu;
            group.adminUserList = tzuadmin;
            res(group);
        });
    });
}
function syncUserAndGroups() {
    return new Promise(function (res, rej) {
        getGroupList().then(function (data) {
            var GroupList = index_1.Teams.find({}).cursor.fetch();
            checkGroup(GroupList, data, 0, function (dataLists) {
                var UserList = index_1.Users.find({}).cursor.fetch();
                var UserOList = [];
                for (var z = 0; z < dataLists.length; z++) {
                    for (var y = 0; y < dataLists[z].userList.length; y++) {
                        var found = false;
                        for (var k = 0; k < UserOList.length; k++) {
                            if (UserOList[k].id === dataLists[z].userList[y].id) {
                                found = true;
                            }
                        }
                        if (found === false) {
                            UserOList.push(dataLists[z].userList[y]);
                        }
                    }
                }
                updateUser(UserList, UserOList, 0, function () {
                    res();
                });
            });
        });
    });
}
exports.syncUserAndGroups = syncUserAndGroups;
function updateUser(UserList, UserOList, index, cb) {
    if (UserOList.length === index) {
        cb();
    }
    else {
        var found = false;
        for (var x = 0; x < UserList.length; x++) {
            if (UserList[x]._id === UserOList[index].id) {
                found = true;
                UserOList[index]._id = UserOList[index].id;
                delete UserOList[index]["@odata.type"];
                index_1.Users.update({ _id: UserOList[index].id }, { $set: UserOList[index] })
                    .toPromise()
                    .then(function () {
                    updateUser(UserList, UserOList, index + 1, cb);
                });
            }
        }
        if (found === false) {
            UserOList[index]._id = UserOList[index].id;
            delete UserOList[index]["@odata.type"];
            index_1.Users.insert(UserOList[index])
                .toPromise()
                .then(function () {
                updateUser(UserList, UserOList, index + 1, cb);
            })
                .catch(function (err) { });
        }
    }
}
function checkGroup(groupList, dataLists, index, cb) {
    if (dataLists.length === index) {
        cb(dataLists);
    }
    else {
        if (dataLists[index].visibility === "Private") {
            checkGroup(groupList, dataLists, index + 1, cb);
            return;
        }
        var found = false;
        for (var x = 0; x < groupList.length; x++) {
            if (groupList[x]._id === dataLists[index].id) {
                found = true;
                dataLists[index]._id = dataLists[index].id;
                index_1.Teams.update({ _id: dataLists[index].id }, { $set: dataLists[index] })
                    .toPromise()
                    .then(function () {
                    checkGroup(groupList, dataLists, index + 1, cb);
                });
            }
        }
        if (found === false) {
            dataLists[index]._id = dataLists[index].id;
            dataLists[index].eventTypeIds = [];
            delete dataLists[index].userList;
            delete dataLists[index].adminUserList;
            index_1.Teams.insert(dataLists[index])
                .toPromise()
                .then(function () {
                checkGroup(groupList, dataLists, index + 1, cb);
            })
                .catch(function (err) { });
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"query.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/libModules/query.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
(function () {
  function objectify(a) {
    var rows = [];

    for (var key in a) {
      var o = {};
      o[key] = a[key];
      rows.push(o);
    }

    return rows;
  } // polyfill, since String.startsWith is part of ECMAScript 6,


  if (!String.prototype.startsWith) {
    Object.defineProperty(String.prototype, 'startsWith', {
      enumerable: false,
      configurable: false,
      writable: false,
      value: function (searchString, position) {
        position = position || 0;
        return this.lastIndexOf(searchString, position) === position;
      }
    });
  } // polyfill, since String.endsWith is part of ECMAScript 6,


  if (!String.prototype.endsWith) {
    Object.defineProperty(String.prototype, 'endsWith', {
      value: function (searchString, position) {
        var subjectString = this.toString();

        if (position === undefined || position > subjectString.length) {
          position = subjectString.length;
        }

        position -= searchString.length;
        var lastIndex = subjectString.indexOf(searchString, position);
        return lastIndex !== -1 && lastIndex === position;
      }
    });
  } // should turn this function around so it works more like this
  //
  // var truth = Query(q).satisfies(obj)


  var Query = {
    satisfies: function (row, constraints, getter) {
      return Query.lhs._rowsatisfies(row, constraints, getter);
    },
    Query: function (constraints, getter) {
      return function (row) {
        return Query.lhs._rowsatisfies(row, constraints, getter);
      };
    },
    join: function (left_rows, right_rows, left_key, right_key) {
      var leftKeyFn, rightKeyFn;
      if (typeof left_key == 'string') leftKeyFn = function (row) {
        return row[left_key];
      };else leftKeyFn = left_key;
      if (!right_key) rightKeyFn = leftKeyFn;
      if (typeof right_key == 'string') rightKeyFn = function (row) {
        return row[left_key];
      };else rightKeyFn = right_key;
      return left_rows;
    },
    query: function (rows, constraints, getter) {
      if (typeof getter == 'string') {
        var method = getter;

        getter = function (obj, key) {
          return obj[method](key);
        };
      }

      var filter = new Query.Query(constraints, getter);
      return rows.filter(filter);
    },
    lhs: {
      // queries that are not yet referenced to a particular attribute, e.g. {$not: {likes: 0}}
      // test whether a row satisfies a constraints hash,
      _rowsatisfies: function (row, constraints, getter) {
        for (var key in constraints) {
          if (this[key]) {
            if (!this[key](row, constraints[key], getter)) return false;
          } else {
            var val = getter ? getter(row, key) : row[key];

            var res = this.rhs._satisfies(val, constraints[key], key);

            if (!res) return false;
          }
        }

        return true;
      },
      $count: function (row, condition, getter) {
        var res = condition.$constraints.map(function (c) {
          return Query.satisfies(row, c, getter);
        }).filter(function (v) {
          return v;
        }).length;
        return this.rhs._satisfies(res, condition.$constraint);
      },
      $not: function (row, constraint, getter) {
        return !this._rowsatisfies(row, constraint, getter);
      },
      $or: function (row, constraint, getter) {
        if (!Array.isArray(constraint)) {
          constraint = objectify(constraint);
        }

        for (var i = 0; i < constraint.length; i++) {
          if (this._rowsatisfies(row, constraint[i], getter)) return true;
        }

        return false;
      },
      $and: function (row, constraint, getter) {
        if (!Array.isArray(constraint)) {
          constraint = objectify(constraint);
        }

        for (var i = 0; i < constraint.length; i++) {
          if (!this._rowsatisfies(row, constraint[i], getter)) return false;
        }

        return true;
      },
      $nor: function (row, constraint, getter) {
        return !this.$or(row, constraint, getter);
      },
      $where: function (values, ref) {
        var fn = typeof ref == 'string' ? new Function(ref) : ref;
        var res = fn.call(values);
        return res;
      },
      rhs: {
        // queries that reference a particular attribute, e.g. {likes: {$gt: 10}}
        $cb: function (value, constraint, parentKey) {
          return constraint(value);
        },
        // test whether a single value matches a particular constraint
        _satisfies: function (value, constraint, parentKey) {
          if (constraint === value) return true;

          if (typeof value === 'string' && (value[0] === '[' || value[0] === '{')) {
            try {
              var value = JSON.parse(value);
            } catch (e) {}
          }

          if (constraint instanceof RegExp) return this.$regex(value, constraint);else if (Array.isArray(constraint)) return this.$in(value, constraint);else if (constraint && typeof constraint === 'object') {
            if (constraint instanceof Date) return this.$eq(value, constraint.getTime());else {
              if (constraint.$regex) return this.$regex(value, new RegExp(constraint.$regex, constraint.$options));

              for (var key in constraint) {
                if (!this[key]) return this.$eq(value, constraint, parentKey);else if (!this[key](value, constraint[key], parentKey)) return false;
              }

              return true;
            }
          } else if (Array.isArray(value)) {
            for (var i = 0; i < value.length; i++) if (this.$eq(value[i], constraint)) return true;

            return false;
          } else if (constraint === '' || constraint === null || constraint === undefined) return this.$null(value);else return this.$eq(value, constraint);
        },
        $eq: function (value, constraint) {
          if (value === constraint) return true;else if (Array.isArray(value)) {
            for (var i = 0; i < value.length; i++) if (this.$eq(value[i], constraint)) return true;

            return false;
          } else if (constraint === null || constraint === undefined || constraint === '') {
            return this.$null(value);
          } else if (value === null || value === '' || value === undefined) return false; //we know from above the constraint is not null
          else if (value instanceof Date) {
              if (constraint instanceof Date) {
                return value.getTime() == constraint.getTime();
              } else if (typeof constraint == 'number') {
                return value.getTime() == constraint;
              } else if (typeof constraint == 'string') return value.getTime() == new Date(constraint).getTime();
            } else {
              return value == constraint;
            }
          ;
        },
        $exists: function (value, constraint, parentKey) {
          return value != undefined == (constraint && true);
        },
        $deepEquals: function (value, constraint) {
          if (typeof _ == 'undefined' || typeof _.isEqual == 'undefined') {
            return JSON.stringify(value) == JSON.stringify(constraint); //
          } else {
            return _.isEqual(value, constraint);
          }
        },
        $not: function (values, constraint) {
          return !this._satisfies(values, constraint);
        },
        $ne: function (values, constraint) {
          return !this._satisfies(values, constraint);
        },
        $nor: function (values, constraint, parentKey) {
          return !this.$or(values, constraint, parentKey);
        },
        $and: function (values, constraint, parentKey) {
          if (!Array.isArray(constraint)) {
            throw new Error("Logic $and takes array of constraint objects");
          }

          for (var i = 0; i < constraint.length; i++) {
            var res = this._satisfies(values, constraint[i], parentKey);

            if (!res) return false;
          }

          return true;
        },
        // Identical to $in, but allows for different semantics
        $or: function (values, constraint, parentKey) {
          if (!Array.isArray(values)) {
            values = [values];
          }

          for (var v = 0; v < values.length; v++) {
            for (var i = 0; i < constraint.length; i++) {
              if (this._satisfies(values[v], constraint[i], parentKey)) {
                return true;
              }
            }
          }

          return false;
        },

        /**
         * returns true if all of the values in the array are null
         * @param values
         * @returns {boolean}
         */
        $null: function (values) {
          var result;

          if (values === '' || values === null || values === undefined) {
            return true;
          } else if (Array.isArray(values)) {
            for (var v = 0; v < values.length; v++) {
              if (!this.$null(values[v])) {
                return false;
              }
            }

            return true;
          } else return false;
        },

        /**
         * returns true if any of the values are keys of the constraint
         * @param values
         * @param constraint
         * @returns {boolean}
         */
        $in: function (values, constraint) {
          if (!Array.isArray(constraint)) throw new Error("$in requires an array operand");
          var result = false;

          if (!Array.isArray(values)) {
            values = [values];
          }

          for (var v = 0; v < values.length; v++) {
            var val = values[v];

            for (var i = 0; i < constraint.length; i++) {
              if (constraint.indexOf(val) >= 0 || this._satisfies(val, constraint[i])) {
                result = true;
                break;
              }
            }
          }

          return result;
        },
        $likeI: function (values, constraint) {
          return values.toLowerCase().indexOf(constraint) >= 0;
        },
        $like: function (values, constraint) {
          return values.indexOf(constraint) >= 0;
        },
        $startsWith: function (values, constraint) {
          if (!values) return false;
          return values.startsWith(constraint);
        },
        $endsWith: function (values, constraint) {
          if (!values) return false;
          return values.endsWith(constraint);
        },
        $elemMatch: function (values, constraint, parentKey) {
          for (var i = 0; i < values.length; i++) {
            if (Query.lhs._rowsatisfies(values[i], constraint)) return true;
          }

          return false;
        },
        $contains: function (values, constraint) {
          return values.indexOf(constraint) >= 0;
        },
        $nin: function (values, constraint) {
          return !this.$in(values, constraint);
        },
        $regex: function (values, constraint) {
          var result = false;

          if (Array.isArray(values)) {
            for (var i = 0; i < values.length; i++) {
              if (constraint.test(values[i])) {
                return true;
              }
            }
          } else return constraint.test(values);
        },
        $gte: function (values, ref) {
          if (Array.isArray(values)) {
            var self = this;
            return values.every(function (v) {
              return self.$gte(v, ref);
            });
          }

          return !this.$null(values) && values >= this.resolve(ref);
        },
        $gt: function (values, ref) {
          if (Array.isArray(values)) {
            var self = this;
            return values.every(function (v) {
              return self.$gt(v, ref);
            });
          }

          return !this.$null(values) && values > this.resolve(ref);
        },
        $lt: function (values, ref) {
          if (Array.isArray(values)) {
            var self = this;
            return values.every(function (v) {
              return self.$lt(v, ref);
            });
          }

          return !this.$null(values) && values < this.resolve(ref);
        },
        $lte: function (values, ref) {
          if (Array.isArray(values)) {
            var self = this;
            return values.every(function (v) {
              return self.$lte(v, ref);
            });
          }

          return !this.$null(values) && values <= this.resolve(ref);
        },
        $before: function (values, ref) {
          if (typeof ref === 'string') ref = Date.parse(ref);
          if (typeof values === 'string') values = Date.parse(values);
          return this.$lte(values, ref);
        },
        $after: function (values, ref) {
          if (typeof ref === 'string') ref = Date.parse(ref);
          if (typeof values === 'string') values = Date.parse(values);
          return this.$gte(values, ref);
        },
        $type: function (values, ref) {
          return typeof values == ref;
        },
        $all: function (values, ref) {
          throw new Error("$all not implemented");
        },
        $size: function (values, ref) {
          return typeof values == 'object' && (values.length == ref || Object.keys(values).length == ref);
        },
        $mod: function (values, ref) {
          return values % ref[0] == ref[1];
        },
        $equal: function () {
          return this.$eq(arguments);
        },
        $between: function (values, ref) {
          return this._satisfies(values, {
            $gt: ref[0],
            $lt: ref[1]
          });
        },
        resolve: function (ref) {
          if (typeof ref === 'object') {
            if (ref["$date"]) return Date.parse(ref["$date"]);
          }

          return ref;
        }
      }
    }
  }; // Provide means to parse dot notation for deep Mongo queries, optional for performance

  Query.undot = function (obj, key) {
    var keys = key.split('.'),
        sub = obj;

    for (var i = 0; i < keys.length; i++) {
      sub = sub[keys[i]];
    }

    return sub;
  };

  Query.lhs.rhs.$equal = Query.lhs.rhs.$eq;
  Query.lhs.rhs.$any = Query.lhs.rhs.$or;
  Query.lhs.rhs.$all = Query.lhs.rhs.$and;

  Query.satisfies = function (row, constraints, getter) {
    return this.lhs._rowsatisfies(row, constraints, getter);
  };

  Array.prototype.query = function (q) {
    return Query.query(this, q);
  }; //This allows a query object with regex values to be serialized to JSON
  //http://stackoverflow.com/questions/12075927/serialization-of-regexp
  //However, it doesn't solve the problem of parsing them back to regex on input


  RegExp.prototype.toJSON = RegExp.prototype.toString;
  if (typeof module != 'undefined') module.exports = Query;else if (typeof define != 'undefined' && define.amd) define('query', [], function () {
    return Query;
  });else if (typeof window != 'undefined') window.Query = Query;else if (typeof GLOBAL != undefined && GLOBAL.global) GLOBAL.global.Query = Query;
  return Query;
})(this);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"queryBuilder.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/libModules/queryBuilder.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
function generateMongoQuery(query) {
    return new Promise(function (res, rej) {
        if (query.rules.length === 0) {
            res({});
        }
        else {
            var obj = {};
            var multi = [];
            for (var o = 0; o < query.rules.length; o++) {
                multi.push(regelgenerierung(query.rules[o]));
            }
            Promise.all(multi).then(function (data) {
                if (query.condition === "and") {
                    obj["$and"] = data;
                }
                else {
                    obj["$or"] = data;
                }
                res(obj);
            });
        }
    });
}
exports.generateMongoQuery = generateMongoQuery;
//['equals', "doesn`t equal" ,'contains', 'doesn`t contains','start with','doesn`t start with','ends with','doesn`t ends with','exists','doesn`t  exists','in','not in','array contains all','>','>=','<','<=','has type','doesn`t has type','regex']
function regelgenerierung(rule) {
    return new Promise(function (res, rej) {
        if (typeof rule.condition !== "undefined") {
            var obj = {};
            var multi = [];
            for (var o = 0; o < rule.rules.length; o++) {
                multi.push(regelgenerierung(rule.rules[o]));
            }
            Promise.all(multi).then(function (data) {
                if (rule.condition === "and") {
                    obj["$and"] = data;
                }
                else {
                    obj["$or"] = data;
                }
                res(obj);
            });
        }
        else {
            var obj = {};
            switch (rule.operator) {
                case "equals":
                    obj[rule.field] = rule.value;
                    break;
                case "doesn`t equal":
                    obj[rule.field] = rule.value;
                    break;
                case "contains":
                    obj[rule.field] = rule.value;
                    break;
                case "doesn`t contains":
                    obj[rule.field] = rule.value;
                    break;
                case "start with":
                    obj[rule.field] = rule.value;
                    break;
                case "doesn`t start with":
                    obj[rule.field] = rule.value;
                    break;
                case "ends with":
                    obj[rule.field] = rule.value;
                    break;
                case "doesn`t ends with":
                    obj[rule.field] = rule.value;
                    break;
                case "exists":
                    obj[rule.field] = rule.value;
                    break;
                case "doesn`t  exists":
                    obj[rule.field] = rule.value;
                    break;
                case "in":
                    obj[rule.field] = rule.value;
                    break;
                case "not in":
                    obj[rule.field] = rule.value;
                    break;
                case "array contains all":
                    obj[rule.field] = rule.value;
                    break;
                case ">":
                    obj[rule.field] = rule.value;
                    break;
                case ">=":
                    obj[rule.field] = rule.value;
                    break;
                case "<":
                    obj[rule.field] = rule.value;
                    break;
                case "<=":
                    obj[rule.field] = rule.value;
                    break;
                case "has type":
                    obj[rule.field] = rule.value;
                    break;
                case "doesn`t has type":
                    obj[rule.field] = rule.value;
                    break;
                case "regex":
                    obj[rule.field] = rule.value;
                    break;
            }
            res(obj);
        }
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"reactiveaggregate.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/libModules/reactiveaggregate.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var _ = require("underscore");
var mongodb = require("mongodb");
var client = mongodb.MongoClient;
var url = process.env.MONGO_URL;
var db;
var mp = require("parse-mongo-url");
var connections = {};
function loadInitial(argCollection, argSubscription, argPipeline, clientName) {
    argCollection.aggregate(argPipeline).forEach(function (doc) {
        if (!argSubscription._ids[doc._id]) {
            argSubscription.added(clientName, doc._id, doc);
        }
        else {
            argSubscription.changed(clientName, doc._id, doc);
        }
        argSubscription._ids[doc._id] = argSubscription._iteration;
    }, {}); // remove documents not in the result anymore
    _.each(argSubscription._ids, function (iteration, key) {
        if (iteration != argSubscription._iteration) {
            delete argSubscription._ids[key];
            argSubscription.removed(clientName, key);
        }
    });
    argSubscription._iteration++;
}
var loadInitialObserve = meteor_1.Meteor.bindEnvironment(function (argSubscription, argCollection, argPipeline, clientName) {
    argCollection.aggregate(argPipeline, {}).forEach(function (doc) {
        if (!argSubscription._ids[doc._id]) {
            argSubscription.added(clientName, doc._id, doc);
        }
        else {
            argSubscription.changed(clientName, doc._id, doc);
        }
        argSubscription._ids[doc._id] = argSubscription._iteration;
    }, {}); // remove documents not in the result anymore
    _.each(argSubscription._ids, function (iteration, key) {
        if (iteration != argSubscription._iteration) {
            delete argSubscription._ids[key];
            argSubscription.removed(clientName, key);
        }
    });
    argSubscription._iteration++;
});
var loadInitialObserveMain = meteor_1.Meteor.bindEnvironment(function (argSubscription, argCollection, argPipeline, clientName, match) {
    var temp = JSON.parse(JSON.stringify(argPipeline));
    temp.unshift({
        $match: match
    });
    argCollection.aggregate(temp, {}).forEach(function (doc) {
        if (!argSubscription._ids[doc._id]) {
            argSubscription.added(clientName, doc._id, doc);
        }
        else {
            argSubscription.changed(clientName, doc._id, doc);
        }
        argSubscription._ids[doc._id] = argSubscription._iteration;
    }, {}); // remove documents not in the result anymore
    _.each(argSubscription._ids, function (iteration, key) {
        argSubscription._ids[key] = argSubscription._iteration;
    });
    /*
    _.each(argSubscription._ids, (iteration, key) => {
        if (iteration != argSubscription._iteration) {
            delete argSubscription._ids[key];
            argSubscription.removed(clientName, key);
        }
    });*/
    argSubscription._iteration++;
});
var createObserver = meteor_1.Meteor.bindEnvironment(function (mainCollection, argSubscription, argPipeline, argClientName, subcollection) {
    if (subcollection !== null) {
        var tempSubcollections = subcollection.watch([
            {
                $match: {}
            }
        ]);
        tempSubcollections.on("change", function () {
            if (typeof argSubscription.timeouters[mainCollection._name] !==
                "undefined") {
                clearTimeout(argSubscription.timeouters[mainCollection._name]);
            }
            argSubscription.timeouters[mainCollection._name] = setTimeout(function () {
                loadInitialObserve(argSubscription, mainCollection, argPipeline, argClientName);
            }, 500);
        });
        argSubscription.observerHandles.push(tempSubcollections);
    }
    else {
        var tempMainCollection = mainCollection.watch([
            {
                $match: {}
            }
        ]);
        tempMainCollection.on("change", function (das) {
            if (das.operationType === "delete") {
                if (typeof argSubscription._ids[das.documentKey._id] !== "undefined") {
                    delete argSubscription._ids[das.documentKey._id];
                    argSubscription.removed(argClientName, das.documentKey._id);
                }
            }
            else {
                if (typeof argSubscription.timeouters[mainCollection._name] !==
                    "undefined") {
                    clearTimeout(argSubscription.timeouters[mainCollection._name]);
                }
                argSubscription.timeouters[mainCollection._name] = setTimeout(function () {
                    loadInitialObserveMain(argSubscription, mainCollection, argPipeline, argClientName, das.documentKey);
                }, 500);
            }
            argSubscription.timeouters[mainCollection._name] = setTimeout(function () {
                loadInitialObserve(argSubscription, mainCollection, argPipeline, argClientName);
            }, 500);
        });
        argSubscription.observerHandles.push(tempMainCollection);
    }
});
function connectOrGetConnection(argSubscription) {
    return new Promise(meteor_1.Meteor.bindEnvironment(function (res, rej) {
        if (argSubscription._session.mongoClient === null) {
            client.connect(url, {
                useNewUrlParser: true,
                reconnectTries: 60,
                reconnectInterval: 1000,
                bufferMaxEntries: 300000
            }, function (err, client) {
                argSubscription._session.mongoClient = client;
                res(client);
            });
        }
        else {
            res(argSubscription._session.mongoClient);
        }
    }));
}
;
function startGoUse(argSubscription, argCollection, argPipeline, argClientName, client) {
    argSubscription.ikrclient = client;
    argSubscription.observerHandles = [];
    argSubscription.timeouters = {};
    argSubscription.dbIkr = client["db"](mp(url).dbName);
    var clientName;
    if (argClientName === null) {
        clientName = argCollection._name;
    }
    else {
        clientName = argClientName;
    }
    argSubscription._ids = {};
    argSubscription._iteration = 1;
    argSubscription.ready();
    loadInitial(argSubscription.dbIkr.collection(argCollection._name), argSubscription, argPipeline, clientName);
    createObserver(argSubscription.dbIkr.collection(argCollection._name), argSubscription, argPipeline, clientName, null);
    argPipeline.map(function (stage) {
        if (stage.$lookup) {
            createObserver(argSubscription.dbIkr.collection(argCollection._name), argSubscription, argPipeline, clientName, argSubscription.dbIkr.collection(stage.$lookup.from));
        }
    });
}
function watchClientReady(argSubscription, argCollection, argPipeline, argClientName) {
    if (argSubscription._session.mongoClient !== null) {
        startGoUse(argSubscription, argCollection, argPipeline, argClientName, argSubscription._session.mongoClient);
    }
    else {
        setTimeout(function () {
            watchClientReady(argSubscription, argCollection, argPipeline, argClientName);
        }, 500);
    }
}
function IkrReactiveAggregate(argSubscription, argCollection, argPipeline, argClientName) {
    if (argPipeline === void 0) { argPipeline = []; }
    if (typeof argSubscription._session.closeWatcher === "undefined") {
        argSubscription._session.closeWatcher = true;
        argSubscription._session.mongoClient = null;
        argSubscription._session.socket.on("close", meteor_1.Meteor.bindEnvironment(function () {
            if (argSubscription._session.mongoClient !== null) {
                argSubscription._session.mongoClient.close();
            }
        }));
        connectOrGetConnection(argSubscription).then(function (client) {
            startGoUse(argSubscription, argCollection, argPipeline, argClientName, client);
        });
    }
    else {
        watchClientReady(argSubscription, argCollection, argPipeline, argClientName);
    }
    argSubscription.onStop(function () {
        try {
            var promArr = [];
            if (typeof argSubscription.observerHandles !== "undefined") {
                for (var t = 0; t < argSubscription.observerHandles.length; t++) {
                    promArr.push(argSubscription.observerHandles[t].cursor.close());
                    //   console.log(argSubscription.observerHandles[t].cursor);
                }
            }
        }
        catch (e) {
            console.log(e);
        }
        Promise.all(promArr).then(function () {
            if (typeof argSubscription.timeouters !== "undefined") {
                for (var a in argSubscription.timeouters) {
                    if (typeof argSubscription.timeouters[a] !== "undefined") {
                        clearTimeout(argSubscription.timeouters[a]);
                    }
                }
            }
            argSubscription.observerHandles = [];
        });
    });
}
exports.IkrReactiveAggregate = IkrReactiveAggregate;
;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"reactiveaggregateLoc.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/libModules/reactiveaggregateLoc.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var _ = require("underscore");
var mongodb = require("mongodb");
var client = mongodb.MongoClient;
var url = process.env.MONGO_URL;
var db;
var mp = require("parse-mongo-url");
var connections = {};
function loadInitial(argCollection, argSubscription, argPipeline, clientName) {
    argCollection.rawCollection().aggregate(argPipeline, { allowDiskUse: true }).forEach(function (doc) {
        if (!argSubscription._ids[doc._id]) {
            argSubscription.added(clientName, doc._id, doc);
        }
        else {
            argSubscription.changed(clientName, doc._id, doc);
        }
        argSubscription._ids[doc._id] = argSubscription._iteration;
    }, {}); // remove documents not in the result anymore
    _.each(argSubscription._ids, function (iteration, key) {
        if (iteration != argSubscription._iteration) {
            delete argSubscription._ids[key];
            argSubscription.removed(clientName, key);
        }
    });
    argSubscription._iteration++;
}
function IkrReactiveAggregateLoc(argSubscription, argCollection, argPipeline, argClientName) {
    if (argPipeline === void 0) { argPipeline = []; }
    argSubscription._ids = {};
    argSubscription._iteration = 1;
    argSubscription.ready();
    var myArg = argCollection.find({}, {}).observeChanges({
        added: function (data) {
            loadInitial(argCollection, argSubscription, argPipeline, argClientName);
        },
        changed: function (data) {
            loadInitial(argCollection, argSubscription, argPipeline, argClientName);
        },
        error: function (err) {
            throw err;
        }
    });
    argSubscription.onStop(function () {
        myArg.stop();
    });
}
exports.IkrReactiveAggregateLoc = IkrReactiveAggregateLoc;
;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"synchelper.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/libModules/synchelper.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
function generateNewId() {
    var ObjectId = require('mongodb').ObjectID;
    var id = new ObjectId();
    return id.toHexString();
}
exports.generateNewId = generateNewId;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"puplications":{"challange.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/puplications/challange.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var index_1 = require("/server/collections/index");
var Future = require("fibers/future");
/**
 *  Allgemein
 */
meteor_1.Meteor.publish('challange', function (challange) {
    var _this = this;
    var fut = new Future();
    var data = index_1.Chalanges.insert({
        challange: challange,
        state: makeid(20),
        token: ""
    });
    data.toPromise().then(function (d) {
        _this.onStop(function () {
            index_1.Chalanges.remove({ _id: d });
        });
        fut.return(index_1.Chalanges.collection.find({ "_id": d }, { fields: { token: 1, challange: 1 } }));
    });
    return fut.wait();
});
function makeid(length) {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"events.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/puplications/events.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var index_1 = require("../collections/index");
meteor_1.Meteor.publish("events", function (start, end, userIds) {
    if (!this.userId) {
        return;
    }
    return index_1.Events.find({});
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"general.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/puplications/general.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var index_1 = require("/server/collections/index");
var reactiveaggregate_1 = require("/server/libModules/reactiveaggregate");
/**
 *  Allgemein
 */
meteor_1.Meteor.publish("me", function () {
    if (!this.userId) {
        return;
    }
    var arrAggregate = [
        {
            $match: {
                _id: this.userId
            }
        }
    ];
    reactiveaggregate_1.IkrReactiveAggregate(this, index_1.Users["_collection"], arrAggregate, "me");
});
meteor_1.Meteor.publish("userOnline", function () {
    if (!this.userId) {
        return;
    }
    var arrAggregate = [
        {
            $match: {
                "status.online": true
            }
        }
    ];
    reactiveaggregate_1.IkrReactiveAggregate(this, index_1.Users["_collection"], arrAggregate, "userOnline");
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"teams.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/puplications/teams.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var index_1 = require("/server/collections/index");
var reactiveaggregate_1 = require("/server/libModules/reactiveaggregate");
meteor_1.Meteor.publish('teamsIfinitySrcoll', function (skip, limit, filter) {
    if (!this.userId) {
        return;
    }
    var arrAggregate = [
        {
            "$match": {}
        },
        {
            $group: {
                "_id": null,
                "count": {
                    "$sum": 1.0
                },
                "data": {
                    "$push": "$$ROOT"
                }
            }
        },
        {
            $unwind: {
                "path": "$data"
            }
        },
        {
            $addFields: {
                "data.count": {
                    "$add": [
                        "$count"
                    ]
                }
            }
        },
        {
            $replaceRoot: {
                "newRoot": "$data"
            }
        },
        {
            "$skip": skip
        },
        {
            "$limit": limit
        },
        {
            $sort: {
                "title": 1
            }
        },
        {
            "$lookup": {
                "from": "users",
                "localField": "leader",
                "foreignField": "_id",
                "as": "leaderList"
            }
        },
        {
            "$lookup": {
                "from": "users",
                "localField": "member",
                "foreignField": "_id",
                "as": "memberList"
            }
        }
    ];
    if (filter !== "") {
        var and = filter.split(" ");
        var obj = {
            "$and": []
        };
        for (var l = 0; l < and.length; l++) {
            var reg = new RegExp(".*" + and[l] + ".*", "i");
            obj["$and"].push({ $or: [{ "title": reg }, { "description": reg }] });
        }
        arrAggregate[0]["$match"] = obj;
    }
    reactiveaggregate_1.IkrReactiveAggregate(this, index_1.mongoTeams, arrAggregate, "teamsIfinitySrcoll");
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/puplications/users.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var index_1 = require("/server/collections/index");
var reactiveaggregate_1 = require("/server/libModules/reactiveaggregate");
var datagridmongohelper_1 = require("/server/libModules/datagridmongohelper");
/*

Infinity Scroll

*/
meteor_1.Meteor.publish('userIfinitySrcoll', function (skip, limit, filter) {
    if (!this.userId) {
        return;
    }
    var arrAggregate = [
        {
            "$match": {}
        },
        {
            $group: {
                "_id": null,
                "count": {
                    "$sum": 1.0
                },
                "data": {
                    "$push": "$$ROOT"
                }
            }
        },
        {
            $unwind: {
                "path": "$data"
            }
        },
        {
            $addFields: {
                "data.count": {
                    "$add": [
                        "$count"
                    ]
                }
            }
        },
        {
            $replaceRoot: {
                "newRoot": "$data"
            }
        },
        {
            "$skip": skip
        },
        {
            "$limit": limit
        },
        {
            $sort: {
                "emails.address": 1
            }
        }
    ];
    if (filter !== "") {
        var and = filter.split(" ");
        var obj = {
            "$and": []
        };
        for (var l = 0; l < and.length; l++) {
            var reg = new RegExp(".*" + and[l] + ".*", "i");
            obj["$and"].push({ $or: [{ "emails.address": reg }, { "profile.firstName": reg }, { "profile.lastName": reg }] });
        }
        arrAggregate[0]["$match"] = obj;
    }
    reactiveaggregate_1.IkrReactiveAggregate(this, index_1.Users.collection, arrAggregate, "userIfinitySrcoll");
});
/**
 *  Users
 */
meteor_1.Meteor.publish('usersGrid', function (skip, limit, sort, filter) {
    if (!this.userId) {
        return;
    }
    var arrAggregate = [
        {
            "$match": {}
        },
        {
            $group: {
                "_id": null,
                "count": {
                    "$sum": 1.0
                },
                "data": {
                    "$push": "$$ROOT"
                }
            }
        },
        // Stage 3
        {
            $unwind: {
                "path": "$data"
            }
        },
        // Stage 4
        {
            $addFields: {
                "data.count": {
                    "$add": [
                        "$count"
                    ]
                }
            }
        },
        // Stage 5 Last stage for the count function
        {
            $replaceRoot: {
                "newRoot": "$data"
            }
        },
        {
            "$skip": skip
        },
        {
            "$limit": limit
        },
        {
            $sort: {}
        }
    ];
    arrAggregate[0]["$match"] = datagridmongohelper_1.generateFilter(filter, null);
    arrAggregate[7]["$sort"] = datagridmongohelper_1.generateSorting(sort);
    reactiveaggregate_1.IkrReactiveAggregate(this, index_1.Users.collection, arrAggregate, "usersGrid");
});
meteor_1.Meteor.publish('searchUser', function (search) {
    if (!this.userId) {
        return;
    }
    var arrAggregate = [
        {
            "$match": {
                "profile.name": new RegExp(".*" + search + ".*", 'i')
            }
        },
        {
            "$limit": 20.0
        }
    ];
    reactiveaggregate_1.IkrReactiveAggregate(this, index_1.Users.collection, arrAggregate, "searchUser");
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"rest":{"google.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/rest/google.js                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var googleClientId = "287153060758-o290633l04qlj3uaondmkh3ac56s92nl.apps.googleusercontent.com"; //3MVG96_7YM2sI9wT5lPiHkkzy9nFwAV7q4Jmz1e_ShzgzrK4YtPKcIXtEMkAuhNE8TI_S3FEgsFeT_P0y9xEn
var googleSecret = "D1-ZDN3LSQe1RrpvGCjzHBh0"; //5D0F9EFA4765B21FEDE647B23731340B3DD14119494D1B31A3A2455B564C2E51
var googleCallbackUrl = "https://ctstest.code-garage-solutions.de/api/google/callback"; //https://devmira.ikr-apps.de/api/salesforce/callback
var googleLoginUrl = "https://accounts.google.com/o/oauth2/auth"; //https://login.salesforce.com
var scopeGoogle = "email profile";
var Api = new Restivus({
    useDefaultAuth: true,
    prettyJson: false
});
/*
Api.addRoute('google/login', { authRequired: false }, {
    get: function () {
        var state = this.queryParams.state;

       var tempData = Chalanges.findOne({ challange: state });
       if(typeof tempData === "undefined"){
        return "Error: Not valid Parameter"
       }

        var ch = Chalanges.findOne({ challange: state }).state;
        if (typeof ch === "undefined") {
            return "Error: Not valid Parameter"
        } else if (typeof state === "undefined") {
            return "Error: Not valid Parameter"
        } else {
            var url = googleLoginUrl + "";
            url = url + "?response_type=code";
            url = url + "&client_id=" + googleClientId;
            url = url + "&redirect_uri=" + googleCallbackUrl;
            url = url + "&display=" + "touch";
            url = url + "&scope=" + scopeGoogle;
            url = url + "&state=" + ch;

            return {
                statusCode: 302,
                headers: {
                    'Content-Type': 'text/plain',
                    'Location': url
                },
                body: 'Location: ' + url
            };
        }
    }
});

Api.addRoute('google/callback', { authRequired: false }, {
    get: function () {
        var code = this.queryParams.code;
        var state = this.queryParams.state;

        if (typeof code === "undefined") {
            return "Error: Not valid Parameter"
        }
        if (typeof state === "undefined") {
            return "Error: Not valid Parameter"
        }

        const fut = new Future();

        const body = {
            grant_type: "authorization_code",
            client_id: googleClientId,
            client_secret: googleSecret,
            redirect_uri: googleCallbackUrl,
            code: code
        };


        needle.post("https://oauth2.googleapis.com/token?grant_type=authorization_code&code=" + code + "&client_id=" + googleClientId + "&client_secret=" + googleSecret + "&redirect_uri=" + googleCallbackUrl, JSON.stringify(body), {

        }, Meteor.bindEnvironment(function (err, data: any) {

            var myTokenData = data.body;

            //console.log( data.body);

            needle.get('https://openidconnect.googleapis.com/v1/userinfo', {
                headers: {
                    'Authorization': "Bearer " + data.body.access_token
                }
            }, Meteor.bindEnvironment((error, response) => {

                if (error === null && response.statusCode == 200) {
        
                    var dat = Users.findOne({ "services.google.email": response.body.email } );
               
                    if (typeof dat !== "undefined") {
                        response.body['token'] = myTokenData;
                        Users.update({
                            "_id": dat._id
                        }, {
                                "$set": {
                                    "picture": response.body.picture,
                                    "services":{
                                        "google": response.body
                                    }
                                    
                                }
                            });

                        var stampedLoginToken = Accounts["_generateStampedLoginToken"]();
                        Accounts["_insertLoginToken"](dat._id, stampedLoginToken);

                        Chalanges.update({
                            "state": state
                        }, {
                                "$set": {
                                    token: stampedLoginToken
                                }
                            })
                        fut.return({
                            statusCode: 302,
                            headers: {
                                'Content-Type': 'text/html'
                            },
                            body:`<div>Login successful</div><script>
                            window.close();
                        </script>`
                        });
                      
                    } else {

                        Chalanges.update({
                            "state": state
                        }, {
                                "$set": {
                                    token: "Permission Denied"
                                }
                            })
                        fut.return({
                            statusCode: 302,
                            headers: {
                                'Content-Type': 'text/html'
                            },
                            body:`<div>Permission Denied</div><script>
                            window.close();
                        </script>`
                        });
                    }
                } else {
                    fut.return({ err: true, data: null });
                }
            }));
        }));
        return fut.wait();
    }
});*/ 

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"office365.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/rest/office365.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var Future = require("fibers/future");
var needle = require("needle");
var collections_1 = require("../collections");
var meteor_1 = require("meteor/meteor");
var accounts_base_1 = require("meteor/accounts-base");
var jwt = require("jsonwebtoken");
var office365_1 = require("/server/libModules/office365");
var credentials = {
    client: {
        id: "59bc226d-08b4-4204-a68d-4d4b88f5d1ae",
        secret: "BsaEYXahwPvHcwF9p51Z3Cos?M]fFd:=" //mMj.Ncno1luE@J1TFFsc:Ka6gY3e@VaG
    },
    auth: {
        tokenHost: "https://login.microsoftonline.com",
        authorizePath: "1f9a148d-183c-409c-8f6b-778be43b5a82/oauth2/v2.0/authorize",
        tokenPath: "1f9a148d-183c-409c-8f6b-778be43b5a82/oauth2/v2.0/token"
    }
};
var oauth2 = require("simple-oauth2").create(credentials);
var scopeBackend = "openid offline_access email profile Group.Read.All GroupMember.Read.All User.Read.All Calendars.ReadWrite.Shared Files.ReadWrite Mail.Send";
var Api = new Restivus({
    useDefaultAuth: true,
    prettyJson: false
});
Api.addRoute("office365/profilephoto", { authRequired: false }, {
    get: function () {
        var id = this.queryParams.id;
        var fut = new Future();
        var userPhotoUrl = collections_1.Users.findOne({ _id: id });
        if (typeof userPhotoUrl !== "undefined") {
            office365_1.getPhotoFromId(id).then(function (data) {
                //          this.res.contentType("image/jpeg");
                if (data.error === 22) {
                    var img = Buffer.from("/9j/4AAQSkZJRgABAQEAZABkAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAEOAQ4DASIAAhEBAxEB/8QAGgABAAMBAQEAAAAAAAAAAAAAAAMEBQIBBv/EABcBAQEBAQAAAAAAAAAAAAAAAAABAgP/2gAMAwEAAhADEAAAAfsx2wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXNDNyptRm5zRRmxa4wePoKupkpI9wAAAAAAAAABpQa2KGNAAAAc4+1HZhOueuQAAAAAAAB6bFg46BQAAAAMyjr5HTIagAAAAAACSPTi8OWwDwegHh689AIcTfyNZrjpAAAAAAAJNqnf568xNzCTjxY3K9q/YxQzqvk73NmA0qHTPl/O0pb9O45355JH2yAAAAAABLtYG5iy1bTFrWQBQAHPQoXeiKlvNqgOuQAAAAABajrU9c9BKAAU4rNFFLKAAjkGRV+gxt5gG4AAAAA1snVzbhX52w47UQnWZbs2UZbgybF6uWFWeOwoChfoWZo65AAAAATwD6CnT1uWqWhQvgSgAAAKtrKsk0YeSbE6h3A1AAAAAAG3iaWbfHPRx6dEZIwuNZ+gZ+hmiJZeOwxtfB1nwdIAAAAAAOjmf2SNVTuctYclzvcs1rNfFxh2zPtY+xztTJ3qRPZ55za+VoRdJUTQ6gAAAACSTXzatv1zoiXK18zW1AzQKnN1ZHISgMPcztTQ9q2snHZc6h9BBrOK656QAB3xpRc7OWwGbcjsllJQAAAAHPQy9SHiyyJQKuR9DjbzXG4B7vZmrzoZ0BHIAAAAAAACOQAAKlvxPn3fHbI9Na157x0CgAAAAAAAAAAAAZlHYx+mf//EACYQAAIBAgYBBQEBAAAAAAAAAAECAwARBBASIDBAIRMUIjEzI3D/2gAIAQEAAQUC/wAWETmvbtXt69tXtzRgeipHajhLUqKvA8KmnQp14IrcbAMJY9B6mHTU3I66lIsenCto+XFL56Q8nmxAvF0o/wBOaX8+lDELbL7b7SLiZNB6CIXKiy0XY1fOOJmzmTWGUqctRrDMS1ToX6OEzkGl6SJmpIlXaRenw9MpU1hR4yk/TnjcoQbipYtdRxKvCQDTYfyosKnk0Doxfnz4r76EUOrosoapYinPAmpuB51FDEUjq/DKmhuXDfnuZgoZ2lK4evQWmiZKimvwYofHlwx/nUkgSlOoZHVXo3IUDY8StQRkoX3Yo+OWF9DfdTrUBseSY+MPe9E2Eja25o5SlGzKsVzySeXjFhJIEqSQv0YTePlIBynN5ejhT4yZgtAg5OdKu5Y1BJn6i3yPgHyejC2l8pDd4DaSsR+WUH61iTaOsObx1iWsnQAJoQvXt2pH0mpIQxiiCZTi8WUA/pTKGHt/KiwZgKeJ3b0HoxOOVFLUkAFfWcvylUWXY0KsfbrSKEGx/jJmyhqeCiLcMUesgBRnI2lcOup+TFLUDXj2SRhwwKnco1Mq6RsxB1NGuheQi4T+Uu2dNS7sKvjZI2lYo9PPImtYW3TrpfYPJUaRs0/LoMt92IW6bMMt37rjS2eHW0fdxS+ch9/XexAvFX//xAAbEQACAgMBAAAAAAAAAAAAAAABEQAwECBAUP/aAAgBAwEBPwHyFFFFFYOg8JpEOFhWDwRUekaPQ3CpZGxyuI5HgGf/xAAhEQACAQQCAgMAAAAAAAAAAAABAgAQESAwEjEhUEBBUf/aAAgBAgEBPwH1BacjORnIwNsY5A2+Euk6F0sYs6haga0uI2pxneDSTfDicVObYdTkZe+C96OochO4otobDhCLVTTcUv4go0U0BAzLVb8req1DYE1Gg+aqfqrH0Cz/xAApEAABAgQFBQACAwAAAAAAAAABABEQICFAAjAxUWESIjJBcVChcIGR/9oACAEBAAY/Av4W0WoXl+l5fpar0VUXXdQKgyKUKrb9WLXLYri1c6DNYprQZwO/4I2eH7n4rMYjrrnsqaWNEBDyMmwkqI6lFy8KerHFEiGwW5lquxVgTHF9sKIGHK3OTVUNEwhT3ZYflgLF8VBY1TjTProMmlVXCqZPFrVMNF3Fe04TYtcgHO+Q3KfSPaw+p8ZJVJNF24nHKqJgM7iDim5TAFt81gHdU8YOU+fwuCnxf1m9wOE+iq6+1yq2IzqwNkRGpVDAlPDpMfIRe2LoQxRwzNvY0C0XpdGPXeDiifUwMRBivJMIOSF6Xjm0VayFASutSmEvySoXZ/irk8JhISn2zepfJeUxnYJhKMGFNmsUx0M3M5xS8+k58jYdOLyE32YCV7F/cz7SvtfESfb4GIF+Yf/EACkQAQABAwIGAgICAwAAAAAAAAERACExEEEgMEBRYXGBkaGxUHDB0eH/2gAIAQEAAT8h/pbEuPNqNwNcnaP1QMfA1m499VdP8jkbIOa/W6koPz08CDwO3LhBI0nfWH+CEAapmWTpPNG7zoPVdGYDvasc71Bno/wXP/G6O7x4SHcqTvwQ7lSd+AmWG1Gcruhin2rwQRTist9lK3XVQX2arGMJUci0LYoHBemhxgG+hg57KSGHJ0GHtr7S0vseRq8x5HhAQJKJuo8NQQw6Q9/bX8l0EquNyvMhOhRRg1dfkeSTAEoE2qCeA0QAX3UsquehU9AHb8dCkP8AYUEAGDoD4M1uh+vPvXIGKRi/SzseGhL/AI5CSQ1Mm65zhE+7PHMHBUV3wK3viKXLQp7LG5Q7Xu5HqTHOmh3aRhEuxUbBXZ1bw8lISFomCBwXNg9yvrgolsPvi/Mudkcs0IJMVdzm1E5I93fmuTiyitzXeO2hNYClX6c+1Z7aEBuFKypGBtzbiYblY8TvSzsvZSew7dDI/Ec6NhMX09Rt0XrrOuGijZJPGk+7UnT8VL3adS/2dcK571ciwXpSLlv0UOuGzqy8pimEYc6fpfvhCQG7GiDO1tLFz0LIz6pPb7a8v3q7JDRKyXqlbtBAl9WXCxozwNHqeqE8BUCLdsFfHJmku75rIL4vURnmLwfmrleoAQEGqse8V4oI4XNxPbjhKFZuqb0MkmoFprfXypEgh5KdoZaMBBweDKvvHNYT6aijezhvK2xpSF+NwzNEOA4VviKEBzSbA1LxhxXYx44Ub2OHHXdhXeeTnnE52aSH/k8UjGLuEIBltQibcILt3bx0IIwGHitbN3DcGOtIJDXhTggne7roC721M95QQAx13oF9P//aAAwDAQACAAMAAAAQ++++++++++++++++++++++++++++++++++++++++0Eeea8++++++++++088888O0++++++++81888888e++++++++58488088/8AvvvvvvvtJ/p3DsaPfPvvvvvvqfXfPPPD+fvvvvvvuhfPOMdPPLGvvvvvvvvfPPv3tfPOvvvvvvvLnPPPPPOdPPvvvvvvrPMPD9+PL/vvvvvvuOfyP9NU31PPvvvvoL/HPPLXPPH7O/PvqfPOfPPPPPPEfPPfvp/PPPPPPPPPLPPP9PN/PPPPPPPPPPPPPFP/xAAeEQEAAgIDAQEBAAAAAAAAAAABABEQISAwMUFRUP/aAAgBAwEBPxD+QJlJSUj+ewfeSX1hzFPSFvQPvSNXgCw/WG0RIXcS+l/IlwK4hUWjoC4FcLOKVs5+otZRZRKTyDnxzNSxIXXJdQ0bi30LfEN5fSDBuA3HzHmIrDREVjrkWgBgfc0Z8QbMP44Bbl3roNayPuTq+5LyGu8Uz//EAB8RAQACAgMBAQEBAAAAAAAAAAEAESExECAwQVFhUP/aAAgBAgEBPxD/ACANRl/SEP1gjk8/idnX883Oe7s8WBnwZrxRalbim0+Jw2EE1AAwUbIZPAMMFGyKrb1U4YRafBQLYiz0ELqVW+R/Jbh76wF1yJplin2VFMSudHdBKYi4hcdjbHLE2nfgbL4qBcF+xFTKvXAyvioUsRInCbHG8EKY5cQirgjrtVg3FXcM4i1+ORn2Le+FTX7EprhDDBvmovnDLHOe6pf3n7ObmvM5Gm4N8Lbfu7J//8QAKhABAAECAwYHAQEBAAAAAAAAAREAITFBcRAgQFFhgTCRobHB0fDh8XD/2gAIAQEAAT8Q/wCKgqAKuRURC5vsp9+lCr7UOLg0l81+P9UAZ+qPuj5P4M4p2OriB78UcTtcIu+qIAB5pK998BAI4iTUmjQWe31VggcBcdHhxDmjZOb19vDQixQ1nT/FPXhSYJuQ4LkfPin5ZLPJyaMuER4SLpA95/kVl4omlhLUw9Pbg+q48zQAAICx40ozIecezwf6XM8eDLz8GJVEAGAzNxQJUDm1/qUMwCddqgSoHWv9ShmALruCbIK0aEZBUHEjE4GEtjFYFXzmOXOCJqU4xil50Ig8il4rVdppuPLF0Pmgg57BMsSDg61Is8nJ0diVKR6NetwFS7CkphkzrKleEm7MeT2pEBEhEhHgPRvnZlSskAo0bnpsgrh0J0M6NBAyJjQy3X5mxEkqRk9Y7OJU6+VODo57GQMQNDH39Nv6XN4BbCkSYP00ZpAUHKSayqIQkSlk5NQqI8jDQyrLwFL1kklLjM3ElNP7QYQUBWVBqiYWBHTnTOFSquKvAyNEYEPQjbbxcLWEzzl/nrwJ61bgYj4KO0AAOhwEbcMHM0akEZsYvq+/HFymJRwXIoIqN5QKsBdaUEjijB551hl5g86nAriqydvAJgESEc6iWcR6cu3jGALuvb42W3Vxcjm6GdY6TbO6r+KtiZ8nu1HEmTJ9UHdKkspqf7RAphGEdeTRvk5xfMT8eMLZ0E6N/usqVlYCqZGC9hHltmwTmS9gt60elNH7Sul6gx3EGU4rD9NNQeQbBomFGatATs4+mxYL0M4YbYTt1YaEfL4ykywycsnt90ZQUSJglICIFxgBj8eRnQSG+n6IJ1cvFiOBg4Q/v3TlHAybvI/ud+Wx+AUq0gbDYcjLx0eau3DRyp0eIHRoKS4XADBORR4iWK2Ii2A/ZhTzgjQzf3rNY8gkBlrgURUDgcDr1eBu1KSdrfG0p3o3DQRQBySsqsxkgOxf1ngpHN4Gj/nrtAL7hLjXX4SnYICTIZywe9IDBbBYDlX+9U7qZnZcMH12LBehYUwRDaOHBWhSrpRWrwUzo7QOfnG1dG7ByBgKa1ug5kL/AHZ+Do2+ofZ2GFQNRyhY9Nl3apC5hh9dthgl2Oxj8cC9CfILRs2Ogf2iG5d31UQUYAbJFhXOhkkpxN8cQvPpSBNSBSAOhsBVUDBjZF9qz2IwuK5BDsAOfQocTeUu85oM4KApcockXVYpADNiSxkYVgjpL5Km5Jzh7KUkCJiJD4l1uMVYNWo/R2wds+9GBBgBBteAlYozi3xQn3i1Qbs7XUpCF51+M+qGExMq4rzd2T7AlSpMj5RREkiSO2GA9S5o5VbWans/dI0BhEhPBcrP+IOtESHANkbAXiRY5rh60kGt6XNy+6nendzrBOj6Px5VPTN5pl6e27gQOCXNeZUZIPn1N89LkTyM2g7gPPdEpSlDNfo96gOUuvNzfFGiShOlNT85kmT+67xudmSMUzN+BV12DF8/bduAkwCVXpUVXFJvE5a9fHaRBvyn6pMiBCOeR671votO+J57otygDq1hFkN0CspEsB06ubwIOcm4nR5jyomL7s8Er5M/vtuzJSMmrY+eNZhIkJSN4tDqZPluTMZnRw9OOiVYy1P57bYYYmE8paIRAADjiQ4sHnHsuz//2Q==", "base64");
                    fut.return({
                        statusCode: 200,
                        headers: {
                            "Content-Type": data.contentType
                        },
                        body: img
                    });
                }
                else {
                    var img = Buffer.from(data.data, "base64");
                    fut.return({
                        statusCode: 200,
                        headers: {
                            "Content-Type": data.contentType
                        },
                        body: img
                    });
                }
            });
        }
        else {
            fut.return({ err: "Permission denied" });
        }
        return fut.wait();
    }
});
Api.addRoute("office365/backlogin", { authRequired: false }, {
    get: function () {
        var state = this.queryParams.state;
        if (state === "backlogin") {
            return {
                statusCode: 302,
                headers: {
                    "Content-Type": "text/plain",
                    Location: getAuthUrlBack(state)
                },
                body: "Location: " + getAuthUrlBack(state)
            };
        }
        else {
            return "Error: Not valid Parameter";
        }
    }
});
Api.addRoute("office365/login", { authRequired: false }, {
    get: function () {
        var state = this.queryParams.state;
        var tempData = collections_1.Chalanges.findOne({ challange: state });
        if (typeof tempData === "undefined") {
            return "Error: Not valid Parameter";
        }
        var ch = collections_1.Chalanges.findOne({ challange: state }).state;
        if (typeof ch === "undefined") {
            return "Error: Not valid Parameter";
        }
        else if (typeof state === "undefined") {
            return "Error: Not valid Parameter";
        }
        else {
            return {
                statusCode: 302,
                headers: {
                    "Content-Type": "text/plain",
                    Location: getAuthUrl(ch)
                },
                body: "Location: " + getAuthUrl(ch)
            };
        }
    }
});
Api.addRoute("cb", { authRequired: false }, {
    get: function () {
        var fut = new Future();
        var code = this.queryParams.code;
        var state = this.queryParams.state;
        if (typeof code === "undefined") {
            return "Error: Not valid Parameter";
        }
        if (typeof state === "undefined") {
            return "Error: Not valid Parameter";
        }
        if (state === "backlogin") {
            getTokenFromCodeBacklogin(code).then(function (token) {
                fut.return({
                    statusCode: 302,
                    headers: {
                        "Content-Type": "text/html"
                    },
                    body: "<div>Login successful</div><script>\n            window.close();\n        </script>"
                });
            });
        }
        else {
            getTokenFromCode(code).then(function (token) {
                collections_1.Chalanges.update({
                    state: state
                }, {
                    $set: {
                        token: token
                    }
                })
                    .toPromise()
                    .then(function () {
                    fut.return({
                        statusCode: 302,
                        headers: {
                            "Content-Type": "text/html"
                        },
                        body: "<div>Login successful</div><script>\n            window.close();\n        </script>"
                    });
                });
            });
        }
        return fut.wait();
    }
});
function getAuthUrl(state) {
    var returnVal = oauth2.authorizationCode.authorizeURL({
        redirect_uri: process.env.ROOT_URL + "/api/cb",
        scope: "openid offline_access profile User.Read",
        state: state
    });
    return returnVal;
}
function getAuthUrlBack(state) {
    var returnVal = oauth2.authorizationCode.authorizeURL({
        redirect_uri: process.env.ROOT_URL + "/api/cb",
        scope: scopeBackend,
        state: state
    });
    return returnVal;
}
function getTokenFromCode(auth_code) {
    return new Promise(function (res, rej) {
        oauth2.authorizationCode
            .getToken({
            code: auth_code,
            redirect_uri: process.env.ROOT_URL + "/api/cb",
            scope: "openid profile User.Read"
        })
            .then(function (result) {
            var token = oauth2.accessToken.create(result);
            var user = jwt.decode(token.token.id_token);
            var tg = new RegExp(".*" + user.preferred_username.toLowerCase() + "*.", "i");
            var dat = collections_1.Users.findOne({
                mail: tg
            });
            if (typeof dat !== "undefined") {
                //https://outlook.office.com/api/v2.0/me/photo
                var options = {
                    headers: { authorization: "bearer " + token.token.access_token }
                };
                needle.get("https://graph.microsoft.com/v1.0/me/photos/120x120/$value", options, meteor_1.Meteor.bindEnvironment(function (err, resp) {
                    dat.photo =
                        "data:" +
                            resp.headers["content-type"] +
                            ";base64," +
                            resp.body.toString("base64");
                    for (var j in user) {
                        dat[j] = user[j];
                    }
                    collections_1.Users.update({
                        _id: dat._id
                    }, {
                        $set: dat
                    });
                    var stampedLoginToken = accounts_base_1.Accounts["_generateStampedLoginToken"]();
                    accounts_base_1.Accounts["_insertLoginToken"](dat._id, stampedLoginToken);
                    res(stampedLoginToken);
                }));
            }
            else {
                res(null);
            }
        });
    });
}
function getTokenFromCodeBacklogin(auth_code) {
    return new Promise(function (res, rej) {
        oauth2.authorizationCode
            .getToken({
            code: auth_code,
            redirect_uri: process.env.ROOT_URL + "/api/cb",
            scope: scopeBackend
        })
            .then(function (result) {
            var token = oauth2.accessToken.create(result);
            var user = jwt.decode(token.token.id_token);
            collections_1.Syncer.remove({})
                .toPromise()
                .then(function () {
                collections_1.Syncer.insert(token.token);
                res(null);
            });
        });
    });
}
/**
 * @api {get} /user Request User
 * @apiHeader {String} authorization Users unique access-key. apitoken myApiToken
 * @apiName GetUser
 * @apiGroup User
 *  @apiExample
 *  #Example Python Call
 *  import http.client
 connection = http.client.HTTPSConnection('pretradecheck.code-garage-solutions.de')
 headers={'authorization': 'apitoken myApiToken','content-Type':'application/json'}
 connection.request("GET", "/api/user",{},headers)
 response = connection.getresponse()
 print(response.read())
 connection.close()
 */

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var index_1 = require("./collections/index");
var office365_1 = require("/server/libModules/office365");
var moment = require("moment");
var timeouterInsertSheet;
var firstRun = true;
meteor_1.Meteor.startup(function () {
    index_1.Events.find({}).observeChanges({
        changed: meteor_1.Meteor.bindEnvironment(function (id, fields) {
            //createNewEventToSheet(id);
        }),
        added: meteor_1.Meteor.bindEnvironment(function (id, fields) {
            if (typeof timeouterUpdateSheet !== "undefined") {
                clearTimeout(timeouterUpdateSheet);
            }
            timeouterUpdateSheet = setTimeout(meteor_1.Meteor.bindEnvironment(function () {
                if (firstRun === true) {
                    firstRun = false;
                }
                else {
                    createNewEventToSheet(id);
                }
            }), 2000);
        }),
        removed: meteor_1.Meteor.bindEnvironment(function (id, fields) {
            // calcTableDataForEvents();
        })
    });
});
function createNewEventToSheet(id) {
    var ev = index_1.Events.findOne({ _id: id });
    var arr = [
        moment().format("DD.MM.YYYY"),
        ev.subject,
        ev.user.displayName,
        "",
        moment().format("MMM.YYYY"),
        ev._id
    ];
    var TeamData = index_1.Teams.find().cursor.fetch();
    for (var t = 0; t < TeamData.length; t++) {
        for (var u = 0; u < TeamData[t].userList.length; u++) {
            if (TeamData[t].userList[u].id === ev.user.id) {
                arr[3] = TeamData[t].displayName;
            }
        }
    }
    office365_1.createDataToSpreadsheetOneDrive("01RNJGBERZNFA6DGZWM5DL7UKFH62TWIGD", "data", arr, 6, arr.length).then(function (data) {
        console.log(data);
    });
}
function updateEventToSheet(id) {
    var ev = index_1.Events.findOne({ _id: id });
    var arr = [
        moment().format("DD.MM.YYYY"),
        ev.subject,
        ev.user.displayName,
        "",
        moment().format("MMM.YYYY"),
        ev._id
    ];
    var TeamData = index_1.Teams.find().cursor.fetch();
    for (var t = 0; t < TeamData.length; t++) {
        for (var u = 0; u < TeamData[t].userList.length; u++) {
            if (TeamData[t].userList[u].id === ev.user.id) {
                arr[3] = TeamData[t].displayName;
            }
        }
    }
}
var timeouterUpdateSheet;
function calcTableDataForEvents() {
    if (typeof timeouterUpdateSheet !== "undefined") {
        clearTimeout(timeouterUpdateSheet);
    }
    timeouterUpdateSheet = setTimeout(meteor_1.Meteor.bindEnvironment(function () {
        var dataList = [["datum", "ort", "mitarbeiterName", "abteilung"]];
        var TeamData = index_1.Teams.find().cursor.fetch();
        var startDate = moment()
            .startOf("day")
            .toDate();
        var endDate = moment()
            .add(6, "month")
            .toDate();
        var eventData = index_1.Events.find({
            $and: [
                { start: { $gt: startDate.toISOString() } },
                { start: { $lt: endDate.toISOString() } }
            ]
        }).cursor.fetch();
        console.log(eventData);
        var prom = [];
        while (startDate < endDate) {
            for (var t = 0; t < TeamData.length; t++) {
                for (var u = 0; u < TeamData[t].userList.length; u++) {
                    prom.push(searchEventInList(eventData, TeamData[t].userList[u], moment(startDate).format("DD.MM.YYYY"), TeamData[t].displayName));
                }
            }
            startDate = moment(startDate)
                .add(1, "day")
                .toDate();
        }
        console.log(prom.length);
        Promise.all(prom).then(function (data) {
            for (var i = 0; i < data.length; i++) {
                if (data[i].ort !== "Keine Daten Vorhanden") {
                    var uo = [];
                    for (var z in data[i]) {
                        uo.push(data[i][z]);
                    }
                    dataList.push(uo);
                }
            }
            office365_1.uploadDataToSpreadsheetOneDrive("01RNJGBERZNFA6DGZWM5DL7UKFH62TWIGD", "data", dataList, dataList.length, 4).then(function (data) {
                console.log(data);
            });
        });
    }), 2000);
}
function searchEventInList(events, user, date, abteilung) {
    return new Promise(function (res, rej) {
        var obj = {
            datum: date,
            ort: "Keine Daten Vorhanden",
            mitarbeiterName: user.displayName,
            abteilung: abteilung
        };
        for (var o = 0; o < events.length; o++) {
            if (events[o].user.id === user.id &&
                moment(date).isSame(new Date(events[o].start), "day") === true) {
                obj.ort = events[o].subject;
            }
        }
        res(obj);
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"node_modules":{"meteor":{"meteor.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/meteor.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = Package['meteor'];
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/mongo.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = Package['mongo'];
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"accounts-base.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/accounts-base.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = Package['accounts-base'];
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts"
  ]
});

require("/server/meteorMethods/general/index.js");
require("/server/meteorMethods/office365/index.js");
require("/server/meteorMethods/teams/index.js");
require("/server/collections/index.js");
require("/server/libModules/datagridmongohelper.js");
require("/server/libModules/loginHandler.js");
require("/server/libModules/office365.js");
require("/server/libModules/query.js");
require("/server/libModules/queryBuilder.js");
require("/server/libModules/reactiveaggregate.js");
require("/server/libModules/reactiveaggregateLoc.js");
require("/server/libModules/synchelper.js");
require("/server/puplications/challange.js");
require("/server/puplications/events.js");
require("/server/puplications/general.js");
require("/server/puplications/teams.js");
require("/server/puplications/users.js");
require("/server/rest/google.js");
require("/server/rest/office365.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGVvck1ldGhvZHMvZ2VuZXJhbC9pbmRleC50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGVvck1ldGhvZHMvb2ZmaWNlMzY1L2luZGV4LnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0ZW9yTWV0aG9kcy90ZWFtcy9pbmRleC50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbGxlY3Rpb25zL2luZGV4LnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbGliTW9kdWxlcy9kYXRhZ3JpZG1vbmdvaGVscGVyLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbGliTW9kdWxlcy9sb2dpbkhhbmRsZXIudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9saWJNb2R1bGVzL29mZmljZTM2NS50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2xpYk1vZHVsZXMvcXVlcnkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9saWJNb2R1bGVzL3F1ZXJ5QnVpbGRlci50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2xpYk1vZHVsZXMvcmVhY3RpdmVhZ2dyZWdhdGUudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9saWJNb2R1bGVzL3JlYWN0aXZlYWdncmVnYXRlTG9jLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbGliTW9kdWxlcy9zeW5jaGVscGVyLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHVwbGljYXRpb25zL2NoYWxsYW5nZS50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1cGxpY2F0aW9ucy9ldmVudHMudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdXBsaWNhdGlvbnMvZ2VuZXJhbC50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1cGxpY2F0aW9ucy90ZWFtcy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1cGxpY2F0aW9ucy91c2Vycy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3Jlc3QvZ29vZ2xlLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcmVzdC9vZmZpY2UzNjUudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLnRzIl0sIm5hbWVzIjpbIm9iamVjdGlmeSIsImEiLCJyb3dzIiwia2V5IiwibyIsInB1c2giLCJTdHJpbmciLCJwcm90b3R5cGUiLCJzdGFydHNXaXRoIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJlbnVtZXJhYmxlIiwiY29uZmlndXJhYmxlIiwid3JpdGFibGUiLCJ2YWx1ZSIsInNlYXJjaFN0cmluZyIsInBvc2l0aW9uIiwibGFzdEluZGV4T2YiLCJlbmRzV2l0aCIsInN1YmplY3RTdHJpbmciLCJ0b1N0cmluZyIsInVuZGVmaW5lZCIsImxlbmd0aCIsImxhc3RJbmRleCIsImluZGV4T2YiLCJRdWVyeSIsInNhdGlzZmllcyIsInJvdyIsImNvbnN0cmFpbnRzIiwiZ2V0dGVyIiwibGhzIiwiX3Jvd3NhdGlzZmllcyIsImpvaW4iLCJsZWZ0X3Jvd3MiLCJyaWdodF9yb3dzIiwibGVmdF9rZXkiLCJyaWdodF9rZXkiLCJsZWZ0S2V5Rm4iLCJyaWdodEtleUZuIiwicXVlcnkiLCJtZXRob2QiLCJvYmoiLCJmaWx0ZXIiLCJ2YWwiLCJyZXMiLCJyaHMiLCJfc2F0aXNmaWVzIiwiJGNvdW50IiwiY29uZGl0aW9uIiwiJGNvbnN0cmFpbnRzIiwibWFwIiwiYyIsInYiLCIkY29uc3RyYWludCIsIiRub3QiLCJjb25zdHJhaW50IiwiJG9yIiwiQXJyYXkiLCJpc0FycmF5IiwiaSIsIiRhbmQiLCIkbm9yIiwiJHdoZXJlIiwidmFsdWVzIiwicmVmIiwiZm4iLCJGdW5jdGlvbiIsImNhbGwiLCIkY2IiLCJwYXJlbnRLZXkiLCJKU09OIiwicGFyc2UiLCJlIiwiUmVnRXhwIiwiJHJlZ2V4IiwiJGluIiwiRGF0ZSIsIiRlcSIsImdldFRpbWUiLCIkb3B0aW9ucyIsIiRudWxsIiwiJGV4aXN0cyIsIiRkZWVwRXF1YWxzIiwiXyIsImlzRXF1YWwiLCJzdHJpbmdpZnkiLCIkbmUiLCJFcnJvciIsInJlc3VsdCIsIiRsaWtlSSIsInRvTG93ZXJDYXNlIiwiJGxpa2UiLCIkc3RhcnRzV2l0aCIsIiRlbmRzV2l0aCIsIiRlbGVtTWF0Y2giLCIkY29udGFpbnMiLCIkbmluIiwidGVzdCIsIiRndGUiLCJzZWxmIiwiZXZlcnkiLCJyZXNvbHZlIiwiJGd0IiwiJGx0IiwiJGx0ZSIsIiRiZWZvcmUiLCIkYWZ0ZXIiLCIkdHlwZSIsIiRhbGwiLCIkc2l6ZSIsImtleXMiLCIkbW9kIiwiJGVxdWFsIiwiYXJndW1lbnRzIiwiJGJldHdlZW4iLCJ1bmRvdCIsInNwbGl0Iiwic3ViIiwiJGFueSIsInEiLCJ0b0pTT04iLCJtb2R1bGUiLCJleHBvcnRzIiwiZGVmaW5lIiwiYW1kIiwid2luZG93IiwiR0xPQkFMIiwiZ2xvYmFsIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSx3Q0FBdUM7QUFJdkMsc0NBQXdDO0FBQ3hDLElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvQixJQUFJLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFL0IsaURBQTBDO0FBQzFDLHNEQUFnRDtBQUVoRCxlQUFNLENBQUMsT0FBTyxDQUFDO0lBQ2IsWUFBWSxZQUFDLFlBQVk7UUFDdkIsSUFBTSxHQUFHLEdBQUcsSUFBSSxNQUFNLEVBQUUsQ0FBQztRQUN6QixNQUFNLENBQUMsR0FBRyxDQUNSLDZEQUE2RDtZQUMzRCxZQUFZLEVBQ2QsZUFBTSxDQUFDLGVBQWUsQ0FBQyxVQUFDLEtBQUssRUFBRSxRQUFRO1lBQ3JDLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxRQUFRLENBQUMsVUFBVSxJQUFJLEdBQUcsRUFBRTtnQkFDaEQsSUFBSSxLQUFLLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7Z0JBQ2hDLElBQUksaUJBQWlCLEdBQUcsd0JBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxFQUFFLENBQUM7Z0JBQ2pFLElBQUksS0FBSyxHQUFHLG1CQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsdUJBQXVCLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztnQkFDOUQsSUFBSSxPQUFPLEtBQUssS0FBSyxXQUFXLEVBQUU7b0JBQ2hDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO2lCQUN2QztxQkFBTTtvQkFDTCx3QkFBUSxDQUFDLG1CQUFtQixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO29CQUM1RCxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDO2lCQUNyRDthQUNGO2lCQUFNO2dCQUNMLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO2FBQ3ZDO1FBQ0gsQ0FBQyxDQUFDLENBQ0gsQ0FBQztRQUNGLE9BQU8sR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFDRCxrQkFBa0IsWUFBQyxRQUFRO1FBQ3pCLHdCQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUNELGlCQUFpQjtRQUNmLElBQUksTUFBTSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN4QixJQUFJLElBQUksR0FBRyxtQkFBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUM7UUFDL0IsbUJBQUssQ0FBQyxNQUFNLENBQ1Y7WUFDRSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU07U0FDakIsRUFDRDtZQUNFLElBQUksRUFBRSxJQUFJO1NBQ1gsQ0FDRixDQUFDO0lBQ0osQ0FBQztJQUNELFVBQVUsWUFBQyxNQUFNO1FBQ2YsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2QsSUFBSSxNQUFNLEtBQUssRUFBRSxFQUFFO1lBQ2pCLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDNUIsSUFBSSxHQUFHLEdBQUc7Z0JBQ1IsSUFBSSxFQUFFLEVBQUU7YUFDVCxDQUFDO1lBQ0YsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ25DLElBQUksR0FBRyxHQUFHLElBQUksTUFBTSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUNoRCxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUNmLEdBQUcsRUFBRTt3QkFDSCxFQUFFLGdCQUFnQixFQUFFLEdBQUcsRUFBRTt3QkFDekIsRUFBRSxtQkFBbUIsRUFBRSxHQUFHLEVBQUU7d0JBQzVCLEVBQUUsa0JBQWtCLEVBQUUsR0FBRyxFQUFFO3FCQUM1QjtpQkFDRixDQUFDLENBQUM7YUFDSjtZQUVELElBQUksR0FBRyxHQUFHLENBQUM7U0FDWjtRQUVELE9BQU8sbUJBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFO1lBQ3RCLE1BQU0sRUFBRTtnQkFDTixPQUFPLEVBQUUsQ0FBQztnQkFDVixNQUFNLEVBQUUsQ0FBQztnQkFDVCxHQUFHLEVBQUUsQ0FBQzthQUNQO1NBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNwQixDQUFDO0NBQ0YsQ0FBQyxDQUFDO0FBRUgsZ0JBQWdCLE1BQU07SUFDcEIsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO0lBQ2hCLElBQUksVUFBVSxHQUNaLGdFQUFnRSxDQUFDO0lBQ25FLElBQUksZ0JBQWdCLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQztJQUN6QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1FBQy9CLE1BQU0sSUFBSSxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLGdCQUFnQixDQUFDLENBQUMsQ0FBQztLQUMzRTtJQUNELE9BQU8sTUFBTSxDQUFDO0FBQ2hCLENBQUM7Ozs7Ozs7Ozs7Ozs7QUMzRkQsd0NBQXVDO0FBSXZDLHNDQUF3QztBQUN4QyxJQUFJLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDL0IsSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRS9CLHlEQU9vQztBQUVwQyxpREFBaUQ7QUFFakQsZUFBTSxDQUFDLE9BQU8sQ0FBQztJQUNiLFVBQVUsWUFBQyxJQUFJO1FBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsT0FBTztTQUNSO1FBQ0QsSUFBTSxHQUFHLEdBQUcsSUFBSSxNQUFNLEVBQUUsQ0FBQztRQUN6QixtQ0FBdUIsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFJO1lBQzNDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbkIsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBQ0QsdUJBQXVCLFlBQUMsSUFBSTtRQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixPQUFPO1NBQ1I7UUFDRCxJQUFNLEdBQUcsR0FBRyxJQUFJLE1BQU0sRUFBRSxDQUFDO1FBQ3pCLG1DQUF1QixDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFJO1lBQ25DLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbkIsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBQ0QsU0FBUyxZQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUk7UUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsT0FBTztTQUNSO1FBQ0QsSUFBTSxHQUFHLEdBQUcsSUFBSSxNQUFNLEVBQUUsQ0FBQztRQUN6QixxQkFBUyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNwQyxHQUFHLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDZixDQUFDLENBQUMsQ0FBQztRQUNILE9BQU8sR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFDRCxXQUFXLFlBQUMsSUFBSTtRQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2hCLE9BQU87U0FDUjtRQUNELElBQU0sR0FBRyxHQUFHLElBQUksTUFBTSxFQUFFLENBQUM7UUFDekIsY0FBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7YUFDaEIsU0FBUyxFQUFFO2FBQ1gsSUFBSSxDQUFDO1lBQ0osR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDTCxPQUFPLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBQ0QsU0FBUztRQUNQLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2hCLE9BQU87U0FDUjtRQUNELElBQU0sR0FBRyxHQUFHLElBQUksTUFBTSxFQUFFLENBQUM7UUFDekIsd0JBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBUztZQUMzQixHQUFHLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3hCLENBQUMsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUNELG9CQUFvQjtRQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixPQUFPO1NBQ1I7UUFDRCxJQUFNLEdBQUcsR0FBRyxJQUFJLE1BQU0sRUFBRSxDQUFDO1FBQ3pCLDZCQUFpQixFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFTO1lBQ2hDLEdBQUcsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDeEIsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBQ0Qsb0JBQW9CLFlBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLEtBQUs7UUFDeEQsSUFBTSxHQUFHLEdBQUcsSUFBSSxNQUFNLEVBQUUsQ0FBQztRQUN6Qix1QkFBVyxDQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBSTtZQUMxRCxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ25CLENBQUMsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDcEIsQ0FBQztDQUNGLENBQUMsQ0FBQztBQUNIOzs7Ozs7OztFQVFFOzs7Ozs7Ozs7Ozs7O0FDbEdGLHdDQUF1QztBQUt2QyxJQUFJLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDL0IsSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRS9CLGlEQUFpRDtBQUdqRCxlQUFNLENBQUMsT0FBTyxDQUFDO0lBQ2IsUUFBUTtRQUNOLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2hCLE9BQU87U0FDUjtRQUNELE9BQU8sbUJBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxZQUFZLFlBQUMsRUFBRTtRQUNiLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2hCLE9BQU87U0FDUjtRQUNELG1CQUFLLENBQUMsTUFBTSxDQUNWLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFDcEI7WUFDRSxJQUFJLEVBQUU7Z0JBQ0osTUFBTSxFQUFFLEVBQUU7YUFDWDtTQUNGLENBQ0YsQ0FBQztJQUNKLENBQUM7Q0FDRixDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUMvQkgsMkNBQThDO0FBRTlDLHdDQUF1QztBQUN2QyxzQ0FBcUM7QUFFeEIsYUFBSyxHQUFHLDZCQUFlLENBQUMsWUFBWSxDQUFNLGVBQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUV4RCxrQkFBVSxHQUFHLElBQUksYUFBSyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMzQyxhQUFLLEdBQUcsSUFBSSw2QkFBZSxDQUFDLFVBQVUsQ0FBTSxrQkFBVSxDQUFDLENBQUM7QUFFeEQsdUJBQWUsR0FBRyxJQUFJLGFBQUssQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDckQsa0JBQVUsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFNLHVCQUFlLENBQUMsQ0FBQztBQUVsRSxzQkFBYyxHQUFHLElBQUksYUFBSyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNuRCxpQkFBUyxHQUFHLElBQUksNkJBQWUsQ0FBQyxVQUFVLENBQU0sc0JBQWMsQ0FBQyxDQUFDO0FBRWhFLG1CQUFXLEdBQUcsSUFBSSxhQUFLLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzdDLGNBQU0sR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFNLG1CQUFXLENBQUMsQ0FBQztBQUUxRCxtQkFBVyxHQUFHLElBQUksYUFBSyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM3QyxjQUFNLEdBQUcsSUFBSSw2QkFBZSxDQUFDLFVBQVUsQ0FBTSxtQkFBVyxDQUFDLENBQUM7QUFFdkUsY0FBTSxDQUFDLEtBQUssQ0FBQztJQUNYLE1BQU0sWUFBQyxNQUFNLEVBQUUsR0FBRztRQUNoQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixPQUFPO1NBQ1I7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFDRCxNQUFNLFlBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsUUFBUTtRQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixPQUFPO1NBQ1I7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFDRCxNQUFNLFlBQUMsTUFBTSxFQUFFLEdBQUc7UUFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsT0FBTztTQUNSO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0NBQ0YsQ0FBQyxDQUFDO0FBQ0gsYUFBSyxDQUFDLEtBQUssQ0FBQztJQUNWLE1BQU0sWUFBQyxNQUFNLEVBQUUsR0FBRztRQUNoQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixPQUFPO1NBQ1I7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFDRCxNQUFNLFlBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsUUFBUTtRQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixPQUFPO1NBQ1I7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFDRCxNQUFNLFlBQUMsTUFBTSxFQUFFLEdBQUc7UUFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsT0FBTztTQUNSO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0NBQ0YsQ0FBQyxDQUFDO0FBQ0gsYUFBSyxDQUFDLEtBQUssQ0FBQztJQUNWLE1BQU0sWUFBQyxNQUFNLEVBQUUsR0FBRztRQUNoQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixPQUFPO1NBQ1I7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFDRCxNQUFNLFlBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsUUFBUTtRQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixPQUFPO1NBQ1I7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFDRCxNQUFNLFlBQUMsTUFBTSxFQUFFLEdBQUc7UUFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsT0FBTztTQUNSO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0NBQ0YsQ0FBQyxDQUFDO0FBQ0gsa0JBQVUsQ0FBQyxLQUFLLENBQUM7SUFDZixNQUFNLFlBQUMsTUFBTSxFQUFFLEdBQUc7UUFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsT0FBTztTQUNSO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBQ0QsTUFBTSxZQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLFFBQVE7UUFDbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsT0FBTztTQUNSO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBQ0QsTUFBTSxZQUFDLE1BQU0sRUFBRSxHQUFHO1FBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2hCLE9BQU87U0FDUjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztDQUNGLENBQUMsQ0FBQztBQUNILGlCQUFTLENBQUMsS0FBSyxDQUFDO0lBQ2QsTUFBTSxZQUFDLE1BQU0sRUFBRSxHQUFHO1FBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2hCLE9BQU87U0FDUjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUNELE1BQU0sWUFBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxRQUFRO1FBQ2xDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2hCLE9BQU87U0FDUjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUNELE1BQU0sWUFBQyxNQUFNLEVBQUUsR0FBRztRQUNoQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixPQUFPO1NBQ1I7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7Q0FDRixDQUFDLENBQUM7QUFDSCxjQUFNLENBQUMsS0FBSyxDQUFDO0lBQ1gsTUFBTSxZQUFDLE1BQU0sRUFBRSxHQUFHO1FBQ2hCLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDcEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsT0FBTztTQUNSO1FBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwQixPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFDRCxNQUFNLFlBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsUUFBUTtRQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixPQUFPO1NBQ1I7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFDRCxNQUFNLFlBQUMsTUFBTSxFQUFFLEdBQUc7UUFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsT0FBTztTQUNSO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0NBQ0YsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FDL0lILHdCQUErQixNQUFNLEVBQUUsYUFBYTtJQUNoRCxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7SUFFZCxJQUFJLE9BQU8sTUFBTSxLQUFLLFdBQVcsRUFBRTtRQUMvQixJQUFJLE1BQU0sS0FBSyxJQUFJLEVBQUU7WUFDakIsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQzNCLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO29CQUU3QixRQUFRLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFO3dCQUVoQyxLQUFLLFVBQVU7NEJBRVgsSUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUU5QyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dDQUNqQixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDO2dDQUNsQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQ0FDbEMsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO29DQUNiLEdBQUcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksTUFBTSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO29DQUN0RSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lDQUMxQjs2QkFFSjtpQ0FBTTtnQ0FDSCxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDOzZCQUMxRjs0QkFFRCxNQUFNO3dCQUNWLEtBQUssSUFBSTs0QkFDTCxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzs0QkFDeEQsTUFBTTt3QkFDVixPQUFPO3FCQUVWO2lCQUNKO3FCQUFNO29CQUNILElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUM7b0JBQ2xCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFFNUMsUUFBUSxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRTs0QkFDaEMsS0FBSyxVQUFVO2dDQUNYLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQ0FDOUMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0NBQ2xDLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztvQ0FDYixHQUFHLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztvQ0FDdEUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztpQ0FDMUI7Z0NBR0QsTUFBTTs0QkFDVixLQUFLLElBQUk7Z0NBQ0wsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0NBQ3hELE1BQU07NEJBQ1YsT0FBTzt5QkFDVjtxQkFDSjtpQkFDSjthQUNKO1NBQ0o7S0FDSjtJQUNELElBQUksYUFBYSxLQUFLLElBQUksRUFBRTtRQUN4QixPQUFPLGFBQWEsQ0FBQztLQUN4QjtTQUFNO1FBQ0gsT0FBTyxJQUFJLENBQUM7S0FDZjtBQUVMLENBQUM7QUFoRUQsd0NBZ0VDO0FBQ0QseUJBQWdDLElBQUk7SUFDaEMsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDO0lBQ25CLElBQUksT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtRQUNwQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssS0FBSyxFQUFFO1lBQ3ZCLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2hDO2FBQU07WUFDSCxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQ2pDO0tBQ0o7U0FBTTtRQUNILFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQ2hDO0lBQ0QsT0FBTyxTQUFTLENBQUM7QUFDckIsQ0FBQztBQVpELDBDQVlDO0FBRUQsb0JBQTJCLFVBQVUsRUFBRSxTQUFTO0lBQzVDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztJQUNkLElBQUksRUFBRSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDL0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7UUFDdkMsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDO1FBQ1osRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNmLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2hDLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUNmLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFDLFFBQVEsRUFBRSxJQUFJLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFDLENBQUM7WUFDdkUsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUN6QjtRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDakI7SUFDRCxPQUFPLElBQUksQ0FBQztBQUNoQixDQUFDO0FBZEQsZ0NBY0M7Ozs7Ozs7Ozs7Ozs7QUM3RkQsd0NBQXVDO0FBQ3ZDLHNEQUFnRDtBQUNoRCxJQUFJLENBQUMsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDO0FBQzdCLElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvQixzQ0FBeUM7QUFLekMsd0JBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLFFBQVEsRUFBRSxVQUFVLFdBQVc7SUFDOUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN0QixJQUFNLEdBQUcsR0FBRyxJQUFJLE1BQU0sRUFBRSxDQUFDO0lBQ3pCLElBQUksWUFBWSxHQUFHLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUV6QyxJQUFJLENBQUMsWUFBWSxFQUFFO1FBQ2pCLE9BQU8sU0FBUyxDQUFDO0tBQ2xCO0lBRUQsSUFBTSxhQUFhLEdBQUcsb0JBQW9CLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQ3pGLElBQUksQ0FBQyxhQUFhO1FBQ2hCLE1BQU0sSUFBSSxvQkFBb0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUcvQyxTQUFTLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFDLE9BQVc7UUFDcEQsSUFBRyxPQUFPLEtBQUssSUFBSSxFQUFDO1lBQ2xCLE1BQU0sSUFBSSxlQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSx5QkFBeUIsQ0FBQztTQUN2RDtRQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFdEIsSUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUMxRSxXQUFXLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFDLFFBQVk7WUFDdkQsV0FBVyxHQUFHO2dCQUNaLFdBQVcsRUFBRSxZQUFZLENBQUMsWUFBWTtnQkFDdEMsU0FBUyxFQUFFLFNBQVM7Z0JBQ3BCLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSzthQUNyQjtZQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDdEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDakMsSUFBTSxZQUFZLEdBQUcsZUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSx1QkFBdUIsRUFBRSxZQUFZLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztZQUMzRixPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQzFCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQztZQUNsQixJQUFJLFlBQVksRUFBRTtnQkFDaEIsTUFBTSxHQUFHLFlBQVksQ0FBQyxHQUFHLENBQUM7Z0JBQzFCLElBQUkscUJBQW1CLEdBQUcsRUFBRSxDQUFDO2dCQUM3QixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFDLEdBQUcsRUFBRSxHQUFHO29CQUMzQixxQkFBbUIsQ0FBQyxxQkFBbUIsR0FBSyxDQUFDLEdBQUcsR0FBRyxDQUFDO2dCQUN0RCxDQUFDLENBQUMsQ0FBQztnQkFDSCxJQUFHLE9BQU8sWUFBWSxDQUFDLFdBQVcsQ0FBQyxLQUFLLFdBQVcsRUFBQztvQkFDbEQscUJBQW1CLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDO2lCQUN2QztnQkFDRCxlQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsRUFBRTtvQkFDbkMsSUFBSSxFQUFFLHFCQUFtQjtpQkFFMUIsQ0FBQyxDQUFDO2FBRUo7aUJBQUk7Z0JBQ0gsTUFBTSxHQUFHLElBQUksQ0FBQzthQUNmO1lBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN0QixHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDakMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztJQUVILE9BQU8sR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDO0FBRUgsSUFBTSxXQUFXLEdBQUcsVUFBQyxXQUFXO0lBQzlCLE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBQyxHQUFHLEVBQUUsR0FBRztRQUMxQixNQUFNLENBQUMsR0FBRyxDQUNSLDZEQUE2RCxHQUFHLFdBQVcsRUFBRSxVQUFVLEtBQUssRUFBRSxRQUFRO1lBQ3BHLElBQUksQ0FBQyxLQUFLLElBQUksUUFBUSxDQUFDLFVBQVUsSUFBSSxHQUFHLEVBQUU7Z0JBQ3hDLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDcEI7aUJBQU07Z0JBQ0wsR0FBRyxDQUFDLElBQUksQ0FBQzthQUNWO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGLElBQU0sU0FBUyxHQUFHLFVBQUMsV0FBVztJQUM1QixPQUFPLElBQUksT0FBTyxDQUFDLFVBQUMsR0FBRyxFQUFFLEdBQUc7UUFDMUIsTUFBTSxDQUFDLEdBQUcsQ0FDUiw4REFBOEQsR0FBRyxXQUFXLEVBQUUsVUFBVSxLQUFLLEVBQUUsUUFBUTtZQUNyRyxJQUFJLENBQUMsS0FBSyxJQUFJLFFBQVEsQ0FBQyxVQUFVLElBQUksR0FBRyxFQUFFO2dCQUN4QyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3BCO2lCQUFNO2dCQUNMLEdBQUcsQ0FBQyxJQUFJLENBQUM7YUFDVjtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFFRixJQUFNLGdCQUFnQixHQUFHLFVBQUMsUUFBUSxFQUFFLE1BQU07SUFDeEMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFDLEdBQUcsRUFBRSxHQUFHO1FBQzFCLE1BQU0sQ0FBQyxJQUFJLENBQ1QsNENBQTRDLEVBQUU7WUFDNUMsSUFBSSxFQUFFLFFBQVE7WUFDZCxTQUFTLEVBQUUsTUFBTSxDQUFDLFFBQVE7WUFDMUIsYUFBYSxFQUFFLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztZQUM5QyxVQUFVLEVBQUUsb0JBQW9CO1NBQ2pDLEVBQUUsVUFBVSxLQUFLLEVBQUUsUUFBUTtZQUMxQixJQUFJLENBQUMsS0FBSyxJQUFJLFFBQVEsQ0FBQyxVQUFVLElBQUksR0FBRyxFQUFFO2dCQUN4QyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3BCO2lCQUFNO2dCQUNMLEdBQUcsQ0FBQyxJQUFJLENBQUM7YUFDVjtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUM1R0YsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFFNUIsSUFBSSxFQUFFLEdBQUcsT0FBTyxDQUFDLG1DQUFtQyxDQUFDLENBQUM7QUFDdEQsSUFBSSxZQUFZLEdBQ2Qsa0hBQWtILENBQUM7QUFDckgsSUFBTSxXQUFXLEdBQUc7SUFDbEIsTUFBTSxFQUFFO1FBQ04sRUFBRSxFQUFFLHNDQUFzQztRQUMxQyxNQUFNLEVBQUUsa0NBQWtDLENBQUMsa0NBQWtDO0tBQzlFO0lBQ0QsSUFBSSxFQUFFO1FBQ0osU0FBUyxFQUFFLG1DQUFtQztRQUM5QyxhQUFhLEVBQUUsNERBQTREO1FBQzNFLFNBQVMsRUFBRSx3REFBd0Q7S0FDcEU7Q0FDRixDQUFDO0FBQ0YsSUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUM1RCw4Q0FBb0Q7QUFDcEQsOENBQThDO0FBQzlDLElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvQixpQ0FBd0MsS0FBSztJQUMzQyxPQUFPLElBQUksT0FBTyxDQUFDLFVBQUMsSUFBSSxFQUFFLEdBQUc7UUFDM0IsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO1FBRWIsSUFBSSxFQUFFLEdBQUcsY0FBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDeEMsTUFBTSxDQUFDLFdBQVc7YUFDZixNQUFNLENBQUMsRUFBRSxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQzlDLE9BQU8sRUFBRTthQUNULElBQUksQ0FBQyxjQUFJO1lBQ1IsSUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQzVCLGNBQWMsRUFBRSxNQUFNO2dCQUN0QixZQUFZLEVBQUUsS0FBSztnQkFDbkIsWUFBWSxFQUFFLGNBQUk7b0JBQ2hCLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDdEMsQ0FBQzthQUNGLENBQUMsQ0FBQztZQUVILE1BQU07aUJBQ0gsR0FBRyxDQUNGLHdFQUF3RSxDQUN6RTtpQkFDQSxHQUFHLEVBQUU7aUJBQ0wsSUFBSSxDQUFDLGFBQUc7Z0JBQ1AsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ1osQ0FBQyxDQUFDO2lCQUNELEtBQUssQ0FBQyxhQUFHO2dCQUNSLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNaLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUE5QkQsMERBOEJDO0FBRUQsd0JBQStCLEVBQUU7SUFDL0IsT0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFDLEdBQUcsRUFBRSxHQUFHO1FBQzFCLDJCQUEyQjtRQUMzQixJQUFJLEVBQUUsR0FBRyxjQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN4QyxNQUFNLENBQUMsV0FBVzthQUNmLE1BQU0sQ0FBQyxFQUFFLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7YUFDOUMsT0FBTyxFQUFFO2FBQ1QsSUFBSSxDQUFDLGNBQUk7WUFDUixJQUFJLE9BQU8sR0FBRztnQkFDWixPQUFPLEVBQUUsRUFBRSxhQUFhLEVBQUUsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFO2FBQ2hFLENBQUM7WUFDRixFQUFFO1lBQ0YsTUFBTSxDQUFDLEdBQUcsQ0FDUix5Q0FBeUM7Z0JBQ3ZDLEVBQUU7Z0JBQ0Ysd0JBQXdCLEVBQzFCLE9BQU8sRUFDUCxNQUFNLENBQUMsZUFBZSxDQUFDLFVBQUMsR0FBRyxFQUFFLElBQUk7Z0JBQy9CLElBQUksT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXLEVBQUU7b0JBQzFDLEdBQUcsQ0FBQzt3QkFDRixLQUFLLEVBQUUsSUFBSTt3QkFDWCxXQUFXLEVBQUUsSUFBSTt3QkFDakIsSUFBSSxFQUFFLElBQUk7cUJBQ1gsQ0FBQyxDQUFDO2lCQUNKO3FCQUFNO29CQUNMLEdBQUcsQ0FBQzt3QkFDRixLQUFLLEVBQUUsS0FBSzt3QkFDWixXQUFXLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUM7d0JBQ3pDLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUM7cUJBQ25DLENBQUMsQ0FBQztpQkFDSjtZQUNILENBQUMsQ0FBQyxDQUNILENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQW5DRCx3Q0FtQ0M7QUFFRCx5Q0FDRSxLQUFLLEVBQ0wsUUFBUSxFQUNSLElBQUksRUFDSixhQUFhLEVBQ2IsVUFBVTtJQUVWLE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBQyxJQUFJLEVBQUUsR0FBRztRQUMzQixJQUFJLEdBQUcsR0FBRztZQUNSLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQztTQUNmLENBQUM7UUFDRixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2pCLElBQUksRUFBRSxHQUFHLGNBQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3hDLE1BQU0sQ0FBQyxXQUFXO2FBQ2YsTUFBTSxDQUFDLEVBQUUsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUM5QyxPQUFPLEVBQUU7YUFDVCxJQUFJLENBQUMsY0FBSTtZQUNSLElBQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUM1QixjQUFjLEVBQUUsTUFBTTtnQkFDdEIsWUFBWSxFQUFFLEtBQUs7Z0JBQ25CLFlBQVksRUFBRSxjQUFJO29CQUNoQixJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQ3RDLENBQUM7YUFDRixDQUFDLENBQUM7WUFDSCxNQUFNO2lCQUNILEdBQUcsQ0FDRixrQkFBa0I7Z0JBQ2hCLEtBQUs7Z0JBQ0wsdUJBQXVCO2dCQUN2QixRQUFRO2dCQUNSLFlBQVksQ0FDZjtpQkFDQSxHQUFHLEVBQUU7aUJBQ0wsSUFBSSxDQUFDLGVBQUs7Z0JBQ1QsTUFBTTtxQkFDSCxHQUFHLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxHQUFHLHlCQUF5QixDQUFDO3FCQUMzRCxJQUFJLENBQUM7b0JBQ0osY0FBYyxFQUFFLElBQUk7aUJBQ3JCLENBQUM7cUJBQ0QsSUFBSSxDQUFDLGFBQUc7b0JBQ1AsT0FBTyxDQUFDLEdBQUcsQ0FDVCxrQkFBa0I7d0JBQ2hCLEtBQUs7d0JBQ0wsdUJBQXVCO3dCQUN2QixRQUFRO3dCQUNSLG1CQUFtQjt3QkFDbkIsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQzt3QkFDcEIsR0FBRzt3QkFDSCxhQUFhLENBQUMsYUFBYSxDQUFDO3dCQUM1QixDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDO3dCQUM3QixJQUFJLENBQ1AsQ0FBQztvQkFDRixNQUFNO3lCQUNILEdBQUcsQ0FDRixrQkFBa0I7d0JBQ2hCLEtBQUs7d0JBQ0wsdUJBQXVCO3dCQUN2QixRQUFRO3dCQUNSLG1CQUFtQjt3QkFDbkIsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQzt3QkFDcEIsR0FBRzt3QkFDSCxhQUFhLENBQUMsYUFBYSxDQUFDO3dCQUM1QixDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDO3dCQUNwQixJQUFJLENBQ1A7eUJBQ0EsTUFBTSxDQUFDLHFCQUFxQixFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUM7eUJBQ3JDLEtBQUssQ0FBQyxHQUFHLENBQUM7eUJBQ1YsSUFBSSxDQUFDLGFBQUc7d0JBQ1AsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNaLENBQUMsQ0FBQzt5QkFDRCxLQUFLLENBQUMsYUFBRzt3QkFDUixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ1osQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQyxDQUFDO3FCQUNELEtBQUssQ0FBQyxhQUFHO29CQUNSLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDWixDQUFDLENBQUMsQ0FBQztZQUNQLENBQUMsQ0FBQztpQkFDRCxLQUFLLENBQUMsYUFBRztnQkFDUixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDWixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBbkZELDBFQW1GQztBQUNELHlDQUNFLEtBQUssRUFDTCxRQUFRLEVBQ1IsSUFBSSxFQUNKLFVBQVUsRUFDVixhQUFhO0lBRWIsT0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFDLElBQUksRUFBRSxHQUFHO1FBQzNCLElBQUksR0FBRyxHQUFHO1lBQ1IsTUFBTSxFQUFFLElBQUk7U0FDYixDQUFDO1FBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUM7UUFDdkQsSUFBSSxFQUFFLEdBQUcsY0FBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDeEMsTUFBTSxDQUFDLFdBQVc7YUFDZixNQUFNLENBQUMsRUFBRSxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQzlDLE9BQU8sRUFBRTthQUNULElBQUksQ0FBQyxjQUFJO1lBQ1IsSUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQzVCLGNBQWMsRUFBRSxNQUFNO2dCQUN0QixZQUFZLEVBQUUsS0FBSztnQkFDbkIsWUFBWSxFQUFFLGNBQUk7b0JBQ2hCLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDdEMsQ0FBQzthQUNGLENBQUMsQ0FBQztZQUNILE1BQU07aUJBQ0gsR0FBRyxDQUFDLGtCQUFrQixHQUFHLEtBQUssR0FBRyx5QkFBeUIsQ0FBQztpQkFDM0QsSUFBSSxDQUFDO2dCQUNKLGNBQWMsRUFBRSxJQUFJO2FBQ3JCLENBQUM7aUJBQ0QsSUFBSSxDQUFDLGFBQUc7Z0JBQ1AsTUFBTTtxQkFDSCxHQUFHLENBQ0Ysa0JBQWtCO29CQUNoQixLQUFLO29CQUNMLHVCQUF1QjtvQkFDdkIsUUFBUTtvQkFDUixxQkFBcUI7b0JBQ3JCLGFBQWEsQ0FBQyxhQUFhLENBQUM7b0JBQzVCLFVBQVU7b0JBQ1YsSUFBSSxDQUNQO3FCQUNBLE1BQU0sQ0FBQyxxQkFBcUIsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDO3FCQUNyQyxLQUFLLENBQUMsR0FBRyxDQUFDO3FCQUNWLElBQUksQ0FBQyxhQUFHO29CQUNQLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDWixDQUFDLENBQUM7cUJBQ0QsS0FBSyxDQUFDLGFBQUc7b0JBQ1IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNaLENBQUMsQ0FBQyxDQUFDO1lBQ1AsQ0FBQyxDQUFDO2lCQUNELEtBQUssQ0FBQyxhQUFHO2dCQUNSLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNaLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUF2REQsMEVBdURDO0FBRUQsdUJBQXVCLGFBQXFCO0lBQzFDLElBQUksRUFBRSxHQUFHO1FBQ1AsR0FBRztRQUNILEdBQUc7UUFDSCxHQUFHO1FBQ0gsR0FBRztRQUNILEdBQUc7UUFDSCxHQUFHO1FBQ0gsR0FBRztRQUNILEdBQUc7UUFDSCxHQUFHO1FBQ0gsR0FBRztRQUNILEdBQUc7UUFDSCxHQUFHO1FBQ0gsR0FBRztRQUNILEdBQUc7UUFDSCxHQUFHO1FBQ0gsR0FBRztRQUNILEdBQUc7UUFDSCxHQUFHO1FBQ0gsR0FBRztRQUNILEdBQUc7UUFDSCxHQUFHO1FBQ0gsR0FBRztRQUNILEdBQUc7UUFDSCxHQUFHO1FBQ0gsR0FBRztRQUNILEdBQUc7S0FDSixDQUFDO0lBRUYsSUFBSSxhQUFhLEdBQUcsRUFBRSxDQUFDLE1BQU0sRUFBRTtRQUM3QixPQUFPLEVBQUUsQ0FBQyxhQUFhLEdBQUcsQ0FBQyxDQUFDLENBQUM7S0FDOUI7U0FBTTtRQUNMLElBQUksTUFBTSxHQUFHLGFBQWEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDO1FBQ3ZDLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNqRCxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUM7UUFDWixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzdCLElBQUksQ0FBQyxLQUFLLElBQUksR0FBRyxDQUFDLEVBQUU7Z0JBQ2xCLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQzthQUMxQjtpQkFBTTtnQkFDTCxFQUFFLEdBQUcsRUFBRSxHQUFHLEdBQUcsQ0FBQzthQUNmO1NBQ0Y7S0FDRjtBQUNILENBQUM7QUFFRCxpQ0FBd0MsS0FBSyxFQUFFLFFBQVEsRUFBRSxJQUFJO0lBQzNELE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBQyxJQUFJLEVBQUUsR0FBRztRQUMzQixJQUFJLEdBQUcsR0FBRztZQUNSLE1BQU0sRUFBRTtnQkFDTixDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUM7Z0JBQ2pCLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQzthQUNsQjtTQUNGLENBQUM7UUFFRixJQUFJLEVBQUUsR0FBRyxjQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN4QyxNQUFNLENBQUMsV0FBVzthQUNmLE1BQU0sQ0FBQyxFQUFFLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7YUFDOUMsT0FBTyxFQUFFO2FBQ1QsSUFBSSxDQUFDLGNBQUk7WUFDUixJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDNUIsY0FBYyxFQUFFLE1BQU07Z0JBQ3RCLFlBQVksRUFBRSxLQUFLO2dCQUNuQixZQUFZLEVBQUUsY0FBSTtvQkFDaEIsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUN0QyxDQUFDO2FBQ0YsQ0FBQyxDQUFDO1lBQ0gsTUFBTTtpQkFDSCxHQUFHLENBQ0YsMkVBQTJFLENBQzVFO2lCQUNBLElBQUksQ0FBQztnQkFDSixjQUFjLEVBQUUsSUFBSTthQUNyQixDQUFDO2lCQUNELElBQUksQ0FBQyxhQUFHO2dCQUNQLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ2pCLE1BQU07cUJBQ0gsR0FBRyxDQUNGLG9HQUFvRyxDQUNyRztxQkFDQSxNQUFNLENBQUMscUJBQXFCLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQztxQkFDckMsS0FBSyxDQUFDLEdBQUcsQ0FBQztxQkFDVixJQUFJLENBQUMsYUFBRztvQkFDUCxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ1osQ0FBQyxDQUFDO3FCQUNELEtBQUssQ0FBQyxhQUFHO29CQUNSLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDWixDQUFDLENBQUMsQ0FBQztZQUNQLENBQUMsQ0FBQztpQkFDRCxLQUFLLENBQUMsYUFBRztnQkFDUixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDWixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBaERELDBEQWdEQztBQUVELG1CQUEwQixFQUFFLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJO0lBQzVDLE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBQyxJQUFJLEVBQUUsR0FBRztRQUMzQixJQUFJLEdBQUcsR0FBRztZQUNSLE9BQU8sRUFBRTtnQkFDUCxPQUFPLEVBQUUsTUFBTTtnQkFDZixJQUFJLEVBQUU7b0JBQ0osV0FBVyxFQUFFLE1BQU07b0JBQ25CLE9BQU8sRUFBRSxJQUFJO2lCQUNkO2dCQUNELFlBQVksRUFBRSxFQUFFO2dCQUNoQixZQUFZLEVBQUUsRUFBRTthQUNqQjtZQUNELGVBQWUsRUFBRSxPQUFPO1NBQ3pCLENBQUM7UUFDRixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNsQyxHQUFHLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUM7Z0JBQzVCLFlBQVksRUFBRTtvQkFDWixPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDZjthQUNGLENBQUMsQ0FBQztTQUNKO1FBQ0QsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDO2dCQUM1QixZQUFZLEVBQUU7b0JBQ1osT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQ2Y7YUFDRixDQUFDLENBQUM7U0FDSjtRQUVELElBQUksRUFBRSxHQUFHLGNBQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3hDLE1BQU0sQ0FBQyxXQUFXO2FBQ2YsTUFBTSxDQUFDLEVBQUUsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUM5QyxPQUFPLEVBQUU7YUFDVCxJQUFJLENBQUMsY0FBSTtZQUNSLElBQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUM1QixjQUFjLEVBQUUsTUFBTTtnQkFDdEIsWUFBWSxFQUFFLEtBQUs7Z0JBQ25CLFlBQVksRUFBRSxjQUFJO29CQUNoQixJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQ3RDLENBQUM7YUFDRixDQUFDLENBQUM7WUFFSCxNQUFNO2lCQUNILEdBQUcsQ0FBQyxjQUFjLENBQUM7aUJBQ25CLElBQUksQ0FBQyxHQUFHLENBQUM7aUJBQ1QsSUFBSSxDQUFDLGFBQUc7Z0JBQ1AsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ1osQ0FBQyxDQUFDO2lCQUNELEtBQUssQ0FBQyxhQUFHO2dCQUNSLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNaLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFyREQsOEJBcURDO0FBRUQscUJBQTRCLEtBQUssRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxLQUFLO0lBQy9ELE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBQyxJQUFJLEVBQUUsR0FBRztRQUMzQixJQUFJLEdBQUcsR0FBRztZQUNSLE9BQU8sRUFBRSxLQUFLO1lBQ2QsSUFBSSxFQUFFO2dCQUNKLFdBQVcsRUFBRSxNQUFNO2dCQUNuQixPQUFPLEVBQUUsV0FBVzthQUNyQjtZQUNELEtBQUssRUFBRTtnQkFDTCxRQUFRLEVBQUUsS0FBSztnQkFDZixRQUFRLEVBQUUsZUFBZTthQUMxQjtZQUNELEdBQUcsRUFBRTtnQkFDSCxRQUFRLEVBQUUsR0FBRztnQkFDYixRQUFRLEVBQUUsZUFBZTthQUMxQjtZQUNELFFBQVEsRUFBRSxJQUFJO1lBQ2QsU0FBUyxFQUFFO2dCQUNUO29CQUNFLFlBQVksRUFBRTt3QkFDWixPQUFPLEVBQUUsS0FBSztxQkFDZjtvQkFDRCxJQUFJLEVBQUUsVUFBVTtpQkFDakI7YUFDRjtTQUNGLENBQUM7UUFFRixJQUFJLEVBQUUsR0FBRyxjQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN4QyxNQUFNLENBQUMsV0FBVzthQUNmLE1BQU0sQ0FBQyxFQUFFLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7YUFDOUMsT0FBTyxFQUFFO2FBQ1QsSUFBSSxDQUFDLGNBQUk7WUFDUixJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDNUIsY0FBYyxFQUFFLE1BQU07Z0JBQ3RCLFlBQVksRUFBRSxLQUFLO2dCQUNuQixZQUFZLEVBQUUsY0FBSTtvQkFDaEIsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUN0QyxDQUFDO2FBQ0YsQ0FBQyxDQUFDO1lBRUgsTUFBTTtpQkFDSCxHQUFHLENBQUMsWUFBWSxDQUFDO2lCQUNqQixJQUFJLENBQUMsR0FBRyxDQUFDO2lCQUNULElBQUksQ0FBQyxhQUFHO2dCQUNQLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNaLENBQUMsQ0FBQztpQkFDRCxLQUFLLENBQUMsYUFBRztnQkFDUixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDWixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBbkRELGtDQW1EQztBQUNELG9CQUEyQixFQUFFO0lBQzNCLE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBQyxJQUFJLEVBQUUsR0FBRztRQUMzQixJQUFJLEVBQUUsR0FBRyxjQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN4QyxNQUFNLENBQUMsV0FBVzthQUNmLE1BQU0sQ0FBQyxFQUFFLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7YUFDOUMsT0FBTyxFQUFFO2FBQ1QsSUFBSSxDQUFDLGNBQUk7WUFDUixJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDNUIsY0FBYyxFQUFFLE1BQU07Z0JBQ3RCLFlBQVksRUFBRSxLQUFLO2dCQUNuQixZQUFZLEVBQUUsY0FBSTtvQkFDaEIsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUN0QyxDQUFDO2FBQ0YsQ0FBQyxDQUFDO1lBRUgsTUFBTTtpQkFDSCxHQUFHLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztpQkFDdkIsTUFBTSxFQUFFO2lCQUNSLElBQUksQ0FBQyxhQUFHO2dCQUNQLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNaLENBQUMsQ0FBQztpQkFDRCxLQUFLLENBQUMsYUFBRztnQkFDUixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDWixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBMUJELGdDQTBCQztBQUNELHFCQUE0QixFQUFFLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLEtBQUs7SUFDbkUsT0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFDLElBQUksRUFBRSxHQUFHO1FBQzNCLElBQUksR0FBRyxHQUFHO1lBQ1IsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUU7Z0JBQ0osV0FBVyxFQUFFLE1BQU07Z0JBQ25CLE9BQU8sRUFBRSxXQUFXO2FBQ3JCO1lBQ0QsS0FBSyxFQUFFO2dCQUNMLFFBQVEsRUFBRSxLQUFLO2dCQUNmLFFBQVEsRUFBRSxlQUFlO2FBQzFCO1lBQ0QsR0FBRyxFQUFFO2dCQUNILFFBQVEsRUFBRSxHQUFHO2dCQUNiLFFBQVEsRUFBRSxlQUFlO2FBQzFCO1lBQ0QsUUFBUSxFQUFFLElBQUk7WUFDZCxTQUFTLEVBQUU7Z0JBQ1Q7b0JBQ0UsWUFBWSxFQUFFO3dCQUNaLE9BQU8sRUFBRSxLQUFLO3FCQUNmO29CQUNELElBQUksRUFBRSxVQUFVO2lCQUNqQjthQUNGO1NBQ0YsQ0FBQztRQUVGLElBQUksRUFBRSxHQUFHLGNBQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3hDLE1BQU0sQ0FBQyxXQUFXO2FBQ2YsTUFBTSxDQUFDLEVBQUUsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUM5QyxPQUFPLEVBQUU7YUFDVCxJQUFJLENBQUMsY0FBSTtZQUNSLElBQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUM1QixjQUFjLEVBQUUsTUFBTTtnQkFDdEIsWUFBWSxFQUFFLEtBQUs7Z0JBQ25CLFlBQVksRUFBRSxjQUFJO29CQUNoQixJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQ3RDLENBQUM7YUFDRixDQUFDLENBQUM7WUFFSCxNQUFNO2lCQUNILEdBQUcsQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO2lCQUN2QixHQUFHLENBQUMsR0FBRyxDQUFDO2lCQUNSLElBQUksQ0FBQyxhQUFHO2dCQUNQLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNaLENBQUMsQ0FBQztpQkFDRCxLQUFLLENBQUMsYUFBRztnQkFDUixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDWixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBbkRELGtDQW1EQztBQUVEO0lBQ0UsT0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFDLElBQUksRUFBRSxHQUFHO1FBQzNCLElBQUksRUFBRSxHQUFHLGNBQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBRXhDLE1BQU0sQ0FBQyxXQUFXO2FBQ2YsTUFBTSxDQUFDLEVBQUUsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUM5QyxPQUFPLEVBQUU7YUFDVCxJQUFJLENBQUMsY0FBSTtZQUNSLElBQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUM1QixjQUFjLEVBQUUsTUFBTTtnQkFDdEIsWUFBWSxFQUFFLEtBQUs7Z0JBQ25CLFlBQVksRUFBRSxjQUFJO29CQUNoQixJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQ3RDLENBQUM7YUFDRixDQUFDLENBQUM7WUFDSCxNQUFNO2lCQUNILEdBQUcsQ0FBQyxTQUFTLENBQUM7aUJBRWQsR0FBRyxFQUFFO2lCQUNMLElBQUksQ0FBQyxhQUFHO2dCQUNQLElBQUksU0FBUyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7Z0JBQzFCLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztnQkFFZCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDekMsSUFDRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQy9DLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFFL0MsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7aUJBQ25EO2dCQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQUk7b0JBQ3pCLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDYixDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQztpQkFDRCxLQUFLLENBQUMsYUFBRztnQkFDUixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDWixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBeENELG9DQXdDQztBQUVELHdCQUF3QixLQUFLLEVBQUUsTUFBTTtJQUNuQyxPQUFPLElBQUksT0FBTyxDQUFDLFVBQUMsR0FBRyxFQUFFLEdBQUc7UUFDMUIsTUFBTTthQUNILEdBQUcsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDLEVBQUUsR0FBRyxVQUFVLENBQUM7YUFDdkMsR0FBRyxFQUFFO2FBQ0wsSUFBSSxDQUFDLGlCQUFPO1lBQ1gsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO1lBQ2IsSUFBSSxRQUFRLEdBQUcsRUFBRSxDQUFDO1lBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDckIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUM3QyxJQUFJLE9BQU8sT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLEVBQUU7b0JBQzNDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMzQixJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTt3QkFDN0MsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ2pDO2lCQUNGO2FBQ0Y7WUFDRCxLQUFLLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQztZQUNyQixLQUFLLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQztZQUMvQixHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDYixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVEO0lBQ0UsT0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFDLEdBQUcsRUFBRSxHQUFHO1FBQzFCLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFJO1lBQ3RCLElBQUksU0FBUyxHQUFHLGFBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQzlDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxtQkFBUztnQkFDdEMsSUFBSSxRQUFRLEdBQUcsYUFBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQzdDLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQztnQkFDbkIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ3pDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFDckQsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDO3dCQUNsQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTs0QkFDekMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO2dDQUNuRCxLQUFLLEdBQUcsSUFBSSxDQUFDOzZCQUNkO3lCQUNGO3dCQUNELElBQUksS0FBSyxLQUFLLEtBQUssRUFBRTs0QkFDbkIsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQzFDO3FCQUNGO2lCQUNGO2dCQUNELFVBQVUsQ0FBQyxRQUFRLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRTtvQkFDakMsR0FBRyxFQUFFLENBQUM7Z0JBQ1IsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBMUJELDhDQTBCQztBQUVELG9CQUFvQixRQUFRLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxFQUFFO0lBQ2hELElBQUksU0FBUyxDQUFDLE1BQU0sS0FBSyxLQUFLLEVBQUU7UUFDOUIsRUFBRSxFQUFFLENBQUM7S0FDTjtTQUFNO1FBQ0wsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ2xCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3hDLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFFO2dCQUMzQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUNiLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQztnQkFDM0MsT0FBTyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQ3ZDLGFBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO3FCQUNuRSxTQUFTLEVBQUU7cUJBQ1gsSUFBSSxDQUFDO29CQUNKLFVBQVUsQ0FBQyxRQUFRLEVBQUUsU0FBUyxFQUFFLEtBQUssR0FBRyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ2pELENBQUMsQ0FBQyxDQUFDO2FBQ047U0FDRjtRQUNELElBQUksS0FBSyxLQUFLLEtBQUssRUFBRTtZQUNuQixTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFFM0MsT0FBTyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDdkMsYUFBSyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzNCLFNBQVMsRUFBRTtpQkFDWCxJQUFJLENBQUM7Z0JBQ0osVUFBVSxDQUFDLFFBQVEsRUFBRSxTQUFTLEVBQUUsS0FBSyxHQUFHLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNqRCxDQUFDLENBQUM7aUJBQ0QsS0FBSyxDQUFDLGFBQUcsSUFBSyxDQUFDLENBQUMsQ0FBQztTQUNyQjtLQUNGO0FBQ0gsQ0FBQztBQUVELG9CQUFvQixTQUFTLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxFQUFFO0lBQ2pELElBQUksU0FBUyxDQUFDLE1BQU0sS0FBSyxLQUFLLEVBQUU7UUFDOUIsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0tBQ2Y7U0FBTTtRQUNMLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsS0FBSyxTQUFTLEVBQUU7WUFDN0MsVUFBVSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsS0FBSyxHQUFHLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUVoRCxPQUFPO1NBQ1I7UUFFRCxJQUFJLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbEIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDekMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUU7Z0JBQzVDLEtBQUssR0FBRyxJQUFJLENBQUM7Z0JBQ2IsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUMzQyxhQUFLLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztxQkFDbkUsU0FBUyxFQUFFO3FCQUNYLElBQUksQ0FBQztvQkFDSixVQUFVLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxLQUFLLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNsRCxDQUFDLENBQUMsQ0FBQzthQUNOO1NBQ0Y7UUFDRCxJQUFJLEtBQUssS0FBSyxLQUFLLEVBQUU7WUFDbkIsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQzNDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO1lBQ25DLE9BQU8sU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztZQUNqQyxPQUFPLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxhQUFhLENBQUM7WUFFdEMsYUFBSyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzNCLFNBQVMsRUFBRTtpQkFDWCxJQUFJLENBQUM7Z0JBQ0osVUFBVSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsS0FBSyxHQUFHLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNsRCxDQUFDLENBQUM7aUJBQ0QsS0FBSyxDQUFDLGFBQUcsSUFBSyxDQUFDLENBQUMsQ0FBQztTQUNyQjtLQUNGO0FBQ0gsQ0FBQzs7Ozs7Ozs7Ozs7O0FDbHFCRCxDQUFDLFlBQVk7QUFDVCxXQUFTQSxTQUFULENBQW1CQyxDQUFuQixFQUFzQjtBQUNwQixRQUFJQyxJQUFJLEdBQUcsRUFBWDs7QUFDQSxTQUFLLElBQUlDLEdBQVQsSUFBZ0JGLENBQWhCLEVBQW1CO0FBQ2pCLFVBQUlHLENBQUMsR0FBRyxFQUFSO0FBQ0FBLE9BQUMsQ0FBQ0QsR0FBRCxDQUFELEdBQVNGLENBQUMsQ0FBQ0UsR0FBRCxDQUFWO0FBQ0FELFVBQUksQ0FBQ0csSUFBTCxDQUFVRCxDQUFWO0FBQ0Q7O0FBQ0QsV0FBT0YsSUFBUDtBQUNELEdBVFEsQ0FXWDs7O0FBQ0UsTUFBSSxDQUFDSSxNQUFNLENBQUNDLFNBQVAsQ0FBaUJDLFVBQXRCLEVBQWtDO0FBQ2hDQyxVQUFNLENBQUNDLGNBQVAsQ0FBc0JKLE1BQU0sQ0FBQ0MsU0FBN0IsRUFBd0MsWUFBeEMsRUFBc0Q7QUFDcERJLGdCQUFVLEVBQUUsS0FEd0M7QUFFcERDLGtCQUFZLEVBQUUsS0FGc0M7QUFHcERDLGNBQVEsRUFBRSxLQUgwQztBQUlwREMsV0FBSyxFQUFFLFVBQVVDLFlBQVYsRUFBd0JDLFFBQXhCLEVBQWtDO0FBQ3ZDQSxnQkFBUSxHQUFHQSxRQUFRLElBQUksQ0FBdkI7QUFDQSxlQUFPLEtBQUtDLFdBQUwsQ0FBaUJGLFlBQWpCLEVBQStCQyxRQUEvQixNQUE2Q0EsUUFBcEQ7QUFDRDtBQVBtRCxLQUF0RDtBQVNELEdBdEJRLENBd0JYOzs7QUFDRSxNQUFJLENBQUNWLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQlcsUUFBdEIsRUFBZ0M7QUFDOUJULFVBQU0sQ0FBQ0MsY0FBUCxDQUFzQkosTUFBTSxDQUFDQyxTQUE3QixFQUF3QyxVQUF4QyxFQUFvRDtBQUNsRE8sV0FBSyxFQUFFLFVBQVVDLFlBQVYsRUFBd0JDLFFBQXhCLEVBQWtDO0FBQ3ZDLFlBQUlHLGFBQWEsR0FBRyxLQUFLQyxRQUFMLEVBQXBCOztBQUNBLFlBQUlKLFFBQVEsS0FBS0ssU0FBYixJQUEwQkwsUUFBUSxHQUFHRyxhQUFhLENBQUNHLE1BQXZELEVBQStEO0FBQzdETixrQkFBUSxHQUFHRyxhQUFhLENBQUNHLE1BQXpCO0FBQ0Q7O0FBQ0ROLGdCQUFRLElBQUlELFlBQVksQ0FBQ08sTUFBekI7QUFDQSxZQUFJQyxTQUFTLEdBQUdKLGFBQWEsQ0FBQ0ssT0FBZCxDQUFzQlQsWUFBdEIsRUFBb0NDLFFBQXBDLENBQWhCO0FBQ0EsZUFBT08sU0FBUyxLQUFLLENBQUMsQ0FBZixJQUFvQkEsU0FBUyxLQUFLUCxRQUF6QztBQUNEO0FBVGlELEtBQXBEO0FBV0QsR0FyQ1EsQ0F1Q1Q7QUFDQTtBQUNBOzs7QUFFQSxNQUFJUyxLQUFLLEdBQUc7QUFFVkMsYUFBUyxFQUFFLFVBQVVDLEdBQVYsRUFBZUMsV0FBZixFQUE0QkMsTUFBNUIsRUFBb0M7QUFDN0MsYUFBT0osS0FBSyxDQUFDSyxHQUFOLENBQVVDLGFBQVYsQ0FBd0JKLEdBQXhCLEVBQTZCQyxXQUE3QixFQUEwQ0MsTUFBMUMsQ0FBUDtBQUNELEtBSlM7QUFNVkosU0FBSyxFQUFFLFVBQVVHLFdBQVYsRUFBdUJDLE1BQXZCLEVBQStCO0FBQ3BDLGFBQU8sVUFBVUYsR0FBVixFQUFlO0FBQ3BCLGVBQU9GLEtBQUssQ0FBQ0ssR0FBTixDQUFVQyxhQUFWLENBQXdCSixHQUF4QixFQUE2QkMsV0FBN0IsRUFBMENDLE1BQTFDLENBQVA7QUFDRCxPQUZEO0FBR0QsS0FWUztBQVlWRyxRQUFJLEVBQUUsVUFBVUMsU0FBVixFQUFxQkMsVUFBckIsRUFBaUNDLFFBQWpDLEVBQTJDQyxTQUEzQyxFQUFzRDtBQUMxRCxVQUFJQyxTQUFKLEVBQWVDLFVBQWY7QUFDQSxVQUFJLE9BQU9ILFFBQVAsSUFBbUIsUUFBdkIsRUFBaUNFLFNBQVMsR0FBRyxVQUFVVixHQUFWLEVBQWU7QUFDMUQsZUFBT0EsR0FBRyxDQUFDUSxRQUFELENBQVY7QUFDRCxPQUZnQyxDQUFqQyxLQUdLRSxTQUFTLEdBQUdGLFFBQVo7QUFFTCxVQUFJLENBQUNDLFNBQUwsRUFBZ0JFLFVBQVUsR0FBR0QsU0FBYjtBQUNoQixVQUFJLE9BQU9ELFNBQVAsSUFBb0IsUUFBeEIsRUFBa0NFLFVBQVUsR0FBRyxVQUFVWCxHQUFWLEVBQWU7QUFDNUQsZUFBT0EsR0FBRyxDQUFDUSxRQUFELENBQVY7QUFDRCxPQUZpQyxDQUFsQyxLQUdLRyxVQUFVLEdBQUdGLFNBQWI7QUFFTCxhQUFPSCxTQUFQO0FBQ0QsS0ExQlM7QUE0QlZNLFNBQUssRUFBRSxVQUFVckMsSUFBVixFQUFnQjBCLFdBQWhCLEVBQTZCQyxNQUE3QixFQUFxQztBQUMxQyxVQUFJLE9BQU9BLE1BQVAsSUFBaUIsUUFBckIsRUFBK0I7QUFDN0IsWUFBSVcsTUFBTSxHQUFHWCxNQUFiOztBQUNBQSxjQUFNLEdBQUcsVUFBVVksR0FBVixFQUFldEMsR0FBZixFQUFvQjtBQUMzQixpQkFBT3NDLEdBQUcsQ0FBQ0QsTUFBRCxDQUFILENBQVlyQyxHQUFaLENBQVA7QUFDRCxTQUZEO0FBR0Q7O0FBQ0QsVUFBSXVDLE1BQU0sR0FBRyxJQUFJakIsS0FBSyxDQUFDQSxLQUFWLENBQWdCRyxXQUFoQixFQUE2QkMsTUFBN0IsQ0FBYjtBQUNBLGFBQU8zQixJQUFJLENBQUN3QyxNQUFMLENBQVlBLE1BQVosQ0FBUDtBQUNELEtBckNTO0FBdUNWWixPQUFHLEVBQUU7QUFBRTtBQUVMO0FBQ0FDLG1CQUFhLEVBQUUsVUFBVUosR0FBVixFQUFlQyxXQUFmLEVBQTRCQyxNQUE1QixFQUFvQztBQUNqRCxhQUFLLElBQUkxQixHQUFULElBQWdCeUIsV0FBaEIsRUFBNkI7QUFDM0IsY0FBSSxLQUFLekIsR0FBTCxDQUFKLEVBQWU7QUFDYixnQkFBSSxDQUFDLEtBQUtBLEdBQUwsRUFBVXdCLEdBQVYsRUFBZUMsV0FBVyxDQUFDekIsR0FBRCxDQUExQixFQUFpQzBCLE1BQWpDLENBQUwsRUFBK0MsT0FBTyxLQUFQO0FBQ2hELFdBRkQsTUFHSztBQUNILGdCQUFJYyxHQUFHLEdBQUlkLE1BQU0sR0FBR0EsTUFBTSxDQUFDRixHQUFELEVBQU14QixHQUFOLENBQVQsR0FBc0J3QixHQUFHLENBQUN4QixHQUFELENBQTFDOztBQUNBLGdCQUFJeUMsR0FBRyxHQUFHLEtBQUtDLEdBQUwsQ0FBU0MsVUFBVCxDQUFvQkgsR0FBcEIsRUFBeUJmLFdBQVcsQ0FBQ3pCLEdBQUQsQ0FBcEMsRUFBMkNBLEdBQTNDLENBQVY7O0FBQ0EsZ0JBQUksQ0FBQ3lDLEdBQUwsRUFBVSxPQUFPLEtBQVA7QUFDWDtBQUNGOztBQUNELGVBQU8sSUFBUDtBQUNELE9BZkU7QUFpQkhHLFlBQU0sRUFBRSxVQUFVcEIsR0FBVixFQUFlcUIsU0FBZixFQUEwQm5CLE1BQTFCLEVBQWtDO0FBRXhDLFlBQUllLEdBQUcsR0FBR0ksU0FBUyxDQUFDQyxZQUFWLENBQXVCQyxHQUF2QixDQUEyQixVQUFVQyxDQUFWLEVBQWE7QUFDaEQsaUJBQU8xQixLQUFLLENBQUNDLFNBQU4sQ0FBZ0JDLEdBQWhCLEVBQXFCd0IsQ0FBckIsRUFBd0J0QixNQUF4QixDQUFQO0FBQ0QsU0FGUyxFQUVQYSxNQUZPLENBRUEsVUFBU1UsQ0FBVCxFQUFZO0FBQUMsaUJBQU9BLENBQVA7QUFBUyxTQUZ0QixFQUV3QjlCLE1BRmxDO0FBR0EsZUFBTyxLQUFLdUIsR0FBTCxDQUFTQyxVQUFULENBQW9CRixHQUFwQixFQUF5QkksU0FBUyxDQUFDSyxXQUFuQyxDQUFQO0FBQ0QsT0F2QkU7QUF5QkhDLFVBQUksRUFBRSxVQUFVM0IsR0FBVixFQUFlNEIsVUFBZixFQUEyQjFCLE1BQTNCLEVBQW1DO0FBQ3ZDLGVBQU8sQ0FBQyxLQUFLRSxhQUFMLENBQW1CSixHQUFuQixFQUF3QjRCLFVBQXhCLEVBQW9DMUIsTUFBcEMsQ0FBUjtBQUNELE9BM0JFO0FBNkJIMkIsU0FBRyxFQUFFLFVBQVU3QixHQUFWLEVBQWU0QixVQUFmLEVBQTJCMUIsTUFBM0IsRUFBbUM7QUFDdEMsWUFBSSxDQUFDNEIsS0FBSyxDQUFDQyxPQUFOLENBQWNILFVBQWQsQ0FBTCxFQUFnQztBQUM5QkEsb0JBQVUsR0FBR3ZELFNBQVMsQ0FBQ3VELFVBQUQsQ0FBdEI7QUFDRDs7QUFDRCxhQUFLLElBQUlJLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdKLFVBQVUsQ0FBQ2pDLE1BQS9CLEVBQXVDcUMsQ0FBQyxFQUF4QyxFQUE0QztBQUMxQyxjQUFJLEtBQUs1QixhQUFMLENBQW1CSixHQUFuQixFQUF3QjRCLFVBQVUsQ0FBQ0ksQ0FBRCxDQUFsQyxFQUF1QzlCLE1BQXZDLENBQUosRUFBb0QsT0FBTyxJQUFQO0FBQ3JEOztBQUNELGVBQU8sS0FBUDtBQUNELE9BckNFO0FBdUNIK0IsVUFBSSxFQUFFLFVBQVVqQyxHQUFWLEVBQWU0QixVQUFmLEVBQTJCMUIsTUFBM0IsRUFBbUM7QUFDdkMsWUFBSSxDQUFDNEIsS0FBSyxDQUFDQyxPQUFOLENBQWNILFVBQWQsQ0FBTCxFQUFnQztBQUM5QkEsb0JBQVUsR0FBR3ZELFNBQVMsQ0FBQ3VELFVBQUQsQ0FBdEI7QUFDRDs7QUFFRCxhQUFLLElBQUlJLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdKLFVBQVUsQ0FBQ2pDLE1BQS9CLEVBQXVDcUMsQ0FBQyxFQUF4QyxFQUE0QztBQUMxQyxjQUFJLENBQUMsS0FBSzVCLGFBQUwsQ0FBbUJKLEdBQW5CLEVBQXdCNEIsVUFBVSxDQUFDSSxDQUFELENBQWxDLEVBQXVDOUIsTUFBdkMsQ0FBTCxFQUFxRCxPQUFPLEtBQVA7QUFDdEQ7O0FBQ0QsZUFBTyxJQUFQO0FBQ0QsT0FoREU7QUFrREhnQyxVQUFJLEVBQUUsVUFBVWxDLEdBQVYsRUFBZTRCLFVBQWYsRUFBMkIxQixNQUEzQixFQUFtQztBQUN2QyxlQUFPLENBQUMsS0FBSzJCLEdBQUwsQ0FBUzdCLEdBQVQsRUFBYzRCLFVBQWQsRUFBMEIxQixNQUExQixDQUFSO0FBQ0QsT0FwREU7QUFzREhpQyxZQUFNLEVBQUUsVUFBVUMsTUFBVixFQUFrQkMsR0FBbEIsRUFBdUI7QUFDN0IsWUFBSUMsRUFBRSxHQUFJLE9BQU9ELEdBQVAsSUFBYyxRQUFmLEdBQTJCLElBQUlFLFFBQUosQ0FBYUYsR0FBYixDQUEzQixHQUErQ0EsR0FBeEQ7QUFDQSxZQUFJcEIsR0FBRyxHQUFHcUIsRUFBRSxDQUFDRSxJQUFILENBQVFKLE1BQVIsQ0FBVjtBQUNBLGVBQU9uQixHQUFQO0FBQ0QsT0ExREU7QUE2REhDLFNBQUcsRUFBRTtBQUFHO0FBRU51QixXQUFHLEVBQUUsVUFBVXRELEtBQVYsRUFBaUJ5QyxVQUFqQixFQUE2QmMsU0FBN0IsRUFBd0M7QUFDM0MsaUJBQU9kLFVBQVUsQ0FBQ3pDLEtBQUQsQ0FBakI7QUFDRCxTQUpFO0FBS0g7QUFDQWdDLGtCQUFVLEVBQUUsVUFBVWhDLEtBQVYsRUFBaUJ5QyxVQUFqQixFQUE2QmMsU0FBN0IsRUFBd0M7QUFHbEQsY0FBSWQsVUFBVSxLQUFLekMsS0FBbkIsRUFBMkIsT0FBTyxJQUFQOztBQUUzQixjQUFJLE9BQU9BLEtBQVAsS0FBZSxRQUFmLEtBQTZCQSxLQUFLLENBQUMsQ0FBRCxDQUFMLEtBQVcsR0FBWixJQUFxQkEsS0FBSyxDQUFDLENBQUQsQ0FBTCxLQUFXLEdBQTVELENBQUosRUFBd0U7QUFDdEUsZ0JBQUk7QUFDRixrQkFBSUEsS0FBSyxHQUFHd0QsSUFBSSxDQUFDQyxLQUFMLENBQVd6RCxLQUFYLENBQVo7QUFDRCxhQUZELENBR0EsT0FBTzBELENBQVAsRUFBVSxDQUFFO0FBQ2I7O0FBQ0QsY0FBSWpCLFVBQVUsWUFBWWtCLE1BQTFCLEVBQW1DLE9BQU8sS0FBS0MsTUFBTCxDQUFZNUQsS0FBWixFQUFtQnlDLFVBQW5CLENBQVAsQ0FBbkMsS0FDSyxJQUFJRSxLQUFLLENBQUNDLE9BQU4sQ0FBY0gsVUFBZCxDQUFKLEVBQWdDLE9BQU8sS0FBS29CLEdBQUwsQ0FBUzdELEtBQVQsRUFBZ0J5QyxVQUFoQixDQUFQLENBQWhDLEtBQ0EsSUFBSUEsVUFBVSxJQUFJLE9BQU9BLFVBQVAsS0FBc0IsUUFBeEMsRUFBa0Q7QUFDckQsZ0JBQUlBLFVBQVUsWUFBWXFCLElBQTFCLEVBQWdDLE9BQU8sS0FBS0MsR0FBTCxDQUFTL0QsS0FBVCxFQUFnQnlDLFVBQVUsQ0FBQ3VCLE9BQVgsRUFBaEIsQ0FBUCxDQUFoQyxLQUNLO0FBQ0gsa0JBQUl2QixVQUFVLENBQUNtQixNQUFmLEVBQXVCLE9BQU8sS0FBS0EsTUFBTCxDQUFZNUQsS0FBWixFQUFtQixJQUFJMkQsTUFBSixDQUFXbEIsVUFBVSxDQUFDbUIsTUFBdEIsRUFBOEJuQixVQUFVLENBQUN3QixRQUF6QyxDQUFuQixDQUFQOztBQUN2QixtQkFBSyxJQUFJNUUsR0FBVCxJQUFnQm9ELFVBQWhCLEVBQTRCO0FBQzFCLG9CQUFJLENBQUMsS0FBS3BELEdBQUwsQ0FBTCxFQUFpQixPQUFPLEtBQUswRSxHQUFMLENBQVMvRCxLQUFULEVBQWdCeUMsVUFBaEIsRUFBNEJjLFNBQTVCLENBQVAsQ0FBakIsS0FDSyxJQUFJLENBQUMsS0FBS2xFLEdBQUwsRUFBVVcsS0FBVixFQUFpQnlDLFVBQVUsQ0FBQ3BELEdBQUQsQ0FBM0IsRUFBa0NrRSxTQUFsQyxDQUFMLEVBQW9ELE9BQU8sS0FBUDtBQUMxRDs7QUFDRCxxQkFBTyxJQUFQO0FBQ0Q7QUFDRixXQVZJLE1BV0EsSUFBSVosS0FBSyxDQUFDQyxPQUFOLENBQWM1QyxLQUFkLENBQUosRUFBMEI7QUFDN0IsaUJBQUssSUFBSTZDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUc3QyxLQUFLLENBQUNRLE1BQTFCLEVBQWtDcUMsQ0FBQyxFQUFuQyxFQUNFLElBQUksS0FBS2tCLEdBQUwsQ0FBUy9ELEtBQUssQ0FBQzZDLENBQUQsQ0FBZCxFQUFtQkosVUFBbkIsQ0FBSixFQUFvQyxPQUFPLElBQVA7O0FBQ3RDLG1CQUFPLEtBQVA7QUFDRCxXQUpJLE1BS0EsSUFBSUEsVUFBVSxLQUFLLEVBQWYsSUFBcUJBLFVBQVUsS0FBSyxJQUFwQyxJQUE0Q0EsVUFBVSxLQUFLbEMsU0FBL0QsRUFBMkUsT0FBTyxLQUFLMkQsS0FBTCxDQUFXbEUsS0FBWCxDQUFQLENBQTNFLEtBQ0EsT0FBTyxLQUFLK0QsR0FBTCxDQUFTL0QsS0FBVCxFQUFnQnlDLFVBQWhCLENBQVA7QUFDTixTQXJDRTtBQXdDSHNCLFdBQUcsRUFBRSxVQUFVL0QsS0FBVixFQUFpQnlDLFVBQWpCLEVBQTZCO0FBQ2hDLGNBQUl6QyxLQUFLLEtBQUt5QyxVQUFkLEVBQTBCLE9BQU8sSUFBUCxDQUExQixLQUNLLElBQUlFLEtBQUssQ0FBQ0MsT0FBTixDQUFjNUMsS0FBZCxDQUFKLEVBQTBCO0FBQzdCLGlCQUFLLElBQUk2QyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHN0MsS0FBSyxDQUFDUSxNQUExQixFQUFrQ3FDLENBQUMsRUFBbkMsRUFDRSxJQUFJLEtBQUtrQixHQUFMLENBQVMvRCxLQUFLLENBQUM2QyxDQUFELENBQWQsRUFBbUJKLFVBQW5CLENBQUosRUFBb0MsT0FBTyxJQUFQOztBQUN0QyxtQkFBTyxLQUFQO0FBQ0QsV0FKSSxNQUtBLElBQUlBLFVBQVUsS0FBSyxJQUFmLElBQXVCQSxVQUFVLEtBQUtsQyxTQUF0QyxJQUFtRGtDLFVBQVUsS0FBSyxFQUF0RSxFQUEwRTtBQUM3RSxtQkFBTyxLQUFLeUIsS0FBTCxDQUFXbEUsS0FBWCxDQUFQO0FBQ0QsV0FGSSxNQUdBLElBQUlBLEtBQUssS0FBSyxJQUFWLElBQWtCQSxLQUFLLEtBQUssRUFBNUIsSUFBa0NBLEtBQUssS0FBS08sU0FBaEQsRUFBMkQsT0FBTyxLQUFQLENBQTNELENBQXlFO0FBQXpFLGVBQ0EsSUFBSVAsS0FBSyxZQUFZOEQsSUFBckIsRUFBMkI7QUFFOUIsa0JBQUlyQixVQUFVLFlBQVlxQixJQUExQixFQUFnQztBQUM5Qix1QkFBTzlELEtBQUssQ0FBQ2dFLE9BQU4sTUFBbUJ2QixVQUFVLENBQUN1QixPQUFYLEVBQTFCO0FBQ0QsZUFGRCxNQUdLLElBQUksT0FBT3ZCLFVBQVAsSUFBcUIsUUFBekIsRUFBbUM7QUFDdEMsdUJBQU96QyxLQUFLLENBQUNnRSxPQUFOLE1BQW1CdkIsVUFBMUI7QUFDRCxlQUZJLE1BR0EsSUFBSSxPQUFPQSxVQUFQLElBQXFCLFFBQXpCLEVBQW1DLE9BQU96QyxLQUFLLENBQUNnRSxPQUFOLE1BQW9CLElBQUlGLElBQUosQ0FBU3JCLFVBQVQsQ0FBRCxDQUF1QnVCLE9BQXZCLEVBQTFCO0FBQ3pDLGFBVEksTUFVQTtBQUNILHFCQUFPaEUsS0FBSyxJQUFJeUMsVUFBaEI7QUFDRDtBQUNEO0FBRUQsU0FsRUU7QUFxRUgwQixlQUFPLEVBQUUsVUFBVW5FLEtBQVYsRUFBaUJ5QyxVQUFqQixFQUE2QmMsU0FBN0IsRUFBd0M7QUFDL0MsaUJBQVF2RCxLQUFLLElBQUlPLFNBQVYsS0FBeUJrQyxVQUFVLElBQUksSUFBdkMsQ0FBUDtBQUNELFNBdkVFO0FBeUVIMkIsbUJBQVcsRUFBRSxVQUFVcEUsS0FBVixFQUFpQnlDLFVBQWpCLEVBQTZCO0FBQ3hDLGNBQUksT0FBTzRCLENBQVAsSUFBWSxXQUFaLElBQTJCLE9BQU9BLENBQUMsQ0FBQ0MsT0FBVCxJQUFvQixXQUFuRCxFQUFnRTtBQUM5RCxtQkFBT2QsSUFBSSxDQUFDZSxTQUFMLENBQWV2RSxLQUFmLEtBQXlCd0QsSUFBSSxDQUFDZSxTQUFMLENBQWU5QixVQUFmLENBQWhDLENBRDhELENBQ0Y7QUFDN0QsV0FGRCxNQUdLO0FBQ0gsbUJBQU80QixDQUFDLENBQUNDLE9BQUYsQ0FBVXRFLEtBQVYsRUFBaUJ5QyxVQUFqQixDQUFQO0FBQ0Q7QUFFRixTQWpGRTtBQW1GSEQsWUFBSSxFQUFFLFVBQVVTLE1BQVYsRUFBa0JSLFVBQWxCLEVBQThCO0FBQ2xDLGlCQUFPLENBQUMsS0FBS1QsVUFBTCxDQUFnQmlCLE1BQWhCLEVBQXdCUixVQUF4QixDQUFSO0FBRUQsU0F0RkU7QUF3RkgrQixXQUFHLEVBQUUsVUFBVXZCLE1BQVYsRUFBa0JSLFVBQWxCLEVBQThCO0FBQ2pDLGlCQUFPLENBQUMsS0FBS1QsVUFBTCxDQUFnQmlCLE1BQWhCLEVBQXdCUixVQUF4QixDQUFSO0FBQ0QsU0ExRkU7QUE0RkhNLFlBQUksRUFBRSxVQUFVRSxNQUFWLEVBQWtCUixVQUFsQixFQUE4QmMsU0FBOUIsRUFBeUM7QUFDN0MsaUJBQU8sQ0FBQyxLQUFLYixHQUFMLENBQVNPLE1BQVQsRUFBaUJSLFVBQWpCLEVBQTZCYyxTQUE3QixDQUFSO0FBQ0QsU0E5RkU7QUFnR0hULFlBQUksRUFBRSxVQUFVRyxNQUFWLEVBQWtCUixVQUFsQixFQUE4QmMsU0FBOUIsRUFBeUM7QUFFN0MsY0FBSSxDQUFDWixLQUFLLENBQUNDLE9BQU4sQ0FBY0gsVUFBZCxDQUFMLEVBQWdDO0FBQzlCLGtCQUFNLElBQUlnQyxLQUFKLENBQVUsOENBQVYsQ0FBTjtBQUNEOztBQUNELGVBQUssSUFBSTVCLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdKLFVBQVUsQ0FBQ2pDLE1BQS9CLEVBQXVDcUMsQ0FBQyxFQUF4QyxFQUE0QztBQUMxQyxnQkFBSWYsR0FBRyxHQUFHLEtBQUtFLFVBQUwsQ0FBZ0JpQixNQUFoQixFQUF3QlIsVUFBVSxDQUFDSSxDQUFELENBQWxDLEVBQXVDVSxTQUF2QyxDQUFWOztBQUNBLGdCQUFJLENBQUN6QixHQUFMLEVBQVUsT0FBTyxLQUFQO0FBQ1g7O0FBQ0QsaUJBQU8sSUFBUDtBQUNELFNBMUdFO0FBNEdIO0FBQ0FZLFdBQUcsRUFBRSxVQUFVTyxNQUFWLEVBQWtCUixVQUFsQixFQUE4QmMsU0FBOUIsRUFBeUM7QUFFNUMsY0FBSSxDQUFDWixLQUFLLENBQUNDLE9BQU4sQ0FBY0ssTUFBZCxDQUFMLEVBQTRCO0FBQzFCQSxrQkFBTSxHQUFHLENBQUNBLE1BQUQsQ0FBVDtBQUNEOztBQUVELGVBQUssSUFBSVgsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR1csTUFBTSxDQUFDekMsTUFBM0IsRUFBbUM4QixDQUFDLEVBQXBDLEVBQXdDO0FBQ3RDLGlCQUFLLElBQUlPLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdKLFVBQVUsQ0FBQ2pDLE1BQS9CLEVBQXVDcUMsQ0FBQyxFQUF4QyxFQUE0QztBQUMxQyxrQkFBSSxLQUFLYixVQUFMLENBQWdCaUIsTUFBTSxDQUFDWCxDQUFELENBQXRCLEVBQTJCRyxVQUFVLENBQUNJLENBQUQsQ0FBckMsRUFBMENVLFNBQTFDLENBQUosRUFBMEQ7QUFDeEQsdUJBQU8sSUFBUDtBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxpQkFBTyxLQUFQO0FBQ0QsU0E1SEU7O0FBOEhIOzs7OztBQUtBVyxhQUFLLEVBQUUsVUFBVWpCLE1BQVYsRUFBa0I7QUFDdkIsY0FBSXlCLE1BQUo7O0FBQ0EsY0FBSXpCLE1BQU0sS0FBSyxFQUFYLElBQWlCQSxNQUFNLEtBQUssSUFBNUIsSUFBb0NBLE1BQU0sS0FBSzFDLFNBQW5ELEVBQThEO0FBQzVELG1CQUFPLElBQVA7QUFDRCxXQUZELE1BR0ssSUFBSW9DLEtBQUssQ0FBQ0MsT0FBTixDQUFjSyxNQUFkLENBQUosRUFBMkI7QUFDOUIsaUJBQUssSUFBSVgsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR1csTUFBTSxDQUFDekMsTUFBM0IsRUFBbUM4QixDQUFDLEVBQXBDLEVBQXdDO0FBQ3RDLGtCQUFJLENBQUMsS0FBSzRCLEtBQUwsQ0FBV2pCLE1BQU0sQ0FBQ1gsQ0FBRCxDQUFqQixDQUFMLEVBQTRCO0FBQzFCLHVCQUFPLEtBQVA7QUFDRDtBQUNGOztBQUNELG1CQUFPLElBQVA7QUFDRCxXQVBJLE1BUUEsT0FBTyxLQUFQO0FBQ04sU0FqSkU7O0FBb0pIOzs7Ozs7QUFNQXVCLFdBQUcsRUFBRSxVQUFVWixNQUFWLEVBQWtCUixVQUFsQixFQUE4QjtBQUNqQyxjQUFJLENBQUNFLEtBQUssQ0FBQ0MsT0FBTixDQUFjSCxVQUFkLENBQUwsRUFBZ0MsTUFBTSxJQUFJZ0MsS0FBSixDQUFVLCtCQUFWLENBQU47QUFDaEMsY0FBSUMsTUFBTSxHQUFHLEtBQWI7O0FBQ0EsY0FBSSxDQUFDL0IsS0FBSyxDQUFDQyxPQUFOLENBQWNLLE1BQWQsQ0FBTCxFQUE0QjtBQUMxQkEsa0JBQU0sR0FBRyxDQUFDQSxNQUFELENBQVQ7QUFDRDs7QUFDRCxlQUFLLElBQUlYLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdXLE1BQU0sQ0FBQ3pDLE1BQTNCLEVBQW1DOEIsQ0FBQyxFQUFwQyxFQUF3QztBQUN0QyxnQkFBSVQsR0FBRyxHQUFHb0IsTUFBTSxDQUFDWCxDQUFELENBQWhCOztBQUNBLGlCQUFLLElBQUlPLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdKLFVBQVUsQ0FBQ2pDLE1BQS9CLEVBQXVDcUMsQ0FBQyxFQUF4QyxFQUE0QztBQUMxQyxrQkFBSUosVUFBVSxDQUFDL0IsT0FBWCxDQUFtQm1CLEdBQW5CLEtBQTJCLENBQTNCLElBQWdDLEtBQUtHLFVBQUwsQ0FBZ0JILEdBQWhCLEVBQXFCWSxVQUFVLENBQUNJLENBQUQsQ0FBL0IsQ0FBcEMsRUFBeUU7QUFDdkU2QixzQkFBTSxHQUFHLElBQVQ7QUFDQTtBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxpQkFBT0EsTUFBUDtBQUNELFNBM0tFO0FBNktIQyxjQUFNLEVBQUUsVUFBVTFCLE1BQVYsRUFBa0JSLFVBQWxCLEVBQThCO0FBQ3BDLGlCQUFPUSxNQUFNLENBQUMyQixXQUFQLEdBQXFCbEUsT0FBckIsQ0FBNkIrQixVQUE3QixLQUE0QyxDQUFuRDtBQUNELFNBL0tFO0FBaUxIb0MsYUFBSyxFQUFFLFVBQVU1QixNQUFWLEVBQWtCUixVQUFsQixFQUE4QjtBQUNuQyxpQkFBT1EsTUFBTSxDQUFDdkMsT0FBUCxDQUFlK0IsVUFBZixLQUE4QixDQUFyQztBQUNELFNBbkxFO0FBcUxIcUMsbUJBQVcsRUFBRSxVQUFVN0IsTUFBVixFQUFrQlIsVUFBbEIsRUFBOEI7QUFDekMsY0FBSSxDQUFDUSxNQUFMLEVBQWEsT0FBTyxLQUFQO0FBQ2IsaUJBQU9BLE1BQU0sQ0FBQ3ZELFVBQVAsQ0FBa0IrQyxVQUFsQixDQUFQO0FBQ0QsU0F4TEU7QUEwTEhzQyxpQkFBUyxFQUFFLFVBQVU5QixNQUFWLEVBQWtCUixVQUFsQixFQUE4QjtBQUN2QyxjQUFJLENBQUNRLE1BQUwsRUFBYSxPQUFPLEtBQVA7QUFDYixpQkFBT0EsTUFBTSxDQUFDN0MsUUFBUCxDQUFnQnFDLFVBQWhCLENBQVA7QUFDRCxTQTdMRTtBQStMSHVDLGtCQUFVLEVBQUUsVUFBVS9CLE1BQVYsRUFBa0JSLFVBQWxCLEVBQThCYyxTQUE5QixFQUF5QztBQUNuRCxlQUFLLElBQUlWLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdJLE1BQU0sQ0FBQ3pDLE1BQTNCLEVBQW1DcUMsQ0FBQyxFQUFwQyxFQUF3QztBQUN0QyxnQkFBSWxDLEtBQUssQ0FBQ0ssR0FBTixDQUFVQyxhQUFWLENBQXdCZ0MsTUFBTSxDQUFDSixDQUFELENBQTlCLEVBQW1DSixVQUFuQyxDQUFKLEVBQW9ELE9BQU8sSUFBUDtBQUNyRDs7QUFDRCxpQkFBTyxLQUFQO0FBQ0QsU0FwTUU7QUFzTUh3QyxpQkFBUyxFQUFFLFVBQVVoQyxNQUFWLEVBQWtCUixVQUFsQixFQUE4QjtBQUN2QyxpQkFBT1EsTUFBTSxDQUFDdkMsT0FBUCxDQUFlK0IsVUFBZixLQUE4QixDQUFyQztBQUNELFNBeE1FO0FBME1IeUMsWUFBSSxFQUFFLFVBQVVqQyxNQUFWLEVBQWtCUixVQUFsQixFQUE4QjtBQUNsQyxpQkFBTyxDQUFDLEtBQUtvQixHQUFMLENBQVNaLE1BQVQsRUFBaUJSLFVBQWpCLENBQVI7QUFDRCxTQTVNRTtBQThNSG1CLGNBQU0sRUFBRSxVQUFVWCxNQUFWLEVBQWtCUixVQUFsQixFQUE4QjtBQUNwQyxjQUFJaUMsTUFBTSxHQUFHLEtBQWI7O0FBQ0EsY0FBSS9CLEtBQUssQ0FBQ0MsT0FBTixDQUFjSyxNQUFkLENBQUosRUFBMkI7QUFDekIsaUJBQUssSUFBSUosQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0ksTUFBTSxDQUFDekMsTUFBM0IsRUFBbUNxQyxDQUFDLEVBQXBDLEVBQXdDO0FBQ3RDLGtCQUFJSixVQUFVLENBQUMwQyxJQUFYLENBQWdCbEMsTUFBTSxDQUFDSixDQUFELENBQXRCLENBQUosRUFBZ0M7QUFDOUIsdUJBQU8sSUFBUDtBQUNEO0FBQ0Y7QUFDRixXQU5ELE1BT0ssT0FBT0osVUFBVSxDQUFDMEMsSUFBWCxDQUFnQmxDLE1BQWhCLENBQVA7QUFFTixTQXpORTtBQTJOSG1DLFlBQUksRUFBRSxVQUFVbkMsTUFBVixFQUFrQkMsR0FBbEIsRUFBdUI7QUFFM0IsY0FBSVAsS0FBSyxDQUFDQyxPQUFOLENBQWNLLE1BQWQsQ0FBSixFQUEyQjtBQUN6QixnQkFBSW9DLElBQUksR0FBRyxJQUFYO0FBQ0EsbUJBQU9wQyxNQUFNLENBQUNxQyxLQUFQLENBQWEsVUFBU2hELENBQVQsRUFBWTtBQUFFLHFCQUFPK0MsSUFBSSxDQUFDRCxJQUFMLENBQVU5QyxDQUFWLEVBQWFZLEdBQWIsQ0FBUDtBQUF5QixhQUFwRCxDQUFQO0FBQ0Q7O0FBRUQsaUJBQU8sQ0FBQyxLQUFLZ0IsS0FBTCxDQUFXakIsTUFBWCxDQUFELElBQXVCQSxNQUFNLElBQUksS0FBS3NDLE9BQUwsQ0FBYXJDLEdBQWIsQ0FBeEM7QUFDRCxTQW5PRTtBQXFPSHNDLFdBQUcsRUFBRSxVQUFVdkMsTUFBVixFQUFrQkMsR0FBbEIsRUFBdUI7QUFDMUIsY0FBSVAsS0FBSyxDQUFDQyxPQUFOLENBQWNLLE1BQWQsQ0FBSixFQUEyQjtBQUN6QixnQkFBSW9DLElBQUksR0FBRyxJQUFYO0FBQ0EsbUJBQU9wQyxNQUFNLENBQUNxQyxLQUFQLENBQWEsVUFBU2hELENBQVQsRUFBWTtBQUFFLHFCQUFPK0MsSUFBSSxDQUFDRyxHQUFMLENBQVNsRCxDQUFULEVBQVlZLEdBQVosQ0FBUDtBQUF3QixhQUFuRCxDQUFQO0FBQ0Q7O0FBQ0QsaUJBQU8sQ0FBQyxLQUFLZ0IsS0FBTCxDQUFXakIsTUFBWCxDQUFELElBQXVCQSxNQUFNLEdBQUcsS0FBS3NDLE9BQUwsQ0FBYXJDLEdBQWIsQ0FBdkM7QUFDRCxTQTNPRTtBQTZPSHVDLFdBQUcsRUFBRSxVQUFVeEMsTUFBVixFQUFrQkMsR0FBbEIsRUFBdUI7QUFDMUIsY0FBSVAsS0FBSyxDQUFDQyxPQUFOLENBQWNLLE1BQWQsQ0FBSixFQUEyQjtBQUN6QixnQkFBSW9DLElBQUksR0FBRyxJQUFYO0FBQ0EsbUJBQU9wQyxNQUFNLENBQUNxQyxLQUFQLENBQWEsVUFBU2hELENBQVQsRUFBWTtBQUFFLHFCQUFPK0MsSUFBSSxDQUFDSSxHQUFMLENBQVNuRCxDQUFULEVBQVlZLEdBQVosQ0FBUDtBQUF3QixhQUFuRCxDQUFQO0FBQ0Q7O0FBQ0QsaUJBQU8sQ0FBQyxLQUFLZ0IsS0FBTCxDQUFXakIsTUFBWCxDQUFELElBQXVCQSxNQUFNLEdBQUcsS0FBS3NDLE9BQUwsQ0FBYXJDLEdBQWIsQ0FBdkM7QUFDRCxTQW5QRTtBQXFQSHdDLFlBQUksRUFBRSxVQUFVekMsTUFBVixFQUFrQkMsR0FBbEIsRUFBdUI7QUFDM0IsY0FBSVAsS0FBSyxDQUFDQyxPQUFOLENBQWNLLE1BQWQsQ0FBSixFQUEyQjtBQUN6QixnQkFBSW9DLElBQUksR0FBRyxJQUFYO0FBQ0EsbUJBQU9wQyxNQUFNLENBQUNxQyxLQUFQLENBQWEsVUFBU2hELENBQVQsRUFBWTtBQUFFLHFCQUFPK0MsSUFBSSxDQUFDSyxJQUFMLENBQVVwRCxDQUFWLEVBQWFZLEdBQWIsQ0FBUDtBQUF5QixhQUFwRCxDQUFQO0FBQ0Q7O0FBQ0QsaUJBQU8sQ0FBQyxLQUFLZ0IsS0FBTCxDQUFXakIsTUFBWCxDQUFELElBQXVCQSxNQUFNLElBQUksS0FBS3NDLE9BQUwsQ0FBYXJDLEdBQWIsQ0FBeEM7QUFDRCxTQTNQRTtBQThQSHlDLGVBQU8sRUFBRSxVQUFVMUMsTUFBVixFQUFrQkMsR0FBbEIsRUFBdUI7QUFDOUIsY0FBSSxPQUFPQSxHQUFQLEtBQWUsUUFBbkIsRUFBNkJBLEdBQUcsR0FBR1ksSUFBSSxDQUFDTCxLQUFMLENBQVdQLEdBQVgsQ0FBTjtBQUM3QixjQUFJLE9BQU9ELE1BQVAsS0FBa0IsUUFBdEIsRUFBZ0NBLE1BQU0sR0FBR2EsSUFBSSxDQUFDTCxLQUFMLENBQVdSLE1BQVgsQ0FBVDtBQUNoQyxpQkFBTyxLQUFLeUMsSUFBTCxDQUFVekMsTUFBVixFQUFrQkMsR0FBbEIsQ0FBUDtBQUNELFNBbFFFO0FBb1FIMEMsY0FBTSxFQUFFLFVBQVUzQyxNQUFWLEVBQWtCQyxHQUFsQixFQUF1QjtBQUM3QixjQUFJLE9BQU9BLEdBQVAsS0FBZSxRQUFuQixFQUE2QkEsR0FBRyxHQUFHWSxJQUFJLENBQUNMLEtBQUwsQ0FBV1AsR0FBWCxDQUFOO0FBQzdCLGNBQUksT0FBT0QsTUFBUCxLQUFrQixRQUF0QixFQUFnQ0EsTUFBTSxHQUFHYSxJQUFJLENBQUNMLEtBQUwsQ0FBV1IsTUFBWCxDQUFUO0FBRWhDLGlCQUFPLEtBQUttQyxJQUFMLENBQVVuQyxNQUFWLEVBQWtCQyxHQUFsQixDQUFQO0FBQ0QsU0F6UUU7QUEyUUgyQyxhQUFLLEVBQUUsVUFBVTVDLE1BQVYsRUFBa0JDLEdBQWxCLEVBQXVCO0FBQzVCLGlCQUFPLE9BQU9ELE1BQVAsSUFBaUJDLEdBQXhCO0FBQ0QsU0E3UUU7QUErUUg0QyxZQUFJLEVBQUUsVUFBVTdDLE1BQVYsRUFBa0JDLEdBQWxCLEVBQXVCO0FBQzNCLGdCQUFNLElBQUl1QixLQUFKLENBQVUsc0JBQVYsQ0FBTjtBQUNELFNBalJFO0FBbVJIc0IsYUFBSyxFQUFFLFVBQVU5QyxNQUFWLEVBQWtCQyxHQUFsQixFQUF1QjtBQUM1QixpQkFBUSxPQUFPRCxNQUFQLElBQWlCLFFBQWpCLEtBQThCQSxNQUFNLENBQUN6QyxNQUFQLElBQWlCMEMsR0FBakIsSUFBd0J2RCxNQUFNLENBQUNxRyxJQUFQLENBQVkvQyxNQUFaLEVBQW9CekMsTUFBcEIsSUFBOEIwQyxHQUFwRixDQUFSO0FBQ0QsU0FyUkU7QUF1UkgrQyxZQUFJLEVBQUUsVUFBVWhELE1BQVYsRUFBa0JDLEdBQWxCLEVBQXVCO0FBQzNCLGlCQUFPRCxNQUFNLEdBQUdDLEdBQUcsQ0FBQyxDQUFELENBQVosSUFBbUJBLEdBQUcsQ0FBQyxDQUFELENBQTdCO0FBQ0QsU0F6UkU7QUEwUkhnRCxjQUFNLEVBQUUsWUFBWTtBQUNsQixpQkFBTyxLQUFLbkMsR0FBTCxDQUFTb0MsU0FBVCxDQUFQO0FBQ0QsU0E1UkU7QUE2UkhDLGdCQUFRLEVBQUUsVUFBVW5ELE1BQVYsRUFBa0JDLEdBQWxCLEVBQXVCO0FBQy9CLGlCQUFPLEtBQUtsQixVQUFMLENBQWdCaUIsTUFBaEIsRUFBd0I7QUFBQ3VDLGVBQUcsRUFBRXRDLEdBQUcsQ0FBQyxDQUFELENBQVQ7QUFBY3VDLGVBQUcsRUFBRXZDLEdBQUcsQ0FBQyxDQUFEO0FBQXRCLFdBQXhCLENBQVA7QUFDRCxTQS9SRTtBQWdTSHFDLGVBQU8sRUFBRSxVQUFVckMsR0FBVixFQUFlO0FBQ3RCLGNBQUksT0FBT0EsR0FBUCxLQUFlLFFBQW5CLEVBQTZCO0FBQzNCLGdCQUFJQSxHQUFHLENBQUMsT0FBRCxDQUFQLEVBQWtCLE9BQU9ZLElBQUksQ0FBQ0wsS0FBTCxDQUFXUCxHQUFHLENBQUMsT0FBRCxDQUFkLENBQVA7QUFDbkI7O0FBQ0QsaUJBQU9BLEdBQVA7QUFDRDtBQXJTRTtBQTdERjtBQXZDSyxHQUFaLENBM0NTLENBeWJUOztBQUNBdkMsT0FBSyxDQUFDMEYsS0FBTixHQUFjLFVBQVUxRSxHQUFWLEVBQWV0QyxHQUFmLEVBQW9CO0FBQ2hDLFFBQUkyRyxJQUFJLEdBQUczRyxHQUFHLENBQUNpSCxLQUFKLENBQVUsR0FBVixDQUFYO0FBQUEsUUFBMkJDLEdBQUcsR0FBRzVFLEdBQWpDOztBQUNBLFNBQUssSUFBSWtCLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdtRCxJQUFJLENBQUN4RixNQUF6QixFQUFpQ3FDLENBQUMsRUFBbEMsRUFBc0M7QUFDcEMwRCxTQUFHLEdBQUdBLEdBQUcsQ0FBQ1AsSUFBSSxDQUFDbkQsQ0FBRCxDQUFMLENBQVQ7QUFDRDs7QUFDRCxXQUFPMEQsR0FBUDtBQUNELEdBTkQ7O0FBUUE1RixPQUFLLENBQUNLLEdBQU4sQ0FBVWUsR0FBVixDQUFjbUUsTUFBZCxHQUF1QnZGLEtBQUssQ0FBQ0ssR0FBTixDQUFVZSxHQUFWLENBQWNnQyxHQUFyQztBQUNBcEQsT0FBSyxDQUFDSyxHQUFOLENBQVVlLEdBQVYsQ0FBY3lFLElBQWQsR0FBcUI3RixLQUFLLENBQUNLLEdBQU4sQ0FBVWUsR0FBVixDQUFjVyxHQUFuQztBQUNBL0IsT0FBSyxDQUFDSyxHQUFOLENBQVVlLEdBQVYsQ0FBYytELElBQWQsR0FBcUJuRixLQUFLLENBQUNLLEdBQU4sQ0FBVWUsR0FBVixDQUFjZSxJQUFuQzs7QUFFQW5DLE9BQUssQ0FBQ0MsU0FBTixHQUFrQixVQUFVQyxHQUFWLEVBQWVDLFdBQWYsRUFBNEJDLE1BQTVCLEVBQW9DO0FBQ3BELFdBQU8sS0FBS0MsR0FBTCxDQUFTQyxhQUFULENBQXVCSixHQUF2QixFQUE0QkMsV0FBNUIsRUFBeUNDLE1BQXpDLENBQVA7QUFDRCxHQUZEOztBQUlBNEIsT0FBSyxDQUFDbEQsU0FBTixDQUFnQmdDLEtBQWhCLEdBQXdCLFVBQVVnRixDQUFWLEVBQWE7QUFDbkMsV0FBTzlGLEtBQUssQ0FBQ2MsS0FBTixDQUFZLElBQVosRUFBa0JnRixDQUFsQixDQUFQO0FBQ0QsR0FGRCxDQTFjUyxDQThjVDtBQUNBO0FBQ0E7OztBQUNBOUMsUUFBTSxDQUFDbEUsU0FBUCxDQUFpQmlILE1BQWpCLEdBQTBCL0MsTUFBTSxDQUFDbEUsU0FBUCxDQUFpQmEsUUFBM0M7QUFFQSxNQUFJLE9BQU9xRyxNQUFQLElBQWlCLFdBQXJCLEVBQWtDQSxNQUFNLENBQUNDLE9BQVAsR0FBaUJqRyxLQUFqQixDQUFsQyxLQUNLLElBQUksT0FBT2tHLE1BQVAsSUFBaUIsV0FBakIsSUFBZ0NBLE1BQU0sQ0FBQ0MsR0FBM0MsRUFBa0RELE1BQU0sQ0FBQyxPQUFELEVBQVUsRUFBVixFQUFjLFlBQVk7QUFDckYsV0FBT2xHLEtBQVA7QUFDRCxHQUY0RCxDQUFOLENBQWxELEtBR0EsSUFBSSxPQUFPb0csTUFBUCxJQUFpQixXQUFyQixFQUFrQ0EsTUFBTSxDQUFDcEcsS0FBUCxHQUFlQSxLQUFmLENBQWxDLEtBQ0EsSUFBSSxPQUFPcUcsTUFBUCxJQUFpQnpHLFNBQWpCLElBQThCeUcsTUFBTSxDQUFDQyxNQUF6QyxFQUFpREQsTUFBTSxDQUFDQyxNQUFQLENBQWN0RyxLQUFkLEdBQXNCQSxLQUF0QjtBQUV0RCxTQUFPQSxLQUFQO0FBQ0QsQ0EzZEgsRUEyZEssSUEzZEwsRTs7Ozs7Ozs7Ozs7O0FDQUEsNEJBQW1DLEtBQUs7SUFDdEMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFDLEdBQUcsRUFBRSxHQUFHO1FBQzFCLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzVCLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUNUO2FBQU07WUFDTCxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7WUFFYixJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7WUFFZixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzNDLEtBQUssQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDOUM7WUFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFJO2dCQUMxQixJQUFJLEtBQUssQ0FBQyxTQUFTLEtBQUssS0FBSyxFQUFFO29CQUM3QixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDO2lCQUNwQjtxQkFBTTtvQkFDTCxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDO2lCQUNuQjtnQkFDRCxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDWCxDQUFDLENBQUMsQ0FBQztTQUNKO0lBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBdEJELGdEQXNCQztBQUVELHFQQUFxUDtBQUNyUCwwQkFBMEIsSUFBSTtJQUM1QixPQUFPLElBQUksT0FBTyxDQUFDLFVBQUMsR0FBRyxFQUFFLEdBQUc7UUFDMUIsSUFBSSxPQUFPLElBQUksQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO1lBQ3pDLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztZQUNiLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUNmLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDMUMsS0FBSyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM3QztZQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQUk7Z0JBQzFCLElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLEVBQUU7b0JBQzVCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUM7aUJBQ3BCO3FCQUFNO29CQUNMLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUM7aUJBQ25CO2dCQUNELEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNYLENBQUMsQ0FBQyxDQUFDO1NBQ0o7YUFBTTtZQUNMLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztZQUNiLFFBQVEsSUFBSSxDQUFDLFFBQVEsRUFBRTtnQkFDckIsS0FBSyxRQUFRO29CQUNYLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQkFDN0IsTUFBTTtnQkFDUixLQUFLLGVBQWU7b0JBQ2xCLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQkFDN0IsTUFBTTtnQkFDUixLQUFLLFVBQVU7b0JBQ2IsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29CQUM3QixNQUFNO2dCQUNSLEtBQUssa0JBQWtCO29CQUNyQixHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0JBQzdCLE1BQU07Z0JBQ1IsS0FBSyxZQUFZO29CQUNmLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQkFDN0IsTUFBTTtnQkFDUixLQUFLLG9CQUFvQjtvQkFDdkIsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29CQUM3QixNQUFNO2dCQUNSLEtBQUssV0FBVztvQkFDZCxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0JBQzdCLE1BQU07Z0JBQ1IsS0FBSyxtQkFBbUI7b0JBQ3RCLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQkFDN0IsTUFBTTtnQkFDUixLQUFLLFFBQVE7b0JBQ1gsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29CQUM3QixNQUFNO2dCQUNSLEtBQUssaUJBQWlCO29CQUNwQixHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0JBQzdCLE1BQU07Z0JBQ1IsS0FBSyxJQUFJO29CQUNQLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQkFDN0IsTUFBTTtnQkFDUixLQUFLLFFBQVE7b0JBQ1gsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29CQUM3QixNQUFNO2dCQUNSLEtBQUssb0JBQW9CO29CQUN2QixHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0JBQzdCLE1BQU07Z0JBQ1IsS0FBSyxHQUFHO29CQUNOLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQkFDN0IsTUFBTTtnQkFDUixLQUFLLElBQUk7b0JBQ1AsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29CQUM3QixNQUFNO2dCQUNSLEtBQUssR0FBRztvQkFDTixHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0JBQzdCLE1BQU07Z0JBQ1IsS0FBSyxJQUFJO29CQUNQLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQkFDN0IsTUFBTTtnQkFDUixLQUFLLFVBQVU7b0JBQ2IsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29CQUM3QixNQUFNO2dCQUNSLEtBQUssa0JBQWtCO29CQUNyQixHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0JBQzdCLE1BQU07Z0JBQ1IsS0FBSyxPQUFPO29CQUNWLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztvQkFDN0IsTUFBTTthQUNUO1lBQ0QsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ1Y7SUFDSCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7Ozs7Ozs7Ozs7Ozs7QUM1R0Qsd0NBQXVDO0FBRXZDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUM5QixJQUFJLE9BQU8sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDakMsSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDLFdBQVcsQ0FBQztBQUNqQyxJQUFJLEdBQUcsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztBQUNoQyxJQUFJLEVBQUUsQ0FBQztBQUNQLElBQUksRUFBRSxHQUFHLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0FBQ3BDLElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQztBQUVyQixxQkFBcUIsYUFBYSxFQUFFLGVBQWUsRUFBRSxXQUFXLEVBQUUsVUFBVTtJQUMxRSxhQUFhLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFHO1FBQzlDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNsQyxlQUFlLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQ2pEO2FBQU07WUFDTCxlQUFlLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQ25EO1FBRUQsZUFBZSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsZUFBZSxDQUFDLFVBQVUsQ0FBQztJQUM3RCxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyw2Q0FBNkM7SUFFckQsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxFQUFFLFVBQUMsU0FBUyxFQUFFLEdBQUc7UUFDMUMsSUFBSSxTQUFTLElBQUksZUFBZSxDQUFDLFVBQVUsRUFBRTtZQUMzQyxPQUFPLGVBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDakMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FDMUM7SUFDSCxDQUFDLENBQUMsQ0FBQztJQUVILGVBQWUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztBQUMvQixDQUFDO0FBQ0QsSUFBSSxrQkFBa0IsR0FBRyxlQUFNLENBQUMsZUFBZSxDQUM3QyxVQUFDLGVBQWUsRUFBRSxhQUFhLEVBQUUsV0FBVyxFQUFFLFVBQVU7SUFDdEQsYUFBYSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQUc7UUFDbEQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ2xDLGVBQWUsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FDakQ7YUFBTTtZQUNMLGVBQWUsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FDbkQ7UUFFRCxlQUFlLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxlQUFlLENBQUMsVUFBVSxDQUFDO0lBQzdELENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLDZDQUE2QztJQUVyRCxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsVUFBQyxTQUFTLEVBQUUsR0FBRztRQUMxQyxJQUFJLFNBQVMsSUFBSSxlQUFlLENBQUMsVUFBVSxFQUFFO1lBQzNDLE9BQU8sZUFBZSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNqQyxlQUFlLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQztTQUMxQztJQUNILENBQUMsQ0FBQyxDQUFDO0lBRUgsZUFBZSxDQUFDLFVBQVUsRUFBRSxDQUFDO0FBQy9CLENBQUMsQ0FDRixDQUFDO0FBQ0YsSUFBSSxzQkFBc0IsR0FBRyxlQUFNLENBQUMsZUFBZSxDQUNqRCxVQUFDLGVBQWUsRUFBRSxhQUFhLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxLQUFLO0lBQzdELElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQ25ELElBQUksQ0FBQyxPQUFPLENBQUM7UUFDWCxNQUFNLEVBQUUsS0FBSztLQUNkLENBQUMsQ0FBQztJQUNILGFBQWEsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFHO1FBQzNDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNsQyxlQUFlLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQ2pEO2FBQU07WUFDTCxlQUFlLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQ25EO1FBQ0QsZUFBZSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsZUFBZSxDQUFDLFVBQVUsQ0FBQztJQUM3RCxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyw2Q0FBNkM7SUFDckQsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxFQUFFLFVBQUMsU0FBUyxFQUFFLEdBQUc7UUFDMUMsZUFBZSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxlQUFlLENBQUMsVUFBVSxDQUFDO0lBQ3pELENBQUMsQ0FBQyxDQUFDO0lBQ0g7Ozs7OztTQU1LO0lBRUwsZUFBZSxDQUFDLFVBQVUsRUFBRSxDQUFDO0FBQy9CLENBQUMsQ0FDRixDQUFDO0FBRUYsSUFBSSxjQUFjLEdBQUcsZUFBTSxDQUFDLGVBQWUsQ0FDekMsVUFDRSxjQUFjLEVBQ2QsZUFBZSxFQUNmLFdBQVcsRUFDWCxhQUFhLEVBQ2IsYUFBYTtJQUViLElBQUksYUFBYSxLQUFLLElBQUksRUFBRTtRQUMxQixJQUFJLGtCQUFrQixHQUFHLGFBQWEsQ0FBQyxLQUFLLENBQUM7WUFDM0M7Z0JBQ0UsTUFBTSxFQUFFLEVBQUU7YUFDWDtTQUNGLENBQUMsQ0FBQztRQUNILGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUU7WUFDOUIsSUFDRSxPQUFPLGVBQWUsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQztnQkFDdkQsV0FBVyxFQUNYO2dCQUNBLFlBQVksQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2FBQ2hFO1lBQ0QsZUFBZSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEdBQUcsVUFBVSxDQUFDO2dCQUM1RCxrQkFBa0IsQ0FDaEIsZUFBZSxFQUNmLGNBQWMsRUFDZCxXQUFXLEVBQ1gsYUFBYSxDQUNkLENBQUM7WUFDSixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDVixDQUFDLENBQUMsQ0FBQztRQUNILGVBQWUsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7S0FDMUQ7U0FBTTtRQUNMLElBQUksa0JBQWtCLEdBQUcsY0FBYyxDQUFDLEtBQUssQ0FBQztZQUM1QztnQkFDRSxNQUFNLEVBQUUsRUFBRTthQUNYO1NBQ0YsQ0FBQyxDQUFDO1FBQ0gsa0JBQWtCLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRSxhQUFHO1lBQ2pDLElBQUksR0FBRyxDQUFDLGFBQWEsS0FBSyxRQUFRLEVBQUU7Z0JBQ2xDLElBQ0UsT0FBTyxlQUFlLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssV0FBVyxFQUNoRTtvQkFDQSxPQUFPLGVBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDakQsZUFBZSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsR0FBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDN0Q7YUFDRjtpQkFBTTtnQkFDTCxJQUNFLE9BQU8sZUFBZSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDO29CQUN2RCxXQUFXLEVBQ1g7b0JBQ0EsWUFBWSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7aUJBQ2hFO2dCQUNELGVBQWUsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxHQUFHLFVBQVUsQ0FBQztvQkFDNUQsc0JBQXNCLENBQ3BCLGVBQWUsRUFDZixjQUFjLEVBQ2QsV0FBVyxFQUNYLGFBQWEsRUFDYixHQUFHLENBQUMsV0FBVyxDQUNoQixDQUFDO2dCQUNKLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQzthQUNUO1lBQ0QsZUFBZSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEdBQUcsVUFBVSxDQUFDO2dCQUM1RCxrQkFBa0IsQ0FDaEIsZUFBZSxFQUNmLGNBQWMsRUFDZCxXQUFXLEVBQ1gsYUFBYSxDQUNkLENBQUM7WUFDSixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDVixDQUFDLENBQUMsQ0FBQztRQUNILGVBQWUsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7S0FDMUQ7QUFDSCxDQUFDLENBQ0YsQ0FBQztBQUVGLGdDQUFnQyxlQUFlO0lBQzdDLE9BQU8sSUFBSSxPQUFPLENBQUUsZUFBTSxDQUFDLGVBQWUsQ0FBQyxVQUFDLEdBQUcsRUFBRSxHQUFHO1FBRWxELElBQUcsZUFBZSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEtBQUssSUFBSSxFQUFDO1lBRTdDLE1BQU0sQ0FBQyxPQUFPLENBQ1YsR0FBRyxFQUNIO2dCQUNFLGVBQWUsRUFBRSxJQUFJO2dCQUNyQixjQUFjLEVBQUUsRUFBRTtnQkFDbEIsaUJBQWlCLEVBQUUsSUFBSTtnQkFDdkIsZ0JBQWdCLEVBQUUsTUFBTTthQUN6QixFQUNELFVBQVMsR0FBRyxFQUFFLE1BQU07Z0JBQ2pCLGVBQWUsQ0FBQyxRQUFRLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQztnQkFDL0MsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRWxCLENBQUMsQ0FBQyxDQUFDO1NBQ047YUFBSTtZQUNELEdBQUcsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQzdDO0lBQ0wsQ0FBQyxDQUFDLENBQ0Q7QUFDRCxDQUFDO0FBQUEsQ0FBQztBQUVGLG9CQUFvQixlQUFlLEVBQUMsYUFBYSxFQUFDLFdBQVcsRUFBRSxhQUFhLEVBQUMsTUFBTTtJQU0vRSxlQUFlLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQztJQUNuQyxlQUFlLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztJQUNyQyxlQUFlLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztJQUNoQyxlQUFlLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDckQsSUFBSSxVQUFVLENBQUM7SUFDZixJQUFJLGFBQWEsS0FBSyxJQUFJLEVBQUU7UUFDMUIsVUFBVSxHQUFHLGFBQWEsQ0FBQyxLQUFLLENBQUM7S0FDbEM7U0FBTTtRQUNMLFVBQVUsR0FBRyxhQUFhLENBQUM7S0FDNUI7SUFDRCxlQUFlLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQztJQUMxQixlQUFlLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztJQUMvQixlQUFlLENBQUMsS0FBSyxFQUFFLENBQUM7SUFDeEIsV0FBVyxDQUNULGVBQWUsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsRUFDckQsZUFBZSxFQUNmLFdBQVcsRUFDWCxVQUFVLENBQ1gsQ0FBQztJQUNGLGNBQWMsQ0FDWixlQUFlLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLEVBQ3JELGVBQWUsRUFDZixXQUFXLEVBQ1gsVUFBVSxFQUNWLElBQUksQ0FDTCxDQUFDO0lBQ0YsV0FBVyxDQUFDLEdBQUcsQ0FBQyxlQUFLO1FBQ25CLElBQUksS0FBSyxDQUFDLE9BQU8sRUFBRTtZQUNqQixjQUFjLENBQ1osZUFBZSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxFQUNyRCxlQUFlLEVBQ2YsV0FBVyxFQUNYLFVBQVUsRUFDVixlQUFlLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUNyRCxDQUFDO1NBQ0g7SUFDSCxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUM7QUFFRCwwQkFBMEIsZUFBZSxFQUFDLGFBQWEsRUFBQyxXQUFXLEVBQUMsYUFBYTtJQUM3RSxJQUFJLGVBQWUsQ0FBQyxRQUFRLENBQUMsV0FBVyxLQUFLLElBQUksRUFBQztRQUM5QyxVQUFVLENBQUMsZUFBZSxFQUFDLGFBQWEsRUFBQyxXQUFXLEVBQUMsYUFBYSxFQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUM7S0FDNUc7U0FBSTtRQUNELFVBQVUsQ0FBQztZQUNQLGdCQUFnQixDQUFDLGVBQWUsRUFBQyxhQUFhLEVBQUMsV0FBVyxFQUFDLGFBQWEsQ0FBQztRQUM3RSxDQUFDLEVBQUMsR0FBRyxDQUFDLENBQUM7S0FDVjtBQUNMLENBQUM7QUFHRCw4QkFBcUMsZUFBZSxFQUNoRCxhQUFhLEVBQ2IsV0FBZ0IsRUFDaEIsYUFBYTtJQURiLDhDQUFnQjtJQUdaLElBQUcsT0FBTyxlQUFlLENBQUMsUUFBUSxDQUFDLFlBQVksS0FBSyxXQUFXLEVBQUM7UUFDNUQsZUFBZSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1FBQzdDLGVBQWUsQ0FBQyxRQUFRLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztRQUU1QyxlQUFlLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQzlCLE9BQU8sRUFDUCxlQUFNLENBQUMsZUFBZSxDQUFDO1lBQ3JCLElBQUcsZUFBZSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEtBQUssSUFBSSxFQUFFO2dCQUNoRCxlQUFlLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsQ0FBQzthQUM5QztRQUVILENBQUMsQ0FBQyxDQUNMLENBQUM7UUFFRixzQkFBc0IsQ0FBQyxlQUFlLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQU07WUFFL0MsVUFBVSxDQUFDLGVBQWUsRUFBQyxhQUFhLEVBQUMsV0FBVyxFQUFDLGFBQWEsRUFBQyxNQUFNLENBQUMsQ0FBQztRQUMvRSxDQUFDLENBQUMsQ0FBQztLQUNOO1NBQUk7UUFDRCxnQkFBZ0IsQ0FBQyxlQUFlLEVBQUMsYUFBYSxFQUFDLFdBQVcsRUFBQyxhQUFhLENBQUM7S0FDNUU7SUFHQyxlQUFlLENBQUMsTUFBTSxDQUFDO1FBQ3JCLElBQUk7WUFDRixJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDakIsSUFBSSxPQUFPLGVBQWUsQ0FBQyxlQUFlLEtBQUssV0FBVyxFQUFFO2dCQUMxRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsZUFBZSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQy9ELE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztvQkFFaEUsNERBQTREO2lCQUM3RDthQUNGO1NBQ0Y7UUFBQyxPQUFPLENBQUMsRUFBRTtZQUNWLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDaEI7UUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQztZQUN4QixJQUFJLE9BQU8sZUFBZSxDQUFDLFVBQVUsS0FBSyxXQUFXLEVBQUU7Z0JBQ3JELEtBQUssSUFBSSxDQUFDLElBQUksZUFBZSxDQUFDLFVBQVUsRUFBRTtvQkFDeEMsSUFBSSxPQUFPLGVBQWUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxFQUFFO3dCQUN4RCxZQUFZLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUM3QztpQkFDRjthQUNGO1lBQ0QsZUFBZSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDdkMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUViLENBQUM7QUF0REQsb0RBc0RDO0FBQUEsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ2xTRixJQUFJLENBQUMsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDOUIsSUFBSSxPQUFPLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2pDLElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUM7QUFDakMsSUFBSSxHQUFHLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7QUFDaEMsSUFBSSxFQUFFLENBQUM7QUFDUCxJQUFJLEVBQUUsR0FBRyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUNwQyxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7QUFFckIscUJBQXFCLGFBQWEsRUFBRSxlQUFlLEVBQUUsV0FBVyxFQUFFLFVBQVU7SUFDMUUsYUFBYSxDQUFDLGFBQWEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBRztRQUV0RixJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDbEMsZUFBZSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztTQUNqRDthQUFNO1lBQ0wsZUFBZSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztTQUNuRDtRQUVELGVBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxVQUFVLENBQUM7SUFDN0QsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsNkNBQTZDO0lBR3JELENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxVQUFDLFNBQVMsRUFBRSxHQUFHO1FBQzFDLElBQUksU0FBUyxJQUFJLGVBQWUsQ0FBQyxVQUFVLEVBQUU7WUFDM0MsT0FBTyxlQUFlLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2pDLGVBQWUsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQzFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDSCxlQUFlLENBQUMsVUFBVSxFQUFFLENBQUM7QUFDL0IsQ0FBQztBQVdELGlDQUF3QyxlQUFlLEVBQ3JELGFBQWEsRUFDYixXQUFnQixFQUNoQixhQUFhO0lBRGIsOENBQWdCO0lBR2hCLGVBQWUsQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO0lBQzFCLGVBQWUsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQy9CLGVBQWUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUN4QixJQUFJLEtBQUssR0FBRyxhQUFhLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUM7UUFDcEQsS0FBSyxFQUFFLFVBQUMsSUFBSTtZQUNWLFdBQVcsQ0FBQyxhQUFhLEVBQUUsZUFBZSxFQUFFLFdBQVcsRUFBRSxhQUFhLENBQUM7UUFDekUsQ0FBQztRQUNELE9BQU8sRUFBRSxVQUFDLElBQUk7WUFDWixXQUFXLENBQUMsYUFBYSxFQUFFLGVBQWUsRUFBRSxXQUFXLEVBQUUsYUFBYSxDQUFDO1FBQ3pFLENBQUM7UUFDRCxLQUFLLEVBQUUsVUFBQyxHQUFHO1lBQ1QsTUFBTSxHQUFHLENBQUM7UUFDWixDQUFDO0tBQ0YsQ0FBQyxDQUFDO0lBS0gsZUFBZSxDQUFDLE1BQU0sQ0FBQztRQUNyQixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDZixDQUFDLENBQUMsQ0FBQztBQUVMLENBQUM7QUEzQkQsMERBMkJDO0FBQUEsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ3BFRjtJQUNJLElBQUksUUFBUSxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRO0lBQzFDLElBQUksRUFBRSxHQUFHLElBQUksUUFBUSxFQUFFLENBQUM7SUFDeEIsT0FBTyxFQUFFLENBQUMsV0FBVyxFQUFFO0FBQzNCLENBQUM7QUFKRCxzQ0FJQzs7Ozs7Ozs7Ozs7OztBQ0pELHdDQUF1QztBQUN2QyxrREFDaUQ7QUFHakQsc0NBQXdDO0FBRXhDOztHQUVHO0FBQ0gsZUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsVUFBVSxTQUFTO0lBQW5CLGlCQWtCM0I7SUFqQkcsSUFBTSxHQUFHLEdBQUcsSUFBSSxNQUFNLEVBQUUsQ0FBQztJQUN6QixJQUFJLElBQUksR0FBRyxpQkFBUyxDQUFDLE1BQU0sQ0FBQztRQUN4QixTQUFTLEVBQUMsU0FBUztRQUNuQixLQUFLLEVBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNoQixLQUFLLEVBQUMsRUFBRTtLQUNYLENBQUMsQ0FBQztJQUNILElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBQyxDQUFDO1FBRXBCLEtBQUksQ0FBQyxNQUFNLENBQUM7WUFFUixpQkFBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDO1FBRUgsR0FBRyxDQUFDLE1BQU0sQ0FBQyxpQkFBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBQyxLQUFLLEVBQUMsQ0FBQyxFQUFDLEVBQUMsRUFBQyxNQUFNLEVBQUMsRUFBQyxLQUFLLEVBQUMsQ0FBQyxFQUFDLFNBQVMsRUFBQyxDQUFDLEVBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUVwRixDQUFDLENBQUMsQ0FBQztJQUNILE9BQU8sR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDO0FBRUgsZ0JBQWdCLE1BQU07SUFDbEIsSUFBSSxNQUFNLEdBQWEsRUFBRSxDQUFDO0lBQzFCLElBQUksVUFBVSxHQUFTLGdFQUFnRSxDQUFDO0lBQ3hGLElBQUksZ0JBQWdCLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQztJQUN6QyxLQUFNLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFHO1FBQ2hDLE1BQU0sSUFBSSxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLGdCQUFnQixDQUFDLENBQUMsQ0FBQztLQUM1RTtJQUNELE9BQU8sTUFBTSxDQUFDO0FBQ2pCLENBQUM7Ozs7Ozs7Ozs7Ozs7QUN0Q0Ysd0NBQXVDO0FBQ3ZDLDhDQUFnRTtBQVFoRSxlQUFNLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxVQUFTLEtBQUssRUFBRSxHQUFHLEVBQUUsT0FBTztJQUNuRCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtRQUNoQixPQUFPO0tBQ1I7SUFFRCxPQUFPLGNBQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUNmSCx3Q0FBdUM7QUFDdkMsa0RBQTZDO0FBQzdDLHlFQUF1RTtBQVF2RTs7R0FFRztBQUNILGVBQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFO0lBQ25CLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ2hCLE9BQU87S0FDUjtJQUVELElBQUksWUFBWSxHQUFHO1FBQ2pCO1lBQ0UsTUFBTSxFQUFFO2dCQUNOLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTTthQUNqQjtTQUNGO0tBQ0YsQ0FBQztJQUVGLHdDQUFvQixDQUFDLElBQUksRUFBRSxhQUFLLENBQUMsYUFBYSxDQUFDLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQ3ZFLENBQUMsQ0FBQyxDQUFDO0FBRUgsZUFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUU7SUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7UUFDaEIsT0FBTztLQUNSO0lBQ0QsSUFBSSxZQUFZLEdBQUc7UUFDakI7WUFDRSxNQUFNLEVBQUU7Z0JBQ04sZUFBZSxFQUFFLElBQUk7YUFDdEI7U0FDRjtLQUNGLENBQUM7SUFDRix3Q0FBb0IsQ0FBQyxJQUFJLEVBQUUsYUFBSyxDQUFDLGFBQWEsQ0FBQyxFQUFFLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQztBQUMvRSxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ3pDSCx3Q0FBdUM7QUFDdkMsa0RBQzRDO0FBQzVDLHlFQUF1RTtBQUl2RSxlQUFNLENBQUMsT0FBTyxDQUFDLG9CQUFvQixFQUFFLFVBQVUsSUFBSSxFQUFFLEtBQUssRUFBQyxNQUFNO0lBQzdELElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ2QsT0FBTztLQUNWO0lBQ0QsSUFBSSxZQUFZLEdBQUc7UUFDZjtZQUNJLFFBQVEsRUFBRSxFQUFFO1NBQ2Y7UUFDRDtZQUNJLE1BQU0sRUFBRTtnQkFDSixLQUFLLEVBQUUsSUFBSTtnQkFDWCxPQUFPLEVBQUU7b0JBQ0wsTUFBTSxFQUFFLEdBQUc7aUJBQ2Q7Z0JBQ0QsTUFBTSxFQUFFO29CQUNKLE9BQU8sRUFBRSxRQUFRO2lCQUNwQjthQUNKO1NBQ0o7UUFDRDtZQUNJLE9BQU8sRUFBRTtnQkFDTCxNQUFNLEVBQUUsT0FBTzthQUNsQjtTQUNKO1FBQ0Q7WUFDSSxVQUFVLEVBQUU7Z0JBQ1IsWUFBWSxFQUFFO29CQUNWLE1BQU0sRUFBRTt3QkFDSixRQUFRO3FCQUNYO2lCQUNKO2FBQ0o7U0FDSjtRQUNEO1lBQ0ksWUFBWSxFQUFFO2dCQUNWLFNBQVMsRUFBRSxPQUFPO2FBQ3JCO1NBQ0o7UUFDRDtZQUNJLE9BQU8sRUFBRSxJQUFJO1NBQ2hCO1FBQ0Q7WUFDSSxRQUFRLEVBQUUsS0FBSztTQUNsQjtRQUNEO1lBQ0ksS0FBSyxFQUFFO2dCQUNILE9BQU8sRUFBRSxDQUFDO2FBQ2I7U0FDSjtRQUNEO1lBQ0ksU0FBUyxFQUFHO2dCQUNSLE1BQU0sRUFBRyxPQUFPO2dCQUNoQixZQUFZLEVBQUcsUUFBUTtnQkFDdkIsY0FBYyxFQUFHLEtBQUs7Z0JBQ3RCLElBQUksRUFBRyxZQUFZO2FBQ3RCO1NBQ0o7UUFDRDtZQUNJLFNBQVMsRUFBRztnQkFDUixNQUFNLEVBQUcsT0FBTztnQkFDaEIsWUFBWSxFQUFHLFFBQVE7Z0JBQ3ZCLGNBQWMsRUFBRyxLQUFLO2dCQUN0QixJQUFJLEVBQUcsWUFBWTthQUN0QjtTQUNKO0tBQ0o7SUFDRCxJQUFHLE1BQU0sS0FBSyxFQUFFLEVBQUM7UUFFYixJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzVCLElBQUksR0FBRyxHQUFHO1lBQ04sTUFBTSxFQUFDLEVBQUU7U0FDWjtRQUNELEtBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBTSxFQUFDLENBQUMsRUFBRSxFQUFDO1lBQzlCLElBQUksR0FBRyxHQUFHLElBQUksTUFBTSxDQUFDLElBQUksR0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxFQUFDLEdBQUcsQ0FBQztZQUMxQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUUsRUFBRSxPQUFPLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUUsR0FBRyxFQUFFLENBQUUsRUFBRSxDQUFDLENBQUM7U0FDM0U7UUFHRCxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsR0FBRyxDQUFDO0tBQ25DO0lBR0Qsd0NBQW9CLENBQUMsSUFBSSxFQUFFLGtCQUFVLEVBQUUsWUFBWSxFQUFFLG9CQUFvQixDQUFDLENBQUM7QUFDL0UsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUMxRkgsd0NBQXVDO0FBQ3ZDLGtEQUN1QztBQUN2Qyx5RUFBdUU7QUFFdkUsNkVBQW9GO0FBRXBGOzs7O0VBSUU7QUFDRixlQUFNLENBQUMsT0FBTyxDQUFDLG1CQUFtQixFQUFFLFVBQVUsSUFBSSxFQUFFLEtBQUssRUFBQyxNQUFNO0lBQzVELElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ2QsT0FBTztLQUNWO0lBQ0QsSUFBSSxZQUFZLEdBQUc7UUFDZjtZQUNJLFFBQVEsRUFBRSxFQUFFO1NBQ2Y7UUFDRDtZQUNJLE1BQU0sRUFBRTtnQkFDSixLQUFLLEVBQUUsSUFBSTtnQkFDWCxPQUFPLEVBQUU7b0JBQ0wsTUFBTSxFQUFFLEdBQUc7aUJBQ2Q7Z0JBQ0QsTUFBTSxFQUFFO29CQUNKLE9BQU8sRUFBRSxRQUFRO2lCQUNwQjthQUNKO1NBQ0o7UUFDRDtZQUNJLE9BQU8sRUFBRTtnQkFDTCxNQUFNLEVBQUUsT0FBTzthQUNsQjtTQUNKO1FBQ0Q7WUFDSSxVQUFVLEVBQUU7Z0JBQ1IsWUFBWSxFQUFFO29CQUNWLE1BQU0sRUFBRTt3QkFDSixRQUFRO3FCQUNYO2lCQUNKO2FBQ0o7U0FDSjtRQUNEO1lBQ0ksWUFBWSxFQUFFO2dCQUNWLFNBQVMsRUFBRSxPQUFPO2FBQ3JCO1NBQ0o7UUFDRDtZQUNJLE9BQU8sRUFBRSxJQUFJO1NBQ2hCO1FBQ0Q7WUFDSSxRQUFRLEVBQUUsS0FBSztTQUNsQjtRQUNEO1lBQ0ksS0FBSyxFQUFFO2dCQUNILGdCQUFnQixFQUFFLENBQUM7YUFDdEI7U0FDSjtLQUNKO0lBRUQsSUFBRyxNQUFNLEtBQUssRUFBRSxFQUFDO1FBRWIsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM1QixJQUFJLEdBQUcsR0FBRztZQUNOLE1BQU0sRUFBQyxFQUFFO1NBQ1o7UUFDRCxLQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDLE1BQU0sRUFBQyxDQUFDLEVBQUUsRUFBQztZQUM5QixJQUFJLEdBQUcsR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksRUFBQyxHQUFHLENBQUM7WUFDMUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFFLEVBQUUsZ0JBQWdCLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxtQkFBbUIsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLGtCQUFrQixFQUFFLEdBQUcsRUFBRSxDQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ3ZIO1FBR0QsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQztLQUNuQztJQUdELHdDQUFvQixDQUFDLElBQUksRUFBRSxhQUFLLENBQUMsVUFBVSxFQUFFLFlBQVksRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3BGLENBQUMsQ0FBQyxDQUFDO0FBQ0g7O0dBRUc7QUFDSCxlQUFNLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxVQUFVLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLE1BQU07SUFDM0QsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7UUFDZCxPQUFPO0tBQ1Y7SUFDRCxJQUFJLFlBQVksR0FBRztRQUNmO1lBQ0ksUUFBUSxFQUFFLEVBQUU7U0FDZjtRQUNEO1lBQ0ksTUFBTSxFQUFFO2dCQUNKLEtBQUssRUFBRSxJQUFJO2dCQUNYLE9BQU8sRUFBRTtvQkFDTCxNQUFNLEVBQUUsR0FBRztpQkFDZDtnQkFDRCxNQUFNLEVBQUU7b0JBQ0osT0FBTyxFQUFFLFFBQVE7aUJBQ3BCO2FBQ0o7U0FDSjtRQUNELFVBQVU7UUFDVjtZQUNJLE9BQU8sRUFBRTtnQkFDTCxNQUFNLEVBQUUsT0FBTzthQUNsQjtTQUNKO1FBQ0QsVUFBVTtRQUNWO1lBQ0ksVUFBVSxFQUFFO2dCQUNSLFlBQVksRUFBRTtvQkFDVixNQUFNLEVBQUU7d0JBQ0osUUFBUTtxQkFDWDtpQkFDSjthQUNKO1NBQ0o7UUFDRCw0Q0FBNEM7UUFDNUM7WUFDSSxZQUFZLEVBQUU7Z0JBQ1YsU0FBUyxFQUFFLE9BQU87YUFDckI7U0FDSjtRQUNEO1lBQ0ksT0FBTyxFQUFFLElBQUk7U0FDaEI7UUFDRDtZQUNJLFFBQVEsRUFBRSxLQUFLO1NBQ2xCO1FBQ0Q7WUFDSSxLQUFLLEVBQUUsRUFBRTtTQUNaO0tBQ0osQ0FBQztJQUNGLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxvQ0FBYyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztJQUN6RCxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcscUNBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNqRCx3Q0FBb0IsQ0FBQyxJQUFJLEVBQUUsYUFBSyxDQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUUsV0FBVyxDQUFDO0FBQzNFLENBQUMsQ0FBQyxDQUFDO0FBQ0gsZUFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsVUFBVSxNQUFNO0lBQ3pDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ2QsT0FBTztLQUNWO0lBQ0QsSUFBSSxZQUFZLEdBQUc7UUFDZjtZQUNJLFFBQVEsRUFBRTtnQkFDTixjQUFjLEVBQUUsSUFBSSxNQUFNLENBQUMsSUFBSSxHQUFHLE1BQU0sR0FBRyxJQUFJLEVBQUUsR0FBRyxDQUFDO2FBQ3hEO1NBQ0o7UUFDRDtZQUNJLFFBQVEsRUFBRSxJQUFJO1NBQ2pCO0tBQ0osQ0FBQztJQUNGLHdDQUFvQixDQUFDLElBQUksRUFBRSxhQUFLLENBQUMsVUFBVSxFQUFFLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQztBQUM3RSxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ25KSCxJQUFJLGNBQWMsR0FBRywwRUFBMEUsQ0FBQyx3RkFBdUY7QUFDdkwsSUFBSSxZQUFZLEdBQUcsMEJBQTBCLENBQUMsQ0FBQyxrRUFBa0U7QUFDakgsSUFBSSxpQkFBaUIsR0FBRyw4REFBOEQsQ0FBQyxDQUFDLHFEQUFxRDtBQUM3SSxJQUFJLGNBQWMsR0FBRywyQ0FBMkMsQ0FBQyxDQUFDLDhCQUE4QjtBQUNoRyxJQUFJLFdBQVcsR0FBRyxlQUFlLENBQUM7QUFLbEMsSUFBSSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUM7SUFDbkIsY0FBYyxFQUFFLElBQUk7SUFDcEIsVUFBVSxFQUFFLEtBQUs7Q0FDcEIsQ0FBQyxDQUFDO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBeUlLOzs7Ozs7Ozs7Ozs7O0FDN0pMLHNDQUF3QztBQUN4QywrQkFBaUM7QUFDakMsOENBQTBEO0FBQzFELHdDQUF1QztBQUN2QyxzREFBZ0Q7QUFDaEQsSUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQ3BDLHlEQUF5RDtBQUN6RCxJQUFNLFdBQVcsR0FBRztJQUNsQixNQUFNLEVBQUU7UUFDTixFQUFFLEVBQUUsc0NBQXNDO1FBQzFDLE1BQU0sRUFBRSxrQ0FBa0MsQ0FBQyxrQ0FBa0M7S0FDOUU7SUFDRCxJQUFJLEVBQUU7UUFDSixTQUFTLEVBQUUsbUNBQW1DO1FBQzlDLGFBQWEsRUFBRSw0REFBNEQ7UUFDM0UsU0FBUyxFQUFFLHdEQUF3RDtLQUNwRTtDQUNGLENBQUM7QUFDRixJQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBRTVELElBQUksWUFBWSxHQUNkLDRJQUE0SSxDQUFDO0FBSS9JLElBQUksR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDO0lBQ3JCLGNBQWMsRUFBRSxJQUFJO0lBQ3BCLFVBQVUsRUFBRSxLQUFLO0NBQ2xCLENBQUMsQ0FBQztBQUVILEdBQUcsQ0FBQyxRQUFRLENBQ1Ysd0JBQXdCLEVBQ3hCLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxFQUN2QjtJQUNFLEdBQUcsRUFBRTtRQUNILElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDO1FBQzdCLElBQU0sR0FBRyxHQUFHLElBQUksTUFBTSxFQUFFLENBQUM7UUFDekIsSUFBSSxZQUFZLEdBQUcsbUJBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM5QyxJQUFJLE9BQU8sWUFBWSxLQUFLLFdBQVcsRUFBRTtZQUN2QywwQkFBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFDLElBQVM7Z0JBQ2hDLCtDQUErQztnQkFFL0MsSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLEVBQUUsRUFBRTtvQkFDckIsSUFBTSxHQUFHLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FDckIsa3ZMQUFrdkwsRUFDbHZMLFFBQVEsQ0FDVCxDQUFDO29CQUNGLEdBQUcsQ0FBQyxNQUFNLENBQUM7d0JBQ1QsVUFBVSxFQUFFLEdBQUc7d0JBQ2YsT0FBTyxFQUFFOzRCQUNQLGNBQWMsRUFBRSxJQUFJLENBQUMsV0FBVzt5QkFDakM7d0JBQ0QsSUFBSSxFQUFFLEdBQUc7cUJBQ1YsQ0FBQyxDQUFDO2lCQUNKO3FCQUFNO29CQUNMLElBQU0sR0FBRyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztvQkFDN0MsR0FBRyxDQUFDLE1BQU0sQ0FBQzt3QkFDVCxVQUFVLEVBQUUsR0FBRzt3QkFDZixPQUFPLEVBQUU7NEJBQ1AsY0FBYyxFQUFFLElBQUksQ0FBQyxXQUFXO3lCQUNqQzt3QkFDRCxJQUFJLEVBQUUsR0FBRztxQkFDVixDQUFDLENBQUM7aUJBQ0o7WUFDSCxDQUFDLENBQUMsQ0FBQztTQUNKO2FBQU07WUFDTCxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxFQUFFLG1CQUFtQixFQUFFLENBQUMsQ0FBQztTQUMxQztRQUNELE9BQU8sR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3BCLENBQUM7Q0FDRixDQUNGLENBQUM7QUFFRixHQUFHLENBQUMsUUFBUSxDQUNWLHFCQUFxQixFQUNyQixFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsRUFDdkI7SUFDRSxHQUFHLEVBQUU7UUFDSCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztRQUVuQyxJQUFJLEtBQUssS0FBSyxXQUFXLEVBQUU7WUFDekIsT0FBTztnQkFDTCxVQUFVLEVBQUUsR0FBRztnQkFDZixPQUFPLEVBQUU7b0JBQ1AsY0FBYyxFQUFFLFlBQVk7b0JBQzVCLFFBQVEsRUFBRSxjQUFjLENBQUMsS0FBSyxDQUFDO2lCQUNoQztnQkFDRCxJQUFJLEVBQUUsWUFBWSxHQUFHLGNBQWMsQ0FBQyxLQUFLLENBQUM7YUFDM0MsQ0FBQztTQUNIO2FBQU07WUFDTCxPQUFPLDRCQUE0QixDQUFDO1NBQ3JDO0lBQ0gsQ0FBQztDQUNGLENBQ0YsQ0FBQztBQUVGLEdBQUcsQ0FBQyxRQUFRLENBQ1YsaUJBQWlCLEVBQ2pCLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxFQUN2QjtJQUNFLEdBQUcsRUFBRTtRQUNILElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDO1FBQ25DLElBQUksUUFBUSxHQUFHLHVCQUFTLENBQUMsT0FBTyxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDdkQsSUFBSSxPQUFPLFFBQVEsS0FBSyxXQUFXLEVBQUU7WUFDbkMsT0FBTyw0QkFBNEIsQ0FBQztTQUNyQztRQUVELElBQUksRUFBRSxHQUFHLHVCQUFTLENBQUMsT0FBTyxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ3ZELElBQUksT0FBTyxFQUFFLEtBQUssV0FBVyxFQUFFO1lBQzdCLE9BQU8sNEJBQTRCLENBQUM7U0FDckM7YUFBTSxJQUFJLE9BQU8sS0FBSyxLQUFLLFdBQVcsRUFBRTtZQUN2QyxPQUFPLDRCQUE0QixDQUFDO1NBQ3JDO2FBQU07WUFDTCxPQUFPO2dCQUNMLFVBQVUsRUFBRSxHQUFHO2dCQUNmLE9BQU8sRUFBRTtvQkFDUCxjQUFjLEVBQUUsWUFBWTtvQkFDNUIsUUFBUSxFQUFFLFVBQVUsQ0FBQyxFQUFFLENBQUM7aUJBQ3pCO2dCQUNELElBQUksRUFBRSxZQUFZLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQzthQUNwQyxDQUFDO1NBQ0g7SUFDSCxDQUFDO0NBQ0YsQ0FDRixDQUFDO0FBRUYsR0FBRyxDQUFDLFFBQVEsQ0FDVixJQUFJLEVBQ0osRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLEVBQ3ZCO0lBQ0UsR0FBRyxFQUFFO1FBQ0gsSUFBTSxHQUFHLEdBQUcsSUFBSSxNQUFNLEVBQUUsQ0FBQztRQUV6QixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQztRQUNqQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztRQUNuQyxJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUMvQixPQUFPLDRCQUE0QixDQUFDO1NBQ3JDO1FBQ0QsSUFBSSxPQUFPLEtBQUssS0FBSyxXQUFXLEVBQUU7WUFDaEMsT0FBTyw0QkFBNEIsQ0FBQztTQUNyQztRQUVELElBQUksS0FBSyxLQUFLLFdBQVcsRUFBRTtZQUN6Qix5QkFBeUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBSztnQkFDeEMsR0FBRyxDQUFDLE1BQU0sQ0FBQztvQkFDVCxVQUFVLEVBQUUsR0FBRztvQkFDZixPQUFPLEVBQUU7d0JBQ1AsY0FBYyxFQUFFLFdBQVc7cUJBQzVCO29CQUNELElBQUksRUFBRSxxRkFFQTtpQkFDUCxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztTQUNKO2FBQU07WUFDTCxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBSztnQkFDL0IsdUJBQVMsQ0FBQyxNQUFNLENBQ2Q7b0JBQ0UsS0FBSyxFQUFFLEtBQUs7aUJBQ2IsRUFDRDtvQkFDRSxJQUFJLEVBQUU7d0JBQ0osS0FBSyxFQUFFLEtBQUs7cUJBQ2I7aUJBQ0YsQ0FDRjtxQkFDRSxTQUFTLEVBQUU7cUJBQ1gsSUFBSSxDQUFDO29CQUNKLEdBQUcsQ0FBQyxNQUFNLENBQUM7d0JBQ1QsVUFBVSxFQUFFLEdBQUc7d0JBQ2YsT0FBTyxFQUFFOzRCQUNQLGNBQWMsRUFBRSxXQUFXO3lCQUM1Qjt3QkFDRCxJQUFJLEVBQUUscUZBRUo7cUJBQ0gsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQyxDQUFDO1lBQ1AsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUVELE9BQU8sR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3BCLENBQUM7Q0FDRixDQUNGLENBQUM7QUFDRixvQkFBb0IsS0FBSztJQUN2QixJQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDO1FBQ3RELFlBQVksRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsR0FBRyxTQUFTO1FBQzlDLEtBQUssRUFBRSx5Q0FBeUM7UUFDaEQsS0FBSyxFQUFFLEtBQUs7S0FDYixDQUFDLENBQUM7SUFDSCxPQUFPLFNBQVMsQ0FBQztBQUNuQixDQUFDO0FBQ0Qsd0JBQXdCLEtBQUs7SUFDM0IsSUFBTSxTQUFTLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQztRQUN0RCxZQUFZLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEdBQUcsU0FBUztRQUM5QyxLQUFLLEVBQUUsWUFBWTtRQUNuQixLQUFLLEVBQUUsS0FBSztLQUNiLENBQUMsQ0FBQztJQUNILE9BQU8sU0FBUyxDQUFDO0FBQ25CLENBQUM7QUFFRCwwQkFBMEIsU0FBUztJQUNqQyxPQUFPLElBQUksT0FBTyxDQUFDLFVBQUMsR0FBRyxFQUFFLEdBQUc7UUFDMUIsTUFBTSxDQUFDLGlCQUFpQjthQUNyQixRQUFRLENBQUM7WUFDUixJQUFJLEVBQUUsU0FBUztZQUNmLFlBQVksRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsR0FBRyxTQUFTO1lBQzlDLEtBQUssRUFBRSwwQkFBMEI7U0FDbEMsQ0FBQzthQUNELElBQUksQ0FBQyxnQkFBTTtZQUNWLElBQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2hELElBQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUU5QyxJQUFJLEVBQUUsR0FBRyxJQUFJLE1BQU0sQ0FDakIsSUFBSSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLEVBQUUsR0FBRyxJQUFJLEVBQ25ELEdBQUcsQ0FDSixDQUFDO1lBRUYsSUFBSSxHQUFHLEdBQUcsbUJBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQ3RCLElBQUksRUFBRSxFQUFFO2FBQ1QsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxPQUFPLEdBQUcsS0FBSyxXQUFXLEVBQUU7Z0JBQzlCLDhDQUE4QztnQkFFOUMsSUFBSSxPQUFPLEdBQUc7b0JBQ1osT0FBTyxFQUFFLEVBQUUsYUFBYSxFQUFFLFNBQVMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRTtpQkFDakUsQ0FBQztnQkFFRixNQUFNLENBQUMsR0FBRyxDQUNSLDJEQUEyRCxFQUMzRCxPQUFPLEVBQ1AsZUFBTSxDQUFDLGVBQWUsQ0FBQyxVQUFDLEdBQUcsRUFBRSxJQUFJO29CQUMvQixHQUFHLENBQUMsS0FBSzt3QkFDUCxPQUFPOzRCQUNQLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDOzRCQUM1QixVQUFVOzRCQUNWLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUUvQixLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksRUFBRTt3QkFDbEIsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDbEI7b0JBRUQsbUJBQUssQ0FBQyxNQUFNLENBQ1Y7d0JBQ0UsR0FBRyxFQUFFLEdBQUcsQ0FBQyxHQUFHO3FCQUNiLEVBQ0Q7d0JBQ0UsSUFBSSxFQUFFLEdBQUc7cUJBQ1YsQ0FDRixDQUFDO29CQUVGLElBQUksaUJBQWlCLEdBQUcsd0JBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxFQUFFLENBQUM7b0JBQ2pFLHdCQUFRLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLGlCQUFpQixDQUFDLENBQUM7b0JBQzFELEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO2dCQUN6QixDQUFDLENBQUMsQ0FDSCxDQUFDO2FBQ0g7aUJBQU07Z0JBQ0wsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ1g7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVELG1DQUFtQyxTQUFTO0lBQzFDLE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBQyxHQUFHLEVBQUUsR0FBRztRQUMxQixNQUFNLENBQUMsaUJBQWlCO2FBQ3JCLFFBQVEsQ0FBQztZQUNSLElBQUksRUFBRSxTQUFTO1lBQ2YsWUFBWSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxHQUFHLFNBQVM7WUFDOUMsS0FBSyxFQUFFLFlBQVk7U0FDcEIsQ0FBQzthQUNELElBQUksQ0FBQyxnQkFBTTtZQUNWLElBQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2hELElBQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUM5QyxvQkFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7aUJBQ2QsU0FBUyxFQUFFO2lCQUNYLElBQUksQ0FBQztnQkFDSixvQkFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzNCLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNaLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRDs7Ozs7Ozs7Ozs7Ozs7R0FjRzs7Ozs7Ozs7Ozs7OztBQzNTSCx3Q0FBdUM7QUFDdkMsNkNBQW9EO0FBQ3BELHlEQUdnQztBQUNoQyxJQUFJLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDL0IsSUFBSSxvQkFBb0IsQ0FBQztBQUN6QixJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUM7QUFDcEIsZUFBTSxDQUFDLE9BQU8sQ0FBQztJQUNiLGNBQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDO1FBQzdCLE9BQU8sRUFBRSxlQUFNLENBQUMsZUFBZSxDQUFDLFVBQVMsRUFBRSxFQUFFLE1BQU07WUFDakQsNEJBQTRCO1FBQzlCLENBQUMsQ0FBQztRQUNGLEtBQUssRUFBRSxlQUFNLENBQUMsZUFBZSxDQUFDLFVBQVMsRUFBRSxFQUFFLE1BQU07WUFDL0MsSUFBSSxPQUFPLG9CQUFvQixLQUFLLFdBQVcsRUFBRTtnQkFDL0MsWUFBWSxDQUFDLG9CQUFvQixDQUFDLENBQUM7YUFDcEM7WUFDRCxvQkFBb0IsR0FBRyxVQUFVLENBQy9CLGVBQU0sQ0FBQyxlQUFlLENBQUM7Z0JBQ3JCLElBQUksUUFBUSxLQUFLLElBQUksRUFBRTtvQkFDckIsUUFBUSxHQUFHLEtBQUssQ0FBQztpQkFDbEI7cUJBQU07b0JBQ0wscUJBQXFCLENBQUMsRUFBRSxDQUFDLENBQUM7aUJBQzNCO1lBQ0gsQ0FBQyxDQUFDLEVBQ0YsSUFBSSxDQUNMLENBQUM7UUFDSixDQUFDLENBQUM7UUFDRixPQUFPLEVBQUUsZUFBTSxDQUFDLGVBQWUsQ0FBQyxVQUFTLEVBQUUsRUFBRSxNQUFNO1lBQ2pELDRCQUE0QjtRQUM5QixDQUFDLENBQUM7S0FDSCxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQztBQUVILCtCQUErQixFQUFFO0lBQy9CLElBQUksRUFBRSxHQUFHLGNBQU0sQ0FBQyxPQUFPLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUNyQyxJQUFJLEdBQUcsR0FBRztRQUNSLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7UUFDN0IsRUFBRSxDQUFDLE9BQU87UUFDVixFQUFFLENBQUMsSUFBSSxDQUFDLFdBQVc7UUFDbkIsRUFBRTtRQUNGLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7UUFDM0IsRUFBRSxDQUFDLEdBQUc7S0FDUCxDQUFDO0lBRUYsSUFBSSxRQUFRLEdBQVEsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNoRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtRQUN4QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDcEQsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRTtnQkFDN0MsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7YUFDbEM7U0FDRjtLQUNGO0lBRUQsMkNBQStCLENBQzdCLG9DQUFvQyxFQUNwQyxNQUFNLEVBQ04sR0FBRyxFQUNILENBQUMsRUFDRCxHQUFHLENBQUMsTUFBTSxDQUNYLENBQUMsSUFBSSxDQUFDLGNBQUk7UUFDVCxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3BCLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUNELDRCQUE0QixFQUFFO0lBQzVCLElBQUksRUFBRSxHQUFHLGNBQU0sQ0FBQyxPQUFPLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUNyQyxJQUFJLEdBQUcsR0FBRztRQUNSLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7UUFDN0IsRUFBRSxDQUFDLE9BQU87UUFDVixFQUFFLENBQUMsSUFBSSxDQUFDLFdBQVc7UUFDbkIsRUFBRTtRQUNGLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7UUFDM0IsRUFBRSxDQUFDLEdBQUc7S0FDUCxDQUFDO0lBRUYsSUFBSSxRQUFRLEdBQVEsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNoRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtRQUN4QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDcEQsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRTtnQkFDN0MsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7YUFDbEM7U0FDRjtLQUNGO0FBQ0gsQ0FBQztBQUVELElBQUksb0JBQW9CLENBQUM7QUFFekI7SUFDRSxJQUFJLE9BQU8sb0JBQW9CLEtBQUssV0FBVyxFQUFFO1FBQy9DLFlBQVksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0tBQ3BDO0lBQ0Qsb0JBQW9CLEdBQUcsVUFBVSxDQUMvQixlQUFNLENBQUMsZUFBZSxDQUFDO1FBQ3JCLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUM7UUFDbEUsSUFBSSxRQUFRLEdBQVEsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNoRCxJQUFJLFNBQVMsR0FBRyxNQUFNLEVBQUU7YUFDckIsT0FBTyxDQUFDLEtBQUssQ0FBQzthQUNkLE1BQU0sRUFBRSxDQUFDO1FBQ1osSUFBSSxPQUFPLEdBQUcsTUFBTSxFQUFFO2FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDO2FBQ2YsTUFBTSxFQUFFLENBQUM7UUFFWixJQUFJLFNBQVMsR0FBRyxjQUFNLENBQUMsSUFBSSxDQUFDO1lBQzFCLElBQUksRUFBRTtnQkFDSixFQUFFLEtBQUssRUFBRSxFQUFFLEdBQUcsRUFBRSxTQUFTLENBQUMsV0FBVyxFQUFFLEVBQUUsRUFBRTtnQkFDM0MsRUFBRSxLQUFLLEVBQUUsRUFBRSxHQUFHLEVBQUUsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFLEVBQUU7YUFDMUM7U0FDRixDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFdkIsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2QsT0FBTyxTQUFTLEdBQUcsT0FBTyxFQUFFO1lBQzFCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN4QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ3BELElBQUksQ0FBQyxJQUFJLENBQ1AsaUJBQWlCLENBQ2YsU0FBUyxFQUNULFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQ3ZCLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQ3RDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQ3hCLENBQ0YsQ0FBQztpQkFDSDthQUNGO1lBQ0QsU0FBUyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUM7aUJBQzFCLEdBQUcsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDO2lCQUNiLE1BQU0sRUFBRSxDQUFDO1NBQ2I7UUFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN6QixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFJO1lBQ3pCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNwQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssdUJBQXVCLEVBQUU7b0JBQzNDLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQztvQkFDWixLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDckIsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDckI7b0JBQ0QsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztpQkFDbkI7YUFDRjtZQUNELDJDQUErQixDQUM3QixvQ0FBb0MsRUFDcEMsTUFBTSxFQUNOLFFBQVEsRUFDUixRQUFRLENBQUMsTUFBTSxFQUNmLENBQUMsQ0FDRixDQUFDLElBQUksQ0FBQyxjQUFJO2dCQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDcEIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxFQUNGLElBQUksQ0FDTCxDQUFDO0FBQ0osQ0FBQztBQUVELDJCQUEyQixNQUFNLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTO0lBQ3RELE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBQyxHQUFHLEVBQUUsR0FBRztRQUMxQixJQUFJLEdBQUcsR0FBRztZQUNSLEtBQUssRUFBRSxJQUFJO1lBQ1gsR0FBRyxFQUFFLHVCQUF1QjtZQUM1QixlQUFlLEVBQUUsSUFBSSxDQUFDLFdBQVc7WUFDakMsU0FBUyxFQUFFLFNBQVM7U0FDckIsQ0FBQztRQUNGLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3RDLElBQ0UsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssSUFBSSxDQUFDLEVBQUU7Z0JBQzdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLEtBQUssQ0FBQyxLQUFLLElBQUksRUFDOUQ7Z0JBQ0EsR0FBRyxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2FBQzdCO1NBQ0Y7UUFDRCxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDWCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XHJcbmRlY2xhcmUgdmFyIHJlcXVpcmU7XHJcbmRlY2xhcmUgdmFyIFJvbGVzO1xyXG5kZWNsYXJlIHZhciBlbWl0O1xyXG5pbXBvcnQgKiBhcyBGdXR1cmUgZnJvbSBcImZpYmVycy9mdXR1cmVcIjtcclxudmFyIG5lZWRsZSA9IHJlcXVpcmUoXCJuZWVkbGVcIik7XHJcbnZhciBtb21lbnQgPSByZXF1aXJlKFwibW9tZW50XCIpO1xyXG5cclxuaW1wb3J0IHsgVXNlcnMgfSBmcm9tIFwiLi4vLi4vY29sbGVjdGlvbnNcIjtcclxuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tIFwibWV0ZW9yL2FjY291bnRzLWJhc2VcIjtcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICBsb2dpbk92ZXJBcHAoYWNjZXNzX3Rva2VuKSB7XHJcbiAgICBjb25zdCBmdXQgPSBuZXcgRnV0dXJlKCk7XHJcbiAgICBuZWVkbGUuZ2V0KFxyXG4gICAgICBcImh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL29hdXRoMi92Mi91c2VyaW5mbz9hY2Nlc3NfdG9rZW49XCIgK1xyXG4gICAgICAgIGFjY2Vzc190b2tlbixcclxuICAgICAgTWV0ZW9yLmJpbmRFbnZpcm9ubWVudCgoZXJyb3IsIHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKGVycm9yID09PSBudWxsICYmIHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICB2YXIgZW1haWwgPSByZXNwb25zZS5ib2R5LmVtYWlsO1xyXG4gICAgICAgICAgdmFyIHN0YW1wZWRMb2dpblRva2VuID0gQWNjb3VudHNbXCJfZ2VuZXJhdGVTdGFtcGVkTG9naW5Ub2tlblwiXSgpO1xyXG4gICAgICAgICAgbGV0IHBvc3RzID0gVXNlcnMuZmluZE9uZSh7IFwic2VydmljZXMuZ29vZ2xlLmVtYWlsXCI6IGVtYWlsIH0pO1xyXG4gICAgICAgICAgaWYgKHR5cGVvZiBwb3N0cyA9PT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgICAgICBmdXQucmV0dXJuKHsgZXJyOiB0cnVlLCBkYXRhOiBudWxsIH0pO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgQWNjb3VudHNbXCJfaW5zZXJ0TG9naW5Ub2tlblwiXShwb3N0cy5faWQsIHN0YW1wZWRMb2dpblRva2VuKTtcclxuICAgICAgICAgICAgZnV0LnJldHVybih7IGVycjogZmFsc2UsIGRhdGE6IHN0YW1wZWRMb2dpblRva2VuIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBmdXQucmV0dXJuKHsgZXJyOiB0cnVlLCBkYXRhOiBudWxsIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgICk7XHJcbiAgICByZXR1cm4gZnV0LndhaXQoKTtcclxuICB9LFxyXG4gIGNoYW5nZVBhc3N3b3JkVXNlcihwYXNzd29yZCkge1xyXG4gICAgQWNjb3VudHMuc2V0UGFzc3dvcmQodGhpcy51c2VySWQsIHBhc3N3b3JkKTtcclxuICB9LFxyXG4gIGNoYW5nZUFjY2Vzc1Rva2VuKCkge1xyXG4gICAgdmFyIHJhbmRvbSA9IG1ha2VpZCgyMCk7XHJcbiAgICB2YXIgdXNlciA9IFVzZXJzLmZpbmRPbmUoeyBfaWQ6IHRoaXMudXNlcklkIH0pO1xyXG4gICAgdXNlci5wcm9maWxlLmFwaVRva2VuID0gcmFuZG9tO1xyXG4gICAgVXNlcnMudXBkYXRlKFxyXG4gICAgICB7XHJcbiAgICAgICAgX2lkOiB0aGlzLnVzZXJJZFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgJHNldDogdXNlclxyXG4gICAgICB9XHJcbiAgICApO1xyXG4gIH0sXHJcbiAgc2VhcmNoVXNlcihmaWx0ZXIpIHtcclxuICAgIHZhciBvYmpBID0ge307XHJcbiAgICBpZiAoZmlsdGVyICE9PSBcIlwiKSB7XHJcbiAgICAgIHZhciBhbmQgPSBmaWx0ZXIuc3BsaXQoXCIgXCIpO1xyXG4gICAgICB2YXIgb2JqID0ge1xyXG4gICAgICAgICRhbmQ6IFtdXHJcbiAgICAgIH07XHJcbiAgICAgIGZvciAodmFyIGwgPSAwOyBsIDwgYW5kLmxlbmd0aDsgbCsrKSB7XHJcbiAgICAgICAgdmFyIHJlZyA9IG5ldyBSZWdFeHAoXCIuKlwiICsgYW5kW2xdICsgXCIuKlwiLCBcImlcIik7XHJcbiAgICAgICAgb2JqW1wiJGFuZFwiXS5wdXNoKHtcclxuICAgICAgICAgICRvcjogW1xyXG4gICAgICAgICAgICB7IFwiZW1haWxzLmFkZHJlc3NcIjogcmVnIH0sXHJcbiAgICAgICAgICAgIHsgXCJwcm9maWxlLmZpcnN0TmFtZVwiOiByZWcgfSxcclxuICAgICAgICAgICAgeyBcInByb2ZpbGUubGFzdE5hbWVcIjogcmVnIH1cclxuICAgICAgICAgIF1cclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgb2JqQSA9IG9iajtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gVXNlcnMuZmluZChvYmpBLCB7XHJcbiAgICAgIGZpZWxkczoge1xyXG4gICAgICAgIHByb2ZpbGU6IDEsXHJcbiAgICAgICAgZW1haWxzOiAxLFxyXG4gICAgICAgIF9pZDogMVxyXG4gICAgICB9XHJcbiAgICB9KS5jdXJzb3IuZmV0Y2goKTtcclxuICB9XHJcbn0pO1xyXG5cclxuZnVuY3Rpb24gbWFrZWlkKGxlbmd0aCkge1xyXG4gIHZhciByZXN1bHQgPSBcIlwiO1xyXG4gIHZhciBjaGFyYWN0ZXJzID1cclxuICAgIFwiQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODlcIjtcclxuICB2YXIgY2hhcmFjdGVyc0xlbmd0aCA9IGNoYXJhY3RlcnMubGVuZ3RoO1xyXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcclxuICAgIHJlc3VsdCArPSBjaGFyYWN0ZXJzLmNoYXJBdChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBjaGFyYWN0ZXJzTGVuZ3RoKSk7XHJcbiAgfVxyXG4gIHJldHVybiByZXN1bHQ7XHJcbn1cclxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcclxuZGVjbGFyZSB2YXIgcmVxdWlyZTtcclxuZGVjbGFyZSB2YXIgUm9sZXM7XHJcbmRlY2xhcmUgdmFyIGVtaXQ7XHJcbmltcG9ydCAqIGFzIEZ1dHVyZSBmcm9tIFwiZmliZXJzL2Z1dHVyZVwiO1xyXG52YXIgbmVlZGxlID0gcmVxdWlyZShcIm5lZWRsZVwiKTtcclxudmFyIG1vbWVudCA9IHJlcXVpcmUoXCJtb21lbnRcIik7XHJcblxyXG5pbXBvcnQge1xyXG4gIGdldEdyb3VwTGlzdCxcclxuICBzeW5jVXNlckFuZEdyb3VwcyxcclxuICBjcmVhdGVFdmVudCxcclxuICBzZW5kRW1haWwsXHJcbiAgcmVhZERhdGFGcm9tU3ByZWFkc2hlZXQsXHJcbiAgdXBsb2FkRGF0YVRvU3ByZWFkc2hlZXRcclxufSBmcm9tIFwiLi4vLi4vbGliTW9kdWxlcy9vZmZpY2UzNjVcIjtcclxuXHJcbmltcG9ydCB7IEV2ZW50cyB9IGZyb20gXCIuLi8uLi9jb2xsZWN0aW9ucy9pbmRleFwiO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG4gIHVwbG9hZHRlc3QoZmlsZSkge1xyXG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBjb25zdCBmdXQgPSBuZXcgRnV0dXJlKCk7XHJcbiAgICB1cGxvYWREYXRhVG9TcHJlYWRzaGVldChcIlwiLCBcIlwiLCBcIlwiKS50aGVuKGRhdGEgPT4ge1xyXG4gICAgICBmdXQucmV0dXJuKGRhdGEpO1xyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gZnV0LndhaXQoKTtcclxuICB9LFxyXG4gIHJlYWREYXRhRnJvbVNwcmVhZFNoZWV0KGZpbGUpIHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgY29uc3QgZnV0ID0gbmV3IEZ1dHVyZSgpO1xyXG4gICAgcmVhZERhdGFGcm9tU3ByZWFkc2hlZXQoXCJcIikudGhlbihkYXRhID0+IHtcclxuICAgICAgZnV0LnJldHVybihkYXRhKTtcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGZ1dC53YWl0KCk7XHJcbiAgfSxcclxuICBzZW5kRW1haWwodG8sIGNjLCBzdWJqZWN0LCBib2R5KSB7XHJcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGNvbnN0IGZ1dCA9IG5ldyBGdXR1cmUoKTtcclxuICAgIHNlbmRFbWFpbCh0bywgY2MsIHN1YmplY3QsIGJvZHkpLnRoZW4oKCkgPT4ge1xyXG4gICAgICBmdXQucmV0dXJuKCk7XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBmdXQud2FpdCgpO1xyXG4gIH0sXHJcbiAgY3JlYXRlRXZlbnQoZGF0YSkge1xyXG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBjb25zdCBmdXQgPSBuZXcgRnV0dXJlKCk7XHJcbiAgICBFdmVudHMuaW5zZXJ0KGRhdGEpXHJcbiAgICAgIC50b1Byb21pc2UoKVxyXG4gICAgICAudGhlbigoKSA9PiB7XHJcbiAgICAgICAgZnV0LnJldHVybigpO1xyXG4gICAgICB9KTtcclxuICAgIHJldHVybiBmdXQud2FpdCgpO1xyXG4gIH0sXHJcbiAgZ2V0R3JvdXBzKCkge1xyXG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBjb25zdCBmdXQgPSBuZXcgRnV0dXJlKCk7XHJcbiAgICBnZXRHcm91cExpc3QoKS50aGVuKGdyb3VwTGlzdCA9PiB7XHJcbiAgICAgIGZ1dC5yZXR1cm4oZ3JvdXBMaXN0KTtcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGZ1dC53YWl0KCk7XHJcbiAgfSxcclxuICBzdGFydFN5bmNHcm91cHNVc2VycygpIHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgY29uc3QgZnV0ID0gbmV3IEZ1dHVyZSgpO1xyXG4gICAgc3luY1VzZXJBbmRHcm91cHMoKS50aGVuKGdyb3VwTGlzdCA9PiB7XHJcbiAgICAgIGZ1dC5yZXR1cm4oZ3JvdXBMaXN0KTtcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGZ1dC53YWl0KCk7XHJcbiAgfSxcclxuICBjcmVhdGVFdmVudEFuZEludml0ZSh0aXRsZSwgZGVzY3JpcHRpb24sIHN0YXJ0LCBlbmQsIGVtYWlsKSB7XHJcbiAgICBjb25zdCBmdXQgPSBuZXcgRnV0dXJlKCk7XHJcbiAgICBjcmVhdGVFdmVudCh0aXRsZSwgZGVzY3JpcHRpb24sIHN0YXJ0LCBlbmQsIGVtYWlsKS50aGVuKGRhdGEgPT4ge1xyXG4gICAgICBmdXQucmV0dXJuKGRhdGEpO1xyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gZnV0LndhaXQoKTtcclxuICB9XHJcbn0pO1xyXG4vKlxyXG5cclxuXCJUZXN0IEhvbWUgT2ZmaWNlXCIsXHJcbiAgICAgIFwiVGVzdCBBc2FuXCIsXHJcbiAgICAgIG5ldyBEYXRlKDIwMTksIDExLCA0LCAxLCAwLCAwLCAwKS50b0lTT1N0cmluZygpLFxyXG4gICAgICBuZXcgRGF0ZSgyMDE5LCAxMSwgNSwgMSwgMCwgMCwgMCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgXCJhc2FuLnN0ZWZhbnNraUBhZHZpc29yaS5kZVwiXHJcblxyXG4qL1xyXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xyXG5kZWNsYXJlIHZhciByZXF1aXJlO1xyXG5kZWNsYXJlIHZhciBSb2xlcztcclxuZGVjbGFyZSB2YXIgZW1pdDtcclxuaW1wb3J0ICogYXMgRnV0dXJlIGZyb20gXCJmaWJlcnMvZnV0dXJlXCI7XHJcbnZhciBuZWVkbGUgPSByZXF1aXJlKFwibmVlZGxlXCIpO1xyXG52YXIgbW9tZW50ID0gcmVxdWlyZShcIm1vbWVudFwiKTtcclxuXHJcbmltcG9ydCB7IFVzZXJzLCBUZWFtcyB9IGZyb20gXCIuLi8uLi9jb2xsZWN0aW9uc1wiO1xyXG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gXCJtZXRlb3IvYWNjb3VudHMtYmFzZVwiO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG4gIGdldFRlYW1zKCkge1xyXG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICByZXR1cm4gVGVhbXMuZmluZCh7fSkuY3Vyc29yLmZldGNoKCk7XHJcbiAgfSxcclxuICB1cGRhdGVNeVRlYW0oaWQpIHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgVXNlcnMudXBkYXRlKFxyXG4gICAgICB7IF9pZDogdGhpcy51c2VySWQgfSxcclxuICAgICAge1xyXG4gICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgIG15VGVhbTogaWRcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICk7XHJcbiAgfVxyXG59KTtcclxuIiwiaW1wb3J0IHsgTW9uZ29PYnNlcnZhYmxlIH0gZnJvbSBcIm1ldGVvci1yeGpzXCI7XHJcblxyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xyXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gXCJtZXRlb3IvbW9uZ29cIjtcclxuXHJcbmV4cG9ydCBjb25zdCBVc2VycyA9IE1vbmdvT2JzZXJ2YWJsZS5mcm9tRXhpc3Rpbmc8YW55PihNZXRlb3IudXNlcnMpO1xyXG5cclxuZXhwb3J0IGNvbnN0IG1vbmdvVGVhbXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcInRlYW1zXCIpO1xyXG5leHBvcnQgY29uc3QgVGVhbXMgPSBuZXcgTW9uZ29PYnNlcnZhYmxlLkNvbGxlY3Rpb248YW55Pihtb25nb1RlYW1zKTtcclxuXHJcbmV4cG9ydCBjb25zdCBtb25nb0V2ZW50VHlwZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcImV2ZW50dHlwZXNcIik7XHJcbmV4cG9ydCBjb25zdCBFdmVudFR5cGVzID0gbmV3IE1vbmdvT2JzZXJ2YWJsZS5Db2xsZWN0aW9uPGFueT4obW9uZ29FdmVudFR5cGVzKTtcclxuXHJcbmV4cG9ydCBjb25zdCBtb25nb0NoYWxhbmdlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiY2hhbGxhbmdlXCIpO1xyXG5leHBvcnQgY29uc3QgQ2hhbGFuZ2VzID0gbmV3IE1vbmdvT2JzZXJ2YWJsZS5Db2xsZWN0aW9uPGFueT4obW9uZ29DaGFsYW5nZXMpO1xyXG5cclxuZXhwb3J0IGNvbnN0IG1vbmdvRXZlbnRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJldmVudHNcIik7XHJcbmV4cG9ydCBjb25zdCBFdmVudHMgPSBuZXcgTW9uZ29PYnNlcnZhYmxlLkNvbGxlY3Rpb248YW55Pihtb25nb0V2ZW50cyk7XHJcblxyXG5leHBvcnQgY29uc3QgbW9uZ29TeW5jZXIgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcInN5bmNlclwiKTtcclxuZXhwb3J0IGNvbnN0IFN5bmNlciA9IG5ldyBNb25nb09ic2VydmFibGUuQ29sbGVjdGlvbjxhbnk+KG1vbmdvU3luY2VyKTtcclxuXHJcblN5bmNlci5hbGxvdyh7XHJcbiAgaW5zZXJ0KHVzZXJJZCwgZG9jKSB7XHJcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH0sXHJcbiAgdXBkYXRlKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XHJcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH0sXHJcbiAgcmVtb3ZlKHVzZXJJZCwgZG9jKSB7XHJcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxufSk7XHJcblVzZXJzLmFsbG93KHtcclxuICBpbnNlcnQodXNlcklkLCBkb2MpIHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfSxcclxuICB1cGRhdGUodXNlcklkLCBkb2MsIGZpZWxkcywgbW9kaWZpZXIpIHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfSxcclxuICByZW1vdmUodXNlcklkLCBkb2MpIHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG59KTtcclxuVGVhbXMuYWxsb3coe1xyXG4gIGluc2VydCh1c2VySWQsIGRvYykge1xyXG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9LFxyXG4gIHVwZGF0ZSh1c2VySWQsIGRvYywgZmllbGRzLCBtb2RpZmllcikge1xyXG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9LFxyXG4gIHJlbW92ZSh1c2VySWQsIGRvYykge1xyXG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbn0pO1xyXG5FdmVudFR5cGVzLmFsbG93KHtcclxuICBpbnNlcnQodXNlcklkLCBkb2MpIHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfSxcclxuICB1cGRhdGUodXNlcklkLCBkb2MsIGZpZWxkcywgbW9kaWZpZXIpIHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfSxcclxuICByZW1vdmUodXNlcklkLCBkb2MpIHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG59KTtcclxuQ2hhbGFuZ2VzLmFsbG93KHtcclxuICBpbnNlcnQodXNlcklkLCBkb2MpIHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfSxcclxuICB1cGRhdGUodXNlcklkLCBkb2MsIGZpZWxkcywgbW9kaWZpZXIpIHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfSxcclxuICByZW1vdmUodXNlcklkLCBkb2MpIHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG59KTtcclxuRXZlbnRzLmFsbG93KHtcclxuICBpbnNlcnQodXNlcklkLCBkb2MpIHtcclxuICAgIGNvbnNvbGUubG9nKHVzZXJJZCk7XHJcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGNvbnNvbGUubG9nKFwianVodVwiKTtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH0sXHJcbiAgdXBkYXRlKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XHJcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH0sXHJcbiAgcmVtb3ZlKHVzZXJJZCwgZG9jKSB7XHJcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxufSk7XHJcbiIsImV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZUZpbHRlcihmaWx0ZXIsIGRlZmF1bHRGaWx0ZXIpIHtcclxuICAgIHZhciBmaWx0ID0ge307XHJcblxyXG4gICAgaWYgKHR5cGVvZiBmaWx0ZXIgIT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICBpZiAoZmlsdGVyICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGlmIChmaWx0ZXIuZmlsdGVycy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZmlsdGVyLmZpbHRlcnMubGVuZ3RoID09PSAxKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHN3aXRjaCAoZmlsdGVyLmZpbHRlcnNbMF0ub3BlcmF0b3IpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJjb250YWluc1wiOlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciB2YWxzID0gZmlsdGVyLmZpbHRlcnNbMF0udmFsdWUuc3BsaXQoXCIgXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxzLmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0W1wiJGFuZFwiXSA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGsgPSAwOyBrIDwgdmFscy5sZW5ndGg7IGsrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgb2JqID0ge307XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9ialtmaWx0ZXIuZmlsdGVyc1swXS5maWVsZF0gPSBuZXcgUmVnRXhwKFwiLipcIiArIHZhbHNba10gKyBcIi4qXCIsICdpJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRbXCIkYW5kXCJdLnB1c2gob2JqKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0W2ZpbHRlci5maWx0ZXJzWzBdLmZpZWxkXSA9IG5ldyBSZWdFeHAoXCIuKlwiICsgZmlsdGVyLmZpbHRlcnNbMF0udmFsdWUgKyBcIi4qXCIsICdpJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJlcVwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdFtmaWx0ZXIuZmlsdGVyc1swXS5maWVsZF0gPSBmaWx0ZXIuZmlsdGVyc1swXS52YWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLy4uLi4uXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdFtcIiRhbmRcIl0gPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IGZpbHRlci5maWx0ZXJzLmxlbmd0aDsgaisrKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKGZpbHRlci5maWx0ZXJzW2pdLm9wZXJhdG9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiY29udGFpbnNcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdmFscyA9IGZpbHRlci5maWx0ZXJzW2pdLnZhbHVlLnNwbGl0KFwiIFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBrID0gMDsgayA8IHZhbHMubGVuZ3RoOyBrKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG9iaiA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmpbZmlsdGVyLmZpbHRlcnNbal0uZmllbGRdID0gbmV3IFJlZ0V4cChcIi4qXCIgKyB2YWxzW2tdICsgXCIuKlwiLCAnaScpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0W1wiJGFuZFwiXS5wdXNoKG9iaik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiZXFcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0W2ZpbHRlci5maWx0ZXJzW2pdLmZpZWxkXSA9IGZpbHRlci5maWx0ZXJzW2pdLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8uLi4uLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKGRlZmF1bHRGaWx0ZXIgIT09IG51bGwpIHtcclxuICAgICAgICByZXR1cm4gZGVmYXVsdEZpbHRlcjtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIGZpbHQ7XHJcbiAgICB9XHJcblxyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZVNvcnRpbmcoc29ydCkge1xyXG4gICAgdmFyIG15U29ydGluZyA9IHt9O1xyXG4gICAgaWYgKHR5cGVvZiBzb3J0WzBdLmRpciAhPT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgIGlmIChzb3J0WzBdLmRpciA9PT0gXCJhc2NcIikge1xyXG4gICAgICAgICAgICBteVNvcnRpbmdbc29ydFswXS5maWVsZF0gPSAxO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIG15U29ydGluZ1tzb3J0WzBdLmZpZWxkXSA9IC0xO1xyXG4gICAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgbXlTb3J0aW5nW3NvcnRbMF0uZmllbGRdID0gMTtcclxuICAgIH1cclxuICAgIHJldHVybiBteVNvcnRpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbml0RmlsdGVyKHNlYXJjaFRleHQsIGZpZWxkc0Fycikge1xyXG4gICAgdmFyIGZpbHQgPSBbXTtcclxuICAgIHZhciBzcCA9IHNlYXJjaFRleHQuc3BsaXQoXCIgXCIpO1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmaWVsZHNBcnIubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICB2YXIgb3IgPSB7fTtcclxuICAgICAgICBvcltcIiRvclwiXSA9IFtdO1xyXG4gICAgICAgIGZvciAodmFyIGcgPSAwOyBnIDwgc3AubGVuZ3RoOyBnKyspIHtcclxuICAgICAgICAgICAgdmFyIHF1ZXJ5ID0ge307XHJcbiAgICAgICAgICAgIHF1ZXJ5W2ZpZWxkc0FycltpXV0gPSB7JyRyZWdleCc6IFwiLipcIiArIHNwW2ddICsgXCIuKlwiLCAnJG9wdGlvbnMnOiAnaSd9O1xyXG4gICAgICAgICAgICBvcltcIiRvclwiXS5wdXNoKHF1ZXJ5KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZmlsdC5wdXNoKG9yKTtcclxuICAgIH1cclxuICAgIHJldHVybiBmaWx0O1xyXG59IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xyXG52YXIgXyA9IHJlcXVpcmUoXCJ1bmRlcnNjb3JlXCIpXHJcbnZhciBuZWVkbGUgPSByZXF1aXJlKCduZWVkbGUnKTtcclxuaW1wb3J0ICogYXMgRnV0dXJlICBmcm9tICdmaWJlcnMvZnV0dXJlJztcclxuXHJcbmRlY2xhcmUgY29uc3QgU2VydmljZUNvbmZpZ3VyYXRpb246IGFueTtcclxuZGVjbGFyZSBjb25zdCBPQXV0aDogYW55O1xyXG5cclxuQWNjb3VudHNbJ3JlZ2lzdGVyTG9naW5IYW5kbGVyJ10oJ2dvb2dsZScsIGZ1bmN0aW9uIChzZXJ2aWNlRGF0YSkge1xyXG4gIGNvbnNvbGUubG9nKFwiaHVodSAxXCIpO1xyXG4gIGNvbnN0IGZ1dCA9IG5ldyBGdXR1cmUoKTtcclxuICBsZXQgbG9naW5SZXF1ZXN0ID0gc2VydmljZURhdGFbJ2dvb2dsZSddO1xyXG5cclxuICBpZiAoIWxvZ2luUmVxdWVzdCkge1xyXG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcclxuICB9XHJcblxyXG4gIGNvbnN0IHNlcnZpY2VDb25maWcgPSBTZXJ2aWNlQ29uZmlndXJhdGlvbi5jb25maWd1cmF0aW9ucy5maW5kT25lKHsgc2VydmljZTogJ2dvb2dsZScgfSk7XHJcbiAgaWYgKCFzZXJ2aWNlQ29uZmlnKVxyXG4gICAgdGhyb3cgbmV3IFNlcnZpY2VDb25maWd1cmF0aW9uLkNvbmZpZ0Vycm9yKCk7XHJcblxyXG5cclxuICBnZXRTY29wZXMobG9naW5SZXF1ZXN0LmFjY2Vzc190b2tlbikudGhlbigocHJvZmlsZTphbnkpID0+IHtcclxuICAgIGlmKHByb2ZpbGUgPT09IG51bGwpe1xyXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMSwgJ0FjY2VzcyBUb2tlbiBpcyBpbnZhbGlkJylcclxuICAgIH1cclxuXHJcbiAgICBjb25zb2xlLmxvZyhcImh1aHUgMlwiKTtcclxuXHJcbiAgICBjb25zdCBleHBpcmVzQXQgPSAoK25ldyBEYXRlKSArICgxMDAwICogcGFyc2VJbnQocHJvZmlsZS5leHBpcmVzX2luLCAxMCkpO1xyXG4gICAgZ2V0SWRlbnRpdHkobG9naW5SZXF1ZXN0LmFjY2Vzc190b2tlbikudGhlbigoaWRlbnRpdHk6YW55KSA9PiB7XHJcbiAgICAgIHNlcnZpY2VEYXRhID0ge1xyXG4gICAgICAgIGFjY2Vzc1Rva2VuOiBsb2dpblJlcXVlc3QuYWNjZXNzX3Rva2VuLFxyXG4gICAgICAgIGV4cGlyZXNBdDogZXhwaXJlc0F0LFxyXG4gICAgICAgIHNjb3BlOiBwcm9maWxlLnNjb3BlLFxyXG4gICAgICB9XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiaHVodSAzXCIpO1xyXG4gICAgICBfLmV4dGVuZChsb2dpblJlcXVlc3QsIGlkZW50aXR5KTtcclxuICAgICAgY29uc3QgZXhpc3RpbmdVc2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyAnc2VydmljZXMuZ29vZ2xlLmVtYWlsJzogbG9naW5SZXF1ZXN0LmVtYWlsIH0pO1xyXG4gICAgICBjb25zb2xlLmxvZyhleGlzdGluZ1VzZXIpO1xyXG4gICAgICBsZXQgdXNlcklkID0gbnVsbDtcclxuICAgICAgaWYgKGV4aXN0aW5nVXNlcikge1xyXG4gICAgICAgIHVzZXJJZCA9IGV4aXN0aW5nVXNlci5faWQ7XHJcbiAgICAgICAgbGV0IHByZWZpeGVkU2VydmljZURhdGEgPSB7fTtcclxuICAgICAgICBfLmVhY2goc2VydmljZURhdGEsICh2YWwsIGtleSkgPT4ge1xyXG4gICAgICAgICAgcHJlZml4ZWRTZXJ2aWNlRGF0YVtgc2VydmljZXMuZ29vZ2xlLiR7a2V5fWBdID0gdmFsO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmKHR5cGVvZiBleGlzdGluZ1VzZXJbJ2Rhc2hib2FyZCddID09PSBcInVuZGVmaW5lZFwiKXtcclxuICAgICAgICAgIHByZWZpeGVkU2VydmljZURhdGFbJ2Rhc2hib2FyZCddID0gW107XHJcbiAgICAgICAgfVxyXG4gICAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoeyBfaWQ6IHVzZXJJZCB9LCB7XHJcbiAgICAgICAgICAkc2V0OiBwcmVmaXhlZFNlcnZpY2VEYXRhLFxyXG4gICAgICAgICAgLy8kYWRkVG9TZXQ6IHsgZW1haWxzOiB7IGFkZHJlc3M6IHNlcnZpY2VEYXRhLmVtYWlsLCB2ZXJpZmllZDogc2VydmljZURhdGEudmVyaWZpZWRfZW1haWwgfSB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICB9ZWxzZXtcclxuICAgICAgICB1c2VySWQgPSBudWxsO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiaHVodSA0XCIpO1xyXG4gICAgICBmdXQucmV0dXJuKHsgdXNlcklkOiB1c2VySWQgfSk7IFxyXG4gICAgfSk7XHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiBmdXQud2FpdCgpO1xyXG59KTtcclxuXHJcbmNvbnN0IGdldElkZW50aXR5ID0gKGFjY2Vzc1Rva2VuKSA9PiB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXMsIHJlaikgPT4ge1xyXG4gICAgbmVlZGxlLmdldChcclxuICAgICAgXCJodHRwczovL3d3dy5nb29nbGVhcGlzLmNvbS9vYXV0aDIvdjEvdXNlcmluZm8/YWNjZXNzX3Rva2VuPVwiICsgYWNjZXNzVG9rZW4sIGZ1bmN0aW9uIChlcnJvciwgcmVzcG9uc2UpIHtcclxuICAgICAgICBpZiAoIWVycm9yICYmIHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICByZXMocmVzcG9uc2UuYm9keSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHJlcyhudWxsKVxyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgfSk7XHJcbn07XHJcbmNvbnN0IGdldFNjb3BlcyA9IChhY2Nlc3NUb2tlbikgPT4ge1xyXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzLCByZWopID0+IHtcclxuICAgIG5lZWRsZS5nZXQoXHJcbiAgICAgIFwiaHR0cHM6Ly93d3cuZ29vZ2xlYXBpcy5jb20vb2F1dGgyL3YxL3Rva2VuaW5mbz9hY2Nlc3NfdG9rZW49XCIgKyBhY2Nlc3NUb2tlbiwgZnVuY3Rpb24gKGVycm9yLCByZXNwb25zZSkge1xyXG4gICAgICAgIGlmICghZXJyb3IgJiYgcmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApIHtcclxuICAgICAgICAgIHJlcyhyZXNwb25zZS5ib2R5KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcmVzKG51bGwpXHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICB9KTtcclxufTtcclxuXHJcbmNvbnN0IGV4Y2hhbmdlQXV0aENvZGUgPSAoYXV0aENvZGUsIGNvbmZpZykgPT4ge1xyXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzLCByZWopID0+IHtcclxuICAgIG5lZWRsZS5wb3N0KFxyXG4gICAgICBcImh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL29hdXRoMi92NC90b2tlblwiLCB7XHJcbiAgICAgICAgY29kZTogYXV0aENvZGUsXHJcbiAgICAgICAgY2xpZW50X2lkOiBjb25maWcuY2xpZW50SWQsXHJcbiAgICAgICAgY2xpZW50X3NlY3JldDogT0F1dGgub3BlblNlY3JldChjb25maWcuc2VjcmV0KSxcclxuICAgICAgICBncmFudF90eXBlOiAnYXV0aG9yaXphdGlvbl9jb2RlJ1xyXG4gICAgICB9LCBmdW5jdGlvbiAoZXJyb3IsIHJlc3BvbnNlKSB7XHJcbiAgICAgICAgaWYgKCFlcnJvciAmJiByZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgcmVzKHJlc3BvbnNlLmJvZHkpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICByZXMobnVsbClcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gIH0pO1xyXG59OyIsInJlcXVpcmUoXCJpc29tb3JwaGljLWZldGNoXCIpO1xyXG5cclxudmFyIG1zID0gcmVxdWlyZShcIkBtaWNyb3NvZnQvbWljcm9zb2Z0LWdyYXBoLWNsaWVudFwiKTtcclxudmFyIHNjb3BlQmFja2VuZCA9XHJcbiAgXCJvcGVuaWQgb2ZmbGluZV9hY2Nlc3MgZW1haWwgcHJvZmlsZSBHcm91cC5SZWFkLkFsbCBHcm91cE1lbWJlci5SZWFkLkFsbCBVc2VyLlJlYWQuQWxsIENhbGVuZGFycy5SZWFkV3JpdGUuU2hhcmVkXCI7XHJcbmNvbnN0IGNyZWRlbnRpYWxzID0ge1xyXG4gIGNsaWVudDoge1xyXG4gICAgaWQ6IFwiNTliYzIyNmQtMDhiNC00MjA0LWE2OGQtNGQ0Yjg4ZjVkMWFlXCIsIC8vOWQ1MmU5OTgtYjM3ZC00ZTY4LTlhY2EtMWY0OTEzM2VmYmU2XHJcbiAgICBzZWNyZXQ6IFwiQnNhRVlYYWh3UHZIY3dGOXA1MVozQ29zP01dZkZkOj1cIiAvL21Nai5OY25vMWx1RUBKMVRGRnNjOkthNmdZM2VAVmFHXHJcbiAgfSxcclxuICBhdXRoOiB7XHJcbiAgICB0b2tlbkhvc3Q6IFwiaHR0cHM6Ly9sb2dpbi5taWNyb3NvZnRvbmxpbmUuY29tXCIsXHJcbiAgICBhdXRob3JpemVQYXRoOiBcIjFmOWExNDhkLTE4M2MtNDA5Yy04ZjZiLTc3OGJlNDNiNWE4Mi9vYXV0aDIvdjIuMC9hdXRob3JpemVcIixcclxuICAgIHRva2VuUGF0aDogXCIxZjlhMTQ4ZC0xODNjLTQwOWMtOGY2Yi03NzhiZTQzYjVhODIvb2F1dGgyL3YyLjAvdG9rZW5cIlxyXG4gIH1cclxufTtcclxuY29uc3Qgb2F1dGgyID0gcmVxdWlyZShcInNpbXBsZS1vYXV0aDJcIikuY3JlYXRlKGNyZWRlbnRpYWxzKTtcclxuaW1wb3J0IHsgVXNlcnMsIFRlYW1zIH0gZnJvbSBcIi4uL2NvbGxlY3Rpb25zL2luZGV4XCI7XHJcbmltcG9ydCB7IFN5bmNlciB9IGZyb20gXCIuLi9jb2xsZWN0aW9ucy9pbmRleFwiO1xyXG52YXIgbmVlZGxlID0gcmVxdWlyZShcIm5lZWRsZVwiKTtcclxuZXhwb3J0IGZ1bmN0aW9uIHJlYWREYXRhRnJvbVNwcmVhZHNoZWV0KHNwcklEKSB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNwLCByZWopID0+IHtcclxuICAgIHZhciBvYmogPSB7fTtcclxuXHJcbiAgICB2YXIgdHogPSBTeW5jZXIuZmluZCh7fSkuY3Vyc29yLmZldGNoKCk7XHJcbiAgICBvYXV0aDIuYWNjZXNzVG9rZW5cclxuICAgICAgLmNyZWF0ZSh7IHJlZnJlc2hfdG9rZW46IHR6WzBdLnJlZnJlc2hfdG9rZW4gfSlcclxuICAgICAgLnJlZnJlc2goKVxyXG4gICAgICAudGhlbihkYXRhID0+IHtcclxuICAgICAgICBjb25zdCBjbGllbnQgPSBtcy5DbGllbnQuaW5pdCh7XHJcbiAgICAgICAgICBkZWZhdWx0VmVyc2lvbjogXCJ2MS4wXCIsXHJcbiAgICAgICAgICBkZWJ1Z0xvZ2dpbmc6IGZhbHNlLFxyXG4gICAgICAgICAgYXV0aFByb3ZpZGVyOiBkb25lID0+IHtcclxuICAgICAgICAgICAgZG9uZShudWxsLCBkYXRhLnRva2VuLmFjY2Vzc190b2tlbik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNsaWVudFxyXG4gICAgICAgICAgLmFwaShcclxuICAgICAgICAgICAgXCIvbWUvZHJpdmUvaXRlbXMvMDFVVEVVRUNHTjNESVdSRlhJUTVHWkhTSTUyV1hVUVNPTC93b3JrYm9vay93b3Jrc2hlZXRzXCJcclxuICAgICAgICAgIClcclxuICAgICAgICAgIC5nZXQoKVxyXG4gICAgICAgICAgLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmVzcChyZXMpO1xyXG4gICAgICAgICAgfSlcclxuICAgICAgICAgIC5jYXRjaChlcnIgPT4ge1xyXG4gICAgICAgICAgICByZXNwKGVycik7XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRQaG90b0Zyb21JZChpZCkge1xyXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzLCByZWopID0+IHtcclxuICAgIC8vL21lL3Bob3Rvcy8xMjB4MTIwLyR2YWx1ZVxyXG4gICAgdmFyIHR6ID0gU3luY2VyLmZpbmQoe30pLmN1cnNvci5mZXRjaCgpO1xyXG4gICAgb2F1dGgyLmFjY2Vzc1Rva2VuXHJcbiAgICAgIC5jcmVhdGUoeyByZWZyZXNoX3Rva2VuOiB0elswXS5yZWZyZXNoX3Rva2VuIH0pXHJcbiAgICAgIC5yZWZyZXNoKClcclxuICAgICAgLnRoZW4oZGF0YSA9PiB7XHJcbiAgICAgICAgdmFyIG9wdGlvbnMgPSB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7IGF1dGhvcml6YXRpb246IFwiYmVhcmVyIFwiICsgZGF0YS50b2tlbi5hY2Nlc3NfdG9rZW4gfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgLy9cclxuICAgICAgICBuZWVkbGUuZ2V0KFxyXG4gICAgICAgICAgXCJodHRwczovL2dyYXBoLm1pY3Jvc29mdC5jb20vdjEuMC91c2Vycy9cIiArXHJcbiAgICAgICAgICAgIGlkICtcclxuICAgICAgICAgICAgXCIvcGhvdG9zLzEyMHgxMjAvJHZhbHVlXCIsXHJcbiAgICAgICAgICBvcHRpb25zLFxyXG4gICAgICAgICAgTWV0ZW9yLmJpbmRFbnZpcm9ubWVudCgoZXJyLCByZXNwKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgcmVzcC5ib2R5LmVycm9yICE9PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgICAgICAgcmVzKHtcclxuICAgICAgICAgICAgICAgIGVycm9yOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgY29udGVudFR5cGU6IG51bGwsXHJcbiAgICAgICAgICAgICAgICBkYXRhOiBudWxsXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgcmVzKHtcclxuICAgICAgICAgICAgICAgIGVycm9yOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGNvbnRlbnRUeXBlOiByZXNwLmhlYWRlcnNbXCJjb250ZW50LXR5cGVcIl0sXHJcbiAgICAgICAgICAgICAgICBkYXRhOiByZXNwLmJvZHkudG9TdHJpbmcoXCJiYXNlNjRcIilcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSlcclxuICAgICAgICApO1xyXG4gICAgICB9KTtcclxuICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZURhdGFUb1NwcmVhZHNoZWV0T25lRHJpdmUoXHJcbiAgc3BySUQsXHJcbiAgV29ya2Jvb2ssXHJcbiAgRGF0YSxcclxuICBDb2x1bW5zTGVuZ3RoLFxyXG4gIERhdGFMZW5ndGhcclxuKSB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNwLCByZWopID0+IHtcclxuICAgIHZhciBvYmogPSB7XHJcbiAgICAgIHZhbHVlczogW0RhdGFdXHJcbiAgICB9O1xyXG4gICAgY29uc29sZS5sb2cob2JqKTtcclxuICAgIHZhciB0eiA9IFN5bmNlci5maW5kKHt9KS5jdXJzb3IuZmV0Y2goKTtcclxuICAgIG9hdXRoMi5hY2Nlc3NUb2tlblxyXG4gICAgICAuY3JlYXRlKHsgcmVmcmVzaF90b2tlbjogdHpbMF0ucmVmcmVzaF90b2tlbiB9KVxyXG4gICAgICAucmVmcmVzaCgpXHJcbiAgICAgIC50aGVuKGRhdGEgPT4ge1xyXG4gICAgICAgIGNvbnN0IGNsaWVudCA9IG1zLkNsaWVudC5pbml0KHtcclxuICAgICAgICAgIGRlZmF1bHRWZXJzaW9uOiBcInYxLjBcIixcclxuICAgICAgICAgIGRlYnVnTG9nZ2luZzogZmFsc2UsXHJcbiAgICAgICAgICBhdXRoUHJvdmlkZXI6IGRvbmUgPT4ge1xyXG4gICAgICAgICAgICBkb25lKG51bGwsIGRhdGEudG9rZW4uYWNjZXNzX3Rva2VuKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICBjbGllbnRcclxuICAgICAgICAgIC5hcGkoXHJcbiAgICAgICAgICAgIFwiL21lL2RyaXZlL2l0ZW1zL1wiICtcclxuICAgICAgICAgICAgICBzcHJJRCArXHJcbiAgICAgICAgICAgICAgXCIvd29ya2Jvb2svd29ya3NoZWV0cy9cIiArXHJcbiAgICAgICAgICAgICAgV29ya2Jvb2sgK1xyXG4gICAgICAgICAgICAgIFwiL3VzZWRSYW5nZVwiXHJcbiAgICAgICAgICApXHJcbiAgICAgICAgICAuZ2V0KClcclxuICAgICAgICAgIC50aGVuKHJhbmdlID0+IHtcclxuICAgICAgICAgICAgY2xpZW50XHJcbiAgICAgICAgICAgICAgLmFwaShcIi9tZS9kcml2ZS9pdGVtcy9cIiArIHNwcklEICsgXCIvd29ya2Jvb2svY3JlYXRlU2Vzc2lvblwiKVxyXG4gICAgICAgICAgICAgIC5wb3N0KHtcclxuICAgICAgICAgICAgICAgIHBlcnNpc3RDaGFuZ2VzOiB0cnVlXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXHJcbiAgICAgICAgICAgICAgICAgIFwiL21lL2RyaXZlL2l0ZW1zL1wiICtcclxuICAgICAgICAgICAgICAgICAgICBzcHJJRCArXHJcbiAgICAgICAgICAgICAgICAgICAgXCIvd29ya2Jvb2svd29ya3NoZWV0cy9cIiArXHJcbiAgICAgICAgICAgICAgICAgICAgV29ya2Jvb2sgK1xyXG4gICAgICAgICAgICAgICAgICAgIFwiL3JhbmdlKGFkZHJlc3M9J0FcIiArXHJcbiAgICAgICAgICAgICAgICAgICAgKHJhbmdlLnJvd0NvdW50ICsgMSkgK1xyXG4gICAgICAgICAgICAgICAgICAgIFwiOlwiICtcclxuICAgICAgICAgICAgICAgICAgICBjYWxjQnVjaHN0YWJlKENvbHVtbnNMZW5ndGgpICtcclxuICAgICAgICAgICAgICAgICAgICAoRGF0YUxlbmd0aCArIHJhbmdlLnJvd0NvdW50KSArXHJcbiAgICAgICAgICAgICAgICAgICAgXCInKVwiXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgY2xpZW50XHJcbiAgICAgICAgICAgICAgICAgIC5hcGkoXHJcbiAgICAgICAgICAgICAgICAgICAgXCIvbWUvZHJpdmUvaXRlbXMvXCIgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgc3BySUQgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgXCIvd29ya2Jvb2svd29ya3NoZWV0cy9cIiArXHJcbiAgICAgICAgICAgICAgICAgICAgICBXb3JrYm9vayArXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIi9yYW5nZShhZGRyZXNzPSdBXCIgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgKHJhbmdlLnJvd0NvdW50ICsgMSkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgXCI6XCIgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgY2FsY0J1Y2hzdGFiZShDb2x1bW5zTGVuZ3RoKSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAoMSArIHJhbmdlLnJvd0NvdW50KSArXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIicpXCJcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAuaGVhZGVyKFwid29ya2Jvb2stc2Vzc2lvbi1pZFwiLCByZXMuaWQpXHJcbiAgICAgICAgICAgICAgICAgIC5wYXRjaChvYmopXHJcbiAgICAgICAgICAgICAgICAgIC50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzcChyZXMpO1xyXG4gICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICAgICAgICAgICAgICByZXNwKGVycik7XHJcbiAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXNwKGVycik7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgIHJlc3AoZXJyKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICB9KTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gdXBsb2FkRGF0YVRvU3ByZWFkc2hlZXRPbmVEcml2ZShcclxuICBzcHJJRCxcclxuICBXb3JrYm9vayxcclxuICBEYXRhLFxyXG4gIERhdGFMZW5ndGgsXHJcbiAgQ29sdW1uc0xlbmd0aFxyXG4pIHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc3AsIHJlaikgPT4ge1xyXG4gICAgdmFyIG9iaiA9IHtcclxuICAgICAgdmFsdWVzOiBEYXRhXHJcbiAgICB9O1xyXG4gICAgY29uc29sZS5sb2coY2FsY0J1Y2hzdGFiZShDb2x1bW5zTGVuZ3RoKSArIERhdGFMZW5ndGgpO1xyXG4gICAgdmFyIHR6ID0gU3luY2VyLmZpbmQoe30pLmN1cnNvci5mZXRjaCgpO1xyXG4gICAgb2F1dGgyLmFjY2Vzc1Rva2VuXHJcbiAgICAgIC5jcmVhdGUoeyByZWZyZXNoX3Rva2VuOiB0elswXS5yZWZyZXNoX3Rva2VuIH0pXHJcbiAgICAgIC5yZWZyZXNoKClcclxuICAgICAgLnRoZW4oZGF0YSA9PiB7XHJcbiAgICAgICAgY29uc3QgY2xpZW50ID0gbXMuQ2xpZW50LmluaXQoe1xyXG4gICAgICAgICAgZGVmYXVsdFZlcnNpb246IFwidjEuMFwiLFxyXG4gICAgICAgICAgZGVidWdMb2dnaW5nOiBmYWxzZSxcclxuICAgICAgICAgIGF1dGhQcm92aWRlcjogZG9uZSA9PiB7XHJcbiAgICAgICAgICAgIGRvbmUobnVsbCwgZGF0YS50b2tlbi5hY2Nlc3NfdG9rZW4pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNsaWVudFxyXG4gICAgICAgICAgLmFwaShcIi9tZS9kcml2ZS9pdGVtcy9cIiArIHNwcklEICsgXCIvd29ya2Jvb2svY3JlYXRlU2Vzc2lvblwiKVxyXG4gICAgICAgICAgLnBvc3Qoe1xyXG4gICAgICAgICAgICBwZXJzaXN0Q2hhbmdlczogdHJ1ZVxyXG4gICAgICAgICAgfSlcclxuICAgICAgICAgIC50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIGNsaWVudFxyXG4gICAgICAgICAgICAgIC5hcGkoXHJcbiAgICAgICAgICAgICAgICBcIi9tZS9kcml2ZS9pdGVtcy9cIiArXHJcbiAgICAgICAgICAgICAgICAgIHNwcklEICtcclxuICAgICAgICAgICAgICAgICAgXCIvd29ya2Jvb2svd29ya3NoZWV0cy9cIiArXHJcbiAgICAgICAgICAgICAgICAgIFdvcmtib29rICtcclxuICAgICAgICAgICAgICAgICAgXCIvcmFuZ2UoYWRkcmVzcz0nQTE6XCIgK1xyXG4gICAgICAgICAgICAgICAgICBjYWxjQnVjaHN0YWJlKENvbHVtbnNMZW5ndGgpICtcclxuICAgICAgICAgICAgICAgICAgRGF0YUxlbmd0aCArXHJcbiAgICAgICAgICAgICAgICAgIFwiJylcIlxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAuaGVhZGVyKFwid29ya2Jvb2stc2Vzc2lvbi1pZFwiLCByZXMuaWQpXHJcbiAgICAgICAgICAgICAgLnBhdGNoKG9iailcclxuICAgICAgICAgICAgICAudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmVzcChyZXMpO1xyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXNwKGVycik7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgIHJlc3AoZXJyKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICB9KTtcclxufVxyXG5cclxuZnVuY3Rpb24gY2FsY0J1Y2hzdGFiZShDb2x1bW5zTGVuZ3RoOiBudW1iZXIpIHtcclxuICB2YXIgYWwgPSBbXHJcbiAgICBcIkFcIixcclxuICAgIFwiQlwiLFxyXG4gICAgXCJDXCIsXHJcbiAgICBcIkRcIixcclxuICAgIFwiRVwiLFxyXG4gICAgXCJGXCIsXHJcbiAgICBcIkdcIixcclxuICAgIFwiSFwiLFxyXG4gICAgXCJJXCIsXHJcbiAgICBcIkpcIixcclxuICAgIFwiS1wiLFxyXG4gICAgXCJMXCIsXHJcbiAgICBcIk1cIixcclxuICAgIFwiTlwiLFxyXG4gICAgXCJPXCIsXHJcbiAgICBcIlBcIixcclxuICAgIFwiUVwiLFxyXG4gICAgXCJSXCIsXHJcbiAgICBcIlNcIixcclxuICAgIFwiVFwiLFxyXG4gICAgXCJVXCIsXHJcbiAgICBcIlZcIixcclxuICAgIFwiV1wiLFxyXG4gICAgXCJYXCIsXHJcbiAgICBcIllcIixcclxuICAgIFwiWlwiXHJcbiAgXTtcclxuXHJcbiAgaWYgKENvbHVtbnNMZW5ndGggPCBhbC5sZW5ndGgpIHtcclxuICAgIHJldHVybiBhbFtDb2x1bW5zTGVuZ3RoIC0gMV07XHJcbiAgfSBlbHNlIHtcclxuICAgIHZhciB0ZXN0ZXIgPSBDb2x1bW5zTGVuZ3RoICUgYWwubGVuZ3RoO1xyXG4gICAgdmFyIHRlaWwgPSBNYXRoLnJvdW5kKENvbHVtbnNMZW5ndGggLyBhbC5sZW5ndGgpO1xyXG4gICAgdmFyIHJ0ID0gXCJcIjtcclxuICAgIGZvciAodmFyIG8gPSAwOyBvIDwgdGVpbDsgbysrKSB7XHJcbiAgICAgIGlmIChvID09PSB0ZWlsIC0gMSkge1xyXG4gICAgICAgIHJ0ID0gcnQgKyBhbFt0ZXN0ZXIgLSAxXTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBydCA9IHJ0ICsgXCJaXCI7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB1cGxvYWREYXRhVG9TcHJlYWRzaGVldChzcHJJRCwgV29ya2Jvb2ssIERhdGEpIHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc3AsIHJlaikgPT4ge1xyXG4gICAgdmFyIG9iaiA9IHtcclxuICAgICAgdmFsdWVzOiBbXHJcbiAgICAgICAgW1wiVGVzdFwiLCBcIlZhbHVlXCJdLFxyXG4gICAgICAgIFtcIkZvclwiLCBcIlVwZGF0ZVwiXVxyXG4gICAgICBdXHJcbiAgICB9O1xyXG5cclxuICAgIHZhciB0eiA9IFN5bmNlci5maW5kKHt9KS5jdXJzb3IuZmV0Y2goKTtcclxuICAgIG9hdXRoMi5hY2Nlc3NUb2tlblxyXG4gICAgICAuY3JlYXRlKHsgcmVmcmVzaF90b2tlbjogdHpbMF0ucmVmcmVzaF90b2tlbiB9KVxyXG4gICAgICAucmVmcmVzaCgpXHJcbiAgICAgIC50aGVuKGRhdGEgPT4ge1xyXG4gICAgICAgIGNvbnN0IGNsaWVudCA9IG1zLkNsaWVudC5pbml0KHtcclxuICAgICAgICAgIGRlZmF1bHRWZXJzaW9uOiBcInYxLjBcIixcclxuICAgICAgICAgIGRlYnVnTG9nZ2luZzogZmFsc2UsXHJcbiAgICAgICAgICBhdXRoUHJvdmlkZXI6IGRvbmUgPT4ge1xyXG4gICAgICAgICAgICBkb25lKG51bGwsIGRhdGEudG9rZW4uYWNjZXNzX3Rva2VuKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICBjbGllbnRcclxuICAgICAgICAgIC5hcGkoXHJcbiAgICAgICAgICAgIFwiL21lL2RyaXZlL2l0ZW1zLzAxUk5KR0JFUlpORkE2REdaV001REw3VUtGSDYyVFdJR0Qvd29ya2Jvb2svY3JlYXRlU2Vzc2lvblwiXHJcbiAgICAgICAgICApXHJcbiAgICAgICAgICAucG9zdCh7XHJcbiAgICAgICAgICAgIHBlcnNpc3RDaGFuZ2VzOiB0cnVlXHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICAgLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2cocmVzKTtcclxuICAgICAgICAgICAgY2xpZW50XHJcbiAgICAgICAgICAgICAgLmFwaShcclxuICAgICAgICAgICAgICAgIFwiL21lL2RyaXZlL2l0ZW1zLzAxUk5KR0JFUlpORkE2REdaV001REw3VUtGSDYyVFdJR0Qvd29ya2Jvb2svd29ya3NoZWV0cy9kYXRhL3JhbmdlKGFkZHJlc3M9J0ExOkIyJylcIlxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAuaGVhZGVyKFwid29ya2Jvb2stc2Vzc2lvbi1pZFwiLCByZXMuaWQpXHJcbiAgICAgICAgICAgICAgLnBhdGNoKG9iailcclxuICAgICAgICAgICAgICAudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmVzcChyZXMpO1xyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXNwKGVycik7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgIHJlc3AoZXJyKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNlbmRFbWFpbCh0bywgY2MsIHN1YmpldCwgYm9keSkge1xyXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzcCwgcmVqKSA9PiB7XHJcbiAgICB2YXIgb2JqID0ge1xyXG4gICAgICBtZXNzYWdlOiB7XHJcbiAgICAgICAgc3ViamVjdDogc3ViamV0LFxyXG4gICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgIGNvbnRlbnRUeXBlOiBcIkhUTUxcIixcclxuICAgICAgICAgIGNvbnRlbnQ6IGJvZHlcclxuICAgICAgICB9LFxyXG4gICAgICAgIHRvUmVjaXBpZW50czogW10sXHJcbiAgICAgICAgY2NSZWNpcGllbnRzOiBbXVxyXG4gICAgICB9LFxyXG4gICAgICBzYXZlVG9TZW50SXRlbXM6IFwiZmFsc2VcIlxyXG4gICAgfTtcclxuICAgIGZvciAodmFyIGwgPSAwOyBsIDwgdG8ubGVuZ3RoOyBsKyspIHtcclxuICAgICAgb2JqLm1lc3NhZ2UudG9SZWNpcGllbnRzLnB1c2goe1xyXG4gICAgICAgIGVtYWlsQWRkcmVzczoge1xyXG4gICAgICAgICAgYWRkcmVzczogdG9bbF1cclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgZm9yICh2YXIgcCA9IDA7IHAgPCBjYy5sZW5ndGg7IHArKykge1xyXG4gICAgICBvYmoubWVzc2FnZS5jY1JlY2lwaWVudHMucHVzaCh7XHJcbiAgICAgICAgZW1haWxBZGRyZXNzOiB7XHJcbiAgICAgICAgICBhZGRyZXNzOiBjY1tsXVxyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgdmFyIHR6ID0gU3luY2VyLmZpbmQoe30pLmN1cnNvci5mZXRjaCgpO1xyXG4gICAgb2F1dGgyLmFjY2Vzc1Rva2VuXHJcbiAgICAgIC5jcmVhdGUoeyByZWZyZXNoX3Rva2VuOiB0elswXS5yZWZyZXNoX3Rva2VuIH0pXHJcbiAgICAgIC5yZWZyZXNoKClcclxuICAgICAgLnRoZW4oZGF0YSA9PiB7XHJcbiAgICAgICAgY29uc3QgY2xpZW50ID0gbXMuQ2xpZW50LmluaXQoe1xyXG4gICAgICAgICAgZGVmYXVsdFZlcnNpb246IFwidjEuMFwiLFxyXG4gICAgICAgICAgZGVidWdMb2dnaW5nOiBmYWxzZSxcclxuICAgICAgICAgIGF1dGhQcm92aWRlcjogZG9uZSA9PiB7XHJcbiAgICAgICAgICAgIGRvbmUobnVsbCwgZGF0YS50b2tlbi5hY2Nlc3NfdG9rZW4pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjbGllbnRcclxuICAgICAgICAgIC5hcGkoXCIvbWUvc2VuZE1haWxcIilcclxuICAgICAgICAgIC5wb3N0KG9iailcclxuICAgICAgICAgIC50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJlc3AocmVzKTtcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgICAuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICAgICAgcmVzcChlcnIpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlRXZlbnQodGl0bGUsIGRlc2NyaXB0aW9uLCBzdGFydCwgZW5kLCBlbWFpbCkge1xyXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzcCwgcmVqKSA9PiB7XHJcbiAgICB2YXIgb2JqID0ge1xyXG4gICAgICBzdWJqZWN0OiB0aXRsZSxcclxuICAgICAgYm9keToge1xyXG4gICAgICAgIGNvbnRlbnRUeXBlOiBcIkhUTUxcIixcclxuICAgICAgICBjb250ZW50OiBkZXNjcmlwdGlvblxyXG4gICAgICB9LFxyXG4gICAgICBzdGFydDoge1xyXG4gICAgICAgIGRhdGVUaW1lOiBzdGFydCxcclxuICAgICAgICB0aW1lWm9uZTogXCJFdXJvcGEvQmVybGluXCJcclxuICAgICAgfSxcclxuICAgICAgZW5kOiB7XHJcbiAgICAgICAgZGF0ZVRpbWU6IGVuZCxcclxuICAgICAgICB0aW1lWm9uZTogXCJFdXJvcGEvQmVybGluXCJcclxuICAgICAgfSxcclxuICAgICAgaXNBbGxEYXk6IHRydWUsXHJcbiAgICAgIGF0dGVuZGVlczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGVtYWlsQWRkcmVzczoge1xyXG4gICAgICAgICAgICBhZGRyZXNzOiBlbWFpbFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHR5cGU6IFwicmVxdWlyZWRcIlxyXG4gICAgICAgIH1cclxuICAgICAgXVxyXG4gICAgfTtcclxuXHJcbiAgICB2YXIgdHogPSBTeW5jZXIuZmluZCh7fSkuY3Vyc29yLmZldGNoKCk7XHJcbiAgICBvYXV0aDIuYWNjZXNzVG9rZW5cclxuICAgICAgLmNyZWF0ZSh7IHJlZnJlc2hfdG9rZW46IHR6WzBdLnJlZnJlc2hfdG9rZW4gfSlcclxuICAgICAgLnJlZnJlc2goKVxyXG4gICAgICAudGhlbihkYXRhID0+IHtcclxuICAgICAgICBjb25zdCBjbGllbnQgPSBtcy5DbGllbnQuaW5pdCh7XHJcbiAgICAgICAgICBkZWZhdWx0VmVyc2lvbjogXCJ2MS4wXCIsXHJcbiAgICAgICAgICBkZWJ1Z0xvZ2dpbmc6IGZhbHNlLFxyXG4gICAgICAgICAgYXV0aFByb3ZpZGVyOiBkb25lID0+IHtcclxuICAgICAgICAgICAgZG9uZShudWxsLCBkYXRhLnRva2VuLmFjY2Vzc190b2tlbik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNsaWVudFxyXG4gICAgICAgICAgLmFwaShcIi9tZS9ldmVudHNcIilcclxuICAgICAgICAgIC5wb3N0KG9iailcclxuICAgICAgICAgIC50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJlc3AocmVzKTtcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgICAuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICAgICAgcmVzcChlcnIpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gIH0pO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBkZWx0ZUV2ZW50KGlkKSB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNwLCByZWopID0+IHtcclxuICAgIHZhciB0eiA9IFN5bmNlci5maW5kKHt9KS5jdXJzb3IuZmV0Y2goKTtcclxuICAgIG9hdXRoMi5hY2Nlc3NUb2tlblxyXG4gICAgICAuY3JlYXRlKHsgcmVmcmVzaF90b2tlbjogdHpbMF0ucmVmcmVzaF90b2tlbiB9KVxyXG4gICAgICAucmVmcmVzaCgpXHJcbiAgICAgIC50aGVuKGRhdGEgPT4ge1xyXG4gICAgICAgIGNvbnN0IGNsaWVudCA9IG1zLkNsaWVudC5pbml0KHtcclxuICAgICAgICAgIGRlZmF1bHRWZXJzaW9uOiBcInYxLjBcIixcclxuICAgICAgICAgIGRlYnVnTG9nZ2luZzogZmFsc2UsXHJcbiAgICAgICAgICBhdXRoUHJvdmlkZXI6IGRvbmUgPT4ge1xyXG4gICAgICAgICAgICBkb25lKG51bGwsIGRhdGEudG9rZW4uYWNjZXNzX3Rva2VuKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY2xpZW50XHJcbiAgICAgICAgICAuYXBpKFwiL21lL2V2ZW50cy9cIiArIGlkKVxyXG4gICAgICAgICAgLmRlbGV0ZSgpXHJcbiAgICAgICAgICAudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXNwKHJlcyk7XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgIHJlc3AoZXJyKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICB9KTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlRXZlbnQoaWQsIHRpdGxlLCBkZXNjcmlwdGlvbiwgc3RhcnQsIGVuZCwgZW1haWwpIHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc3AsIHJlaikgPT4ge1xyXG4gICAgdmFyIG9iaiA9IHtcclxuICAgICAgc3ViamVjdDogdGl0bGUsXHJcbiAgICAgIGJvZHk6IHtcclxuICAgICAgICBjb250ZW50VHlwZTogXCJIVE1MXCIsXHJcbiAgICAgICAgY29udGVudDogZGVzY3JpcHRpb25cclxuICAgICAgfSxcclxuICAgICAgc3RhcnQ6IHtcclxuICAgICAgICBkYXRlVGltZTogc3RhcnQsXHJcbiAgICAgICAgdGltZVpvbmU6IFwiRXVyb3BhL0JlcmxpblwiXHJcbiAgICAgIH0sXHJcbiAgICAgIGVuZDoge1xyXG4gICAgICAgIGRhdGVUaW1lOiBlbmQsXHJcbiAgICAgICAgdGltZVpvbmU6IFwiRXVyb3BhL0JlcmxpblwiXHJcbiAgICAgIH0sXHJcbiAgICAgIGlzQWxsRGF5OiB0cnVlLFxyXG4gICAgICBhdHRlbmRlZXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBlbWFpbEFkZHJlc3M6IHtcclxuICAgICAgICAgICAgYWRkcmVzczogZW1haWxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB0eXBlOiBcInJlcXVpcmVkXCJcclxuICAgICAgICB9XHJcbiAgICAgIF1cclxuICAgIH07XHJcblxyXG4gICAgdmFyIHR6ID0gU3luY2VyLmZpbmQoe30pLmN1cnNvci5mZXRjaCgpO1xyXG4gICAgb2F1dGgyLmFjY2Vzc1Rva2VuXHJcbiAgICAgIC5jcmVhdGUoeyByZWZyZXNoX3Rva2VuOiB0elswXS5yZWZyZXNoX3Rva2VuIH0pXHJcbiAgICAgIC5yZWZyZXNoKClcclxuICAgICAgLnRoZW4oZGF0YSA9PiB7XHJcbiAgICAgICAgY29uc3QgY2xpZW50ID0gbXMuQ2xpZW50LmluaXQoe1xyXG4gICAgICAgICAgZGVmYXVsdFZlcnNpb246IFwidjEuMFwiLFxyXG4gICAgICAgICAgZGVidWdMb2dnaW5nOiBmYWxzZSxcclxuICAgICAgICAgIGF1dGhQcm92aWRlcjogZG9uZSA9PiB7XHJcbiAgICAgICAgICAgIGRvbmUobnVsbCwgZGF0YS50b2tlbi5hY2Nlc3NfdG9rZW4pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjbGllbnRcclxuICAgICAgICAgIC5hcGkoXCIvbWUvZXZlbnRzL1wiICsgaWQpXHJcbiAgICAgICAgICAucHV0KG9iailcclxuICAgICAgICAgIC50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJlc3AocmVzKTtcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgICAuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICAgICAgcmVzcChlcnIpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0R3JvdXBMaXN0KCkge1xyXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzcCwgcmVqKSA9PiB7XHJcbiAgICB2YXIgdHogPSBTeW5jZXIuZmluZCh7fSkuY3Vyc29yLmZldGNoKCk7XHJcblxyXG4gICAgb2F1dGgyLmFjY2Vzc1Rva2VuXHJcbiAgICAgIC5jcmVhdGUoeyByZWZyZXNoX3Rva2VuOiB0elswXS5yZWZyZXNoX3Rva2VuIH0pXHJcbiAgICAgIC5yZWZyZXNoKClcclxuICAgICAgLnRoZW4oZGF0YSA9PiB7XHJcbiAgICAgICAgY29uc3QgY2xpZW50ID0gbXMuQ2xpZW50LmluaXQoe1xyXG4gICAgICAgICAgZGVmYXVsdFZlcnNpb246IFwidjEuMFwiLFxyXG4gICAgICAgICAgZGVidWdMb2dnaW5nOiBmYWxzZSxcclxuICAgICAgICAgIGF1dGhQcm92aWRlcjogZG9uZSA9PiB7XHJcbiAgICAgICAgICAgIGRvbmUobnVsbCwgZGF0YS50b2tlbi5hY2Nlc3NfdG9rZW4pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNsaWVudFxyXG4gICAgICAgICAgLmFwaShcIi9ncm91cHNcIilcclxuXHJcbiAgICAgICAgICAuZ2V0KClcclxuICAgICAgICAgIC50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHZhciB0ZW1wVmFsdWUgPSByZXMudmFsdWU7XHJcbiAgICAgICAgICAgIHZhciBwcm9tID0gW107XHJcblxyXG4gICAgICAgICAgICBmb3IgKHZhciBsID0gMDsgbCA8IHRlbXBWYWx1ZS5sZW5ndGg7IGwrKykge1xyXG4gICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgIHRlbXBWYWx1ZVtsXS5kaXNwbGF5TmFtZS5pbmRleE9mKFwidGVhbVwiKSAhPT0gLTEgfHxcclxuICAgICAgICAgICAgICAgIHRlbXBWYWx1ZVtsXS5kaXNwbGF5TmFtZS5pbmRleE9mKFwiVGVhbVwiKSAhPT0gLTFcclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICBwcm9tLnB1c2goZ2V0R3JvdXBEYXRhaWwodGVtcFZhbHVlW2xdLCBjbGllbnQpKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgUHJvbWlzZS5hbGwocHJvbSkudGhlbihkYXRhID0+IHtcclxuICAgICAgICAgICAgICByZXNwKGRhdGEpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgICAuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICAgICAgcmVzcChlcnIpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gIH0pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRHcm91cERhdGFpbChncm91cCwgY2xpZW50KSB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXMsIHJlaikgPT4ge1xyXG4gICAgY2xpZW50XHJcbiAgICAgIC5hcGkoXCIvZ3JvdXBzL1wiICsgZ3JvdXAuaWQgKyBcIi9tZW1iZXJzXCIpXHJcbiAgICAgIC5nZXQoKVxyXG4gICAgICAudGhlbih1c2VySWRzID0+IHtcclxuICAgICAgICB2YXIgdHp1ID0gW107XHJcbiAgICAgICAgdmFyIHR6dWFkbWluID0gW107XHJcbiAgICAgICAgY29uc29sZS5sb2codXNlcklkcyk7XHJcbiAgICAgICAgZm9yICh2YXIgbyA9IDA7IG8gPCB1c2VySWRzLnZhbHVlLmxlbmd0aDsgbysrKSB7XHJcbiAgICAgICAgICBpZiAodHlwZW9mIHVzZXJJZHMudmFsdWVbb10gIT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICAgICAgdHp1LnB1c2godXNlcklkcy52YWx1ZVtvXSk7XHJcbiAgICAgICAgICAgIGlmICh1c2VySWRzLnZhbHVlW29dLmpvYlRpdGxlID09PSBcIlRlYW0gTGVhZFwiKSB7XHJcbiAgICAgICAgICAgICAgdHp1YWRtaW4ucHVzaCh1c2VySWRzLnZhbHVlW29dKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBncm91cC51c2VyTGlzdCA9IHR6dTtcclxuICAgICAgICBncm91cC5hZG1pblVzZXJMaXN0ID0gdHp1YWRtaW47XHJcbiAgICAgICAgcmVzKGdyb3VwKTtcclxuICAgICAgfSk7XHJcbiAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzeW5jVXNlckFuZEdyb3VwcygpIHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlcywgcmVqKSA9PiB7XHJcbiAgICBnZXRHcm91cExpc3QoKS50aGVuKGRhdGEgPT4ge1xyXG4gICAgICB2YXIgR3JvdXBMaXN0ID0gVGVhbXMuZmluZCh7fSkuY3Vyc29yLmZldGNoKCk7XHJcbiAgICAgIGNoZWNrR3JvdXAoR3JvdXBMaXN0LCBkYXRhLCAwLCBkYXRhTGlzdHMgPT4ge1xyXG4gICAgICAgIHZhciBVc2VyTGlzdCA9IFVzZXJzLmZpbmQoe30pLmN1cnNvci5mZXRjaCgpO1xyXG4gICAgICAgIHZhciBVc2VyT0xpc3QgPSBbXTtcclxuICAgICAgICBmb3IgKHZhciB6ID0gMDsgeiA8IGRhdGFMaXN0cy5sZW5ndGg7IHorKykge1xyXG4gICAgICAgICAgZm9yICh2YXIgeSA9IDA7IHkgPCBkYXRhTGlzdHNbel0udXNlckxpc3QubGVuZ3RoOyB5KyspIHtcclxuICAgICAgICAgICAgdmFyIGZvdW5kID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGsgPSAwOyBrIDwgVXNlck9MaXN0Lmxlbmd0aDsgaysrKSB7XHJcbiAgICAgICAgICAgICAgaWYgKFVzZXJPTGlzdFtrXS5pZCA9PT0gZGF0YUxpc3RzW3pdLnVzZXJMaXN0W3ldLmlkKSB7XHJcbiAgICAgICAgICAgICAgICBmb3VuZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChmb3VuZCA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICBVc2VyT0xpc3QucHVzaChkYXRhTGlzdHNbel0udXNlckxpc3RbeV0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHVwZGF0ZVVzZXIoVXNlckxpc3QsIFVzZXJPTGlzdCwgMCwgKCkgPT4ge1xyXG4gICAgICAgICAgcmVzKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHVwZGF0ZVVzZXIoVXNlckxpc3QsIFVzZXJPTGlzdCwgaW5kZXgsIGNiKSB7XHJcbiAgaWYgKFVzZXJPTGlzdC5sZW5ndGggPT09IGluZGV4KSB7XHJcbiAgICBjYigpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB2YXIgZm91bmQgPSBmYWxzZTtcclxuICAgIGZvciAodmFyIHggPSAwOyB4IDwgVXNlckxpc3QubGVuZ3RoOyB4KyspIHtcclxuICAgICAgaWYgKFVzZXJMaXN0W3hdLl9pZCA9PT0gVXNlck9MaXN0W2luZGV4XS5pZCkge1xyXG4gICAgICAgIGZvdW5kID0gdHJ1ZTtcclxuICAgICAgICBVc2VyT0xpc3RbaW5kZXhdLl9pZCA9IFVzZXJPTGlzdFtpbmRleF0uaWQ7XHJcbiAgICAgICAgZGVsZXRlIFVzZXJPTGlzdFtpbmRleF1bXCJAb2RhdGEudHlwZVwiXTtcclxuICAgICAgICBVc2Vycy51cGRhdGUoeyBfaWQ6IFVzZXJPTGlzdFtpbmRleF0uaWQgfSwgeyAkc2V0OiBVc2VyT0xpc3RbaW5kZXhdIH0pXHJcbiAgICAgICAgICAudG9Qcm9taXNlKClcclxuICAgICAgICAgIC50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgdXBkYXRlVXNlcihVc2VyTGlzdCwgVXNlck9MaXN0LCBpbmRleCArIDEsIGNiKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoZm91bmQgPT09IGZhbHNlKSB7XHJcbiAgICAgIFVzZXJPTGlzdFtpbmRleF0uX2lkID0gVXNlck9MaXN0W2luZGV4XS5pZDtcclxuXHJcbiAgICAgIGRlbGV0ZSBVc2VyT0xpc3RbaW5kZXhdW1wiQG9kYXRhLnR5cGVcIl07XHJcbiAgICAgIFVzZXJzLmluc2VydChVc2VyT0xpc3RbaW5kZXhdKVxyXG4gICAgICAgIC50b1Byb21pc2UoKVxyXG4gICAgICAgIC50aGVuKCgpID0+IHtcclxuICAgICAgICAgIHVwZGF0ZVVzZXIoVXNlckxpc3QsIFVzZXJPTGlzdCwgaW5kZXggKyAxLCBjYik7XHJcbiAgICAgICAgfSlcclxuICAgICAgICAuY2F0Y2goZXJyID0+IHt9KTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNoZWNrR3JvdXAoZ3JvdXBMaXN0LCBkYXRhTGlzdHMsIGluZGV4LCBjYikge1xyXG4gIGlmIChkYXRhTGlzdHMubGVuZ3RoID09PSBpbmRleCkge1xyXG4gICAgY2IoZGF0YUxpc3RzKTtcclxuICB9IGVsc2Uge1xyXG4gICAgaWYgKGRhdGFMaXN0c1tpbmRleF0udmlzaWJpbGl0eSA9PT0gXCJQcml2YXRlXCIpIHtcclxuICAgICAgY2hlY2tHcm91cChncm91cExpc3QsIGRhdGFMaXN0cywgaW5kZXggKyAxLCBjYik7XHJcblxyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdmFyIGZvdW5kID0gZmFsc2U7XHJcbiAgICBmb3IgKHZhciB4ID0gMDsgeCA8IGdyb3VwTGlzdC5sZW5ndGg7IHgrKykge1xyXG4gICAgICBpZiAoZ3JvdXBMaXN0W3hdLl9pZCA9PT0gZGF0YUxpc3RzW2luZGV4XS5pZCkge1xyXG4gICAgICAgIGZvdW5kID0gdHJ1ZTtcclxuICAgICAgICBkYXRhTGlzdHNbaW5kZXhdLl9pZCA9IGRhdGFMaXN0c1tpbmRleF0uaWQ7XHJcbiAgICAgICAgVGVhbXMudXBkYXRlKHsgX2lkOiBkYXRhTGlzdHNbaW5kZXhdLmlkIH0sIHsgJHNldDogZGF0YUxpc3RzW2luZGV4XSB9KVxyXG4gICAgICAgICAgLnRvUHJvbWlzZSgpXHJcbiAgICAgICAgICAudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgIGNoZWNrR3JvdXAoZ3JvdXBMaXN0LCBkYXRhTGlzdHMsIGluZGV4ICsgMSwgY2IpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmIChmb3VuZCA9PT0gZmFsc2UpIHtcclxuICAgICAgZGF0YUxpc3RzW2luZGV4XS5faWQgPSBkYXRhTGlzdHNbaW5kZXhdLmlkO1xyXG4gICAgICBkYXRhTGlzdHNbaW5kZXhdLmV2ZW50VHlwZUlkcyA9IFtdO1xyXG4gICAgICBkZWxldGUgZGF0YUxpc3RzW2luZGV4XS51c2VyTGlzdDtcclxuICAgICAgZGVsZXRlIGRhdGFMaXN0c1tpbmRleF0uYWRtaW5Vc2VyTGlzdDtcclxuXHJcbiAgICAgIFRlYW1zLmluc2VydChkYXRhTGlzdHNbaW5kZXhdKVxyXG4gICAgICAgIC50b1Byb21pc2UoKVxyXG4gICAgICAgIC50aGVuKCgpID0+IHtcclxuICAgICAgICAgIGNoZWNrR3JvdXAoZ3JvdXBMaXN0LCBkYXRhTGlzdHMsIGluZGV4ICsgMSwgY2IpO1xyXG4gICAgICAgIH0pXHJcbiAgICAgICAgLmNhdGNoKGVyciA9PiB7fSk7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiIsIihmdW5jdGlvbiAoKSB7XHJcbiAgICBmdW5jdGlvbiBvYmplY3RpZnkoYSkge1xyXG4gICAgICB2YXIgcm93cyA9IFtdO1xyXG4gICAgICBmb3IgKHZhciBrZXkgaW4gYSkge1xyXG4gICAgICAgIHZhciBvID0ge307XHJcbiAgICAgICAgb1trZXldID0gYVtrZXldO1xyXG4gICAgICAgIHJvd3MucHVzaChvKTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gcm93cztcclxuICAgIH1cclxuICBcclxuICAvLyBwb2x5ZmlsbCwgc2luY2UgU3RyaW5nLnN0YXJ0c1dpdGggaXMgcGFydCBvZiBFQ01BU2NyaXB0IDYsXHJcbiAgICBpZiAoIVN0cmluZy5wcm90b3R5cGUuc3RhcnRzV2l0aCkge1xyXG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU3RyaW5nLnByb3RvdHlwZSwgJ3N0YXJ0c1dpdGgnLCB7XHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiBmYWxzZSxcclxuICAgICAgICB3cml0YWJsZTogZmFsc2UsXHJcbiAgICAgICAgdmFsdWU6IGZ1bmN0aW9uIChzZWFyY2hTdHJpbmcsIHBvc2l0aW9uKSB7XHJcbiAgICAgICAgICBwb3NpdGlvbiA9IHBvc2l0aW9uIHx8IDA7XHJcbiAgICAgICAgICByZXR1cm4gdGhpcy5sYXN0SW5kZXhPZihzZWFyY2hTdHJpbmcsIHBvc2l0aW9uKSA9PT0gcG9zaXRpb247XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICBcclxuICAvLyBwb2x5ZmlsbCwgc2luY2UgU3RyaW5nLmVuZHNXaXRoIGlzIHBhcnQgb2YgRUNNQVNjcmlwdCA2LFxyXG4gICAgaWYgKCFTdHJpbmcucHJvdG90eXBlLmVuZHNXaXRoKSB7XHJcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShTdHJpbmcucHJvdG90eXBlLCAnZW5kc1dpdGgnLCB7XHJcbiAgICAgICAgdmFsdWU6IGZ1bmN0aW9uIChzZWFyY2hTdHJpbmcsIHBvc2l0aW9uKSB7XHJcbiAgICAgICAgICB2YXIgc3ViamVjdFN0cmluZyA9IHRoaXMudG9TdHJpbmcoKTtcclxuICAgICAgICAgIGlmIChwb3NpdGlvbiA9PT0gdW5kZWZpbmVkIHx8IHBvc2l0aW9uID4gc3ViamVjdFN0cmluZy5sZW5ndGgpIHtcclxuICAgICAgICAgICAgcG9zaXRpb24gPSBzdWJqZWN0U3RyaW5nLmxlbmd0aDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHBvc2l0aW9uIC09IHNlYXJjaFN0cmluZy5sZW5ndGg7XHJcbiAgICAgICAgICB2YXIgbGFzdEluZGV4ID0gc3ViamVjdFN0cmluZy5pbmRleE9mKHNlYXJjaFN0cmluZywgcG9zaXRpb24pO1xyXG4gICAgICAgICAgcmV0dXJuIGxhc3RJbmRleCAhPT0gLTEgJiYgbGFzdEluZGV4ID09PSBwb3NpdGlvbjtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIFxyXG4gICAgLy8gc2hvdWxkIHR1cm4gdGhpcyBmdW5jdGlvbiBhcm91bmQgc28gaXQgd29ya3MgbW9yZSBsaWtlIHRoaXNcclxuICAgIC8vXHJcbiAgICAvLyB2YXIgdHJ1dGggPSBRdWVyeShxKS5zYXRpc2ZpZXMob2JqKVxyXG4gIFxyXG4gICAgdmFyIFF1ZXJ5ID0ge1xyXG4gIFxyXG4gICAgICBzYXRpc2ZpZXM6IGZ1bmN0aW9uIChyb3csIGNvbnN0cmFpbnRzLCBnZXR0ZXIpIHtcclxuICAgICAgICByZXR1cm4gUXVlcnkubGhzLl9yb3dzYXRpc2ZpZXMocm93LCBjb25zdHJhaW50cywgZ2V0dGVyKTtcclxuICAgICAgfSxcclxuICBcclxuICAgICAgUXVlcnk6IGZ1bmN0aW9uIChjb25zdHJhaW50cywgZ2V0dGVyKSB7XHJcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIChyb3cpIHtcclxuICAgICAgICAgIHJldHVybiBRdWVyeS5saHMuX3Jvd3NhdGlzZmllcyhyb3csIGNvbnN0cmFpbnRzLCBnZXR0ZXIpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICBcclxuICAgICAgam9pbjogZnVuY3Rpb24gKGxlZnRfcm93cywgcmlnaHRfcm93cywgbGVmdF9rZXksIHJpZ2h0X2tleSkge1xyXG4gICAgICAgIHZhciBsZWZ0S2V5Rm4sIHJpZ2h0S2V5Rm47XHJcbiAgICAgICAgaWYgKHR5cGVvZiBsZWZ0X2tleSA9PSAnc3RyaW5nJykgbGVmdEtleUZuID0gZnVuY3Rpb24gKHJvdykge1xyXG4gICAgICAgICAgcmV0dXJuIHJvd1tsZWZ0X2tleV07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgbGVmdEtleUZuID0gbGVmdF9rZXk7XHJcbiAgXHJcbiAgICAgICAgaWYgKCFyaWdodF9rZXkpIHJpZ2h0S2V5Rm4gPSBsZWZ0S2V5Rm47XHJcbiAgICAgICAgaWYgKHR5cGVvZiByaWdodF9rZXkgPT0gJ3N0cmluZycpIHJpZ2h0S2V5Rm4gPSBmdW5jdGlvbiAocm93KSB7XHJcbiAgICAgICAgICByZXR1cm4gcm93W2xlZnRfa2V5XTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSByaWdodEtleUZuID0gcmlnaHRfa2V5O1xyXG4gIFxyXG4gICAgICAgIHJldHVybiBsZWZ0X3Jvd3M7XHJcbiAgICAgIH0sXHJcbiAgXHJcbiAgICAgIHF1ZXJ5OiBmdW5jdGlvbiAocm93cywgY29uc3RyYWludHMsIGdldHRlcikge1xyXG4gICAgICAgIGlmICh0eXBlb2YgZ2V0dGVyID09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgICB2YXIgbWV0aG9kID0gZ2V0dGVyO1xyXG4gICAgICAgICAgZ2V0dGVyID0gZnVuY3Rpb24gKG9iaiwga2V5KSB7XHJcbiAgICAgICAgICAgIHJldHVybiBvYmpbbWV0aG9kXShrZXkpO1xyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIGZpbHRlciA9IG5ldyBRdWVyeS5RdWVyeShjb25zdHJhaW50cywgZ2V0dGVyKTtcclxuICAgICAgICByZXR1cm4gcm93cy5maWx0ZXIoZmlsdGVyKTtcclxuICAgICAgfSxcclxuICBcclxuICAgICAgbGhzOiB7IC8vIHF1ZXJpZXMgdGhhdCBhcmUgbm90IHlldCByZWZlcmVuY2VkIHRvIGEgcGFydGljdWxhciBhdHRyaWJ1dGUsIGUuZy4geyRub3Q6IHtsaWtlczogMH19XHJcbiAgXHJcbiAgICAgICAgLy8gdGVzdCB3aGV0aGVyIGEgcm93IHNhdGlzZmllcyBhIGNvbnN0cmFpbnRzIGhhc2gsXHJcbiAgICAgICAgX3Jvd3NhdGlzZmllczogZnVuY3Rpb24gKHJvdywgY29uc3RyYWludHMsIGdldHRlcikge1xyXG4gICAgICAgICAgZm9yICh2YXIga2V5IGluIGNvbnN0cmFpbnRzKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzW2tleV0pIHtcclxuICAgICAgICAgICAgICBpZiAoIXRoaXNba2V5XShyb3csIGNvbnN0cmFpbnRzW2tleV0sIGdldHRlcikpIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICB2YXIgdmFsID0gKGdldHRlciA/IGdldHRlcihyb3csIGtleSkgOiByb3dba2V5XSk7XHJcbiAgICAgICAgICAgICAgdmFyIHJlcyA9IHRoaXMucmhzLl9zYXRpc2ZpZXModmFsLCBjb25zdHJhaW50c1trZXldLCBrZXkpXHJcbiAgICAgICAgICAgICAgaWYgKCFyZXMpIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfSxcclxuICBcclxuICAgICAgICAkY291bnQ6IGZ1bmN0aW9uIChyb3csIGNvbmRpdGlvbiwgZ2V0dGVyKSB7XHJcbiAgXHJcbiAgICAgICAgICB2YXIgcmVzID0gY29uZGl0aW9uLiRjb25zdHJhaW50cy5tYXAoZnVuY3Rpb24gKGMpIHtcclxuICAgICAgICAgICAgcmV0dXJuIFF1ZXJ5LnNhdGlzZmllcyhyb3csIGMsIGdldHRlcik7XHJcbiAgICAgICAgICB9KS5maWx0ZXIoZnVuY3Rpb24odikge3JldHVybiB2fSkubGVuZ3RoXHJcbiAgICAgICAgICByZXR1cm4gdGhpcy5yaHMuX3NhdGlzZmllcyhyZXMsIGNvbmRpdGlvbi4kY29uc3RyYWludClcclxuICAgICAgICB9LFxyXG4gIFxyXG4gICAgICAgICRub3Q6IGZ1bmN0aW9uIChyb3csIGNvbnN0cmFpbnQsIGdldHRlcikge1xyXG4gICAgICAgICAgcmV0dXJuICF0aGlzLl9yb3dzYXRpc2ZpZXMocm93LCBjb25zdHJhaW50LCBnZXR0ZXIpO1xyXG4gICAgICAgIH0sXHJcbiAgXHJcbiAgICAgICAgJG9yOiBmdW5jdGlvbiAocm93LCBjb25zdHJhaW50LCBnZXR0ZXIpIHtcclxuICAgICAgICAgIGlmICghQXJyYXkuaXNBcnJheShjb25zdHJhaW50KSkge1xyXG4gICAgICAgICAgICBjb25zdHJhaW50ID0gb2JqZWN0aWZ5KGNvbnN0cmFpbnQpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjb25zdHJhaW50Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9yb3dzYXRpc2ZpZXMocm93LCBjb25zdHJhaW50W2ldLCBnZXR0ZXIpKSByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9LFxyXG4gIFxyXG4gICAgICAgICRhbmQ6IGZ1bmN0aW9uIChyb3csIGNvbnN0cmFpbnQsIGdldHRlcikge1xyXG4gICAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KGNvbnN0cmFpbnQpKSB7XHJcbiAgICAgICAgICAgIGNvbnN0cmFpbnQgPSBvYmplY3RpZnkoY29uc3RyYWludCk7XHJcbiAgICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNvbnN0cmFpbnQubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKCF0aGlzLl9yb3dzYXRpc2ZpZXMocm93LCBjb25zdHJhaW50W2ldLCBnZXR0ZXIpKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9LFxyXG4gIFxyXG4gICAgICAgICRub3I6IGZ1bmN0aW9uIChyb3csIGNvbnN0cmFpbnQsIGdldHRlcikge1xyXG4gICAgICAgICAgcmV0dXJuICF0aGlzLiRvcihyb3csIGNvbnN0cmFpbnQsIGdldHRlcilcclxuICAgICAgICB9LFxyXG4gIFxyXG4gICAgICAgICR3aGVyZTogZnVuY3Rpb24gKHZhbHVlcywgcmVmKSB7XHJcbiAgICAgICAgICB2YXIgZm4gPSAodHlwZW9mIHJlZiA9PSAnc3RyaW5nJykgPyBuZXcgRnVuY3Rpb24ocmVmKSA6IHJlZjtcclxuICAgICAgICAgIHZhciByZXMgPSBmbi5jYWxsKHZhbHVlcylcclxuICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSxcclxuICBcclxuICBcclxuICAgICAgICByaHM6IHsgIC8vIHF1ZXJpZXMgdGhhdCByZWZlcmVuY2UgYSBwYXJ0aWN1bGFyIGF0dHJpYnV0ZSwgZS5nLiB7bGlrZXM6IHskZ3Q6IDEwfX1cclxuICBcclxuICAgICAgICAgICRjYjogZnVuY3Rpb24gKHZhbHVlLCBjb25zdHJhaW50LCBwYXJlbnRLZXkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGNvbnN0cmFpbnQodmFsdWUpXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgLy8gdGVzdCB3aGV0aGVyIGEgc2luZ2xlIHZhbHVlIG1hdGNoZXMgYSBwYXJ0aWN1bGFyIGNvbnN0cmFpbnRcclxuICAgICAgICAgIF9zYXRpc2ZpZXM6IGZ1bmN0aW9uICh2YWx1ZSwgY29uc3RyYWludCwgcGFyZW50S2V5KSB7XHJcbiAgXHJcbiAgXHJcbiAgICAgICAgICAgIGlmIChjb25zdHJhaW50ID09PSB2YWx1ZSkgIHJldHVybiB0cnVlO1xyXG4gIFxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlPT09J3N0cmluZycgJiYgKCh2YWx1ZVswXT09PSdbJyApfHwgKHZhbHVlWzBdPT09J3snKSApKSB7XHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHZhciB2YWx1ZSA9IEpTT04ucGFyc2UodmFsdWUpXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGNhdGNoIChlKSB7fVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChjb25zdHJhaW50IGluc3RhbmNlb2YgUmVnRXhwKSAgcmV0dXJuIHRoaXMuJHJlZ2V4KHZhbHVlLCBjb25zdHJhaW50KTtcclxuICAgICAgICAgICAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheShjb25zdHJhaW50KSkgIHJldHVybiB0aGlzLiRpbih2YWx1ZSwgY29uc3RyYWludCk7XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKGNvbnN0cmFpbnQgJiYgdHlwZW9mIGNvbnN0cmFpbnQgPT09ICdvYmplY3QnKSB7XHJcbiAgICAgICAgICAgICAgaWYgKGNvbnN0cmFpbnQgaW5zdGFuY2VvZiBEYXRlKSByZXR1cm4gdGhpcy4kZXEodmFsdWUsIGNvbnN0cmFpbnQuZ2V0VGltZSgpKVxyXG4gICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbnN0cmFpbnQuJHJlZ2V4KSByZXR1cm4gdGhpcy4kcmVnZXgodmFsdWUsIG5ldyBSZWdFeHAoY29uc3RyYWludC4kcmVnZXgsIGNvbnN0cmFpbnQuJG9wdGlvbnMpKVxyXG4gICAgICAgICAgICAgICAgZm9yICh2YXIga2V5IGluIGNvbnN0cmFpbnQpIHtcclxuICAgICAgICAgICAgICAgICAgaWYgKCF0aGlzW2tleV0pICByZXR1cm4gdGhpcy4kZXEodmFsdWUsIGNvbnN0cmFpbnQsIHBhcmVudEtleSlcclxuICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoIXRoaXNba2V5XSh2YWx1ZSwgY29uc3RyYWludFtrZXldLCBwYXJlbnRLZXkpKSAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XHJcbiAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB2YWx1ZS5sZW5ndGg7IGkrKylcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLiRlcSh2YWx1ZVtpXSwgY29uc3RyYWludCkpIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmIChjb25zdHJhaW50ID09PSAnJyB8fCBjb25zdHJhaW50ID09PSBudWxsIHx8IGNvbnN0cmFpbnQgPT09IHVuZGVmaW5lZCkgIHJldHVybiB0aGlzLiRudWxsKHZhbHVlKTtcclxuICAgICAgICAgICAgZWxzZSByZXR1cm4gdGhpcy4kZXEodmFsdWUsIGNvbnN0cmFpbnQpO1xyXG4gICAgICAgICAgfSxcclxuICBcclxuICBcclxuICAgICAgICAgICRlcTogZnVuY3Rpb24gKHZhbHVlLCBjb25zdHJhaW50KSB7XHJcbiAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gY29uc3RyYWludCkgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XHJcbiAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB2YWx1ZS5sZW5ndGg7IGkrKylcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLiRlcSh2YWx1ZVtpXSwgY29uc3RyYWludCkpIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmIChjb25zdHJhaW50ID09PSBudWxsIHx8IGNvbnN0cmFpbnQgPT09IHVuZGVmaW5lZCB8fCBjb25zdHJhaW50ID09PSAnJykge1xyXG4gICAgICAgICAgICAgIHJldHVybiB0aGlzLiRudWxsKHZhbHVlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gJycgfHwgdmFsdWUgPT09IHVuZGVmaW5lZCkgcmV0dXJuIGZhbHNlOyAvL3dlIGtub3cgZnJvbSBhYm92ZSB0aGUgY29uc3RyYWludCBpcyBub3QgbnVsbFxyXG4gICAgICAgICAgICBlbHNlIGlmICh2YWx1ZSBpbnN0YW5jZW9mIERhdGUpIHtcclxuICBcclxuICAgICAgICAgICAgICBpZiAoY29uc3RyYWludCBpbnN0YW5jZW9mIERhdGUpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZS5nZXRUaW1lKCkgPT0gY29uc3RyYWludC5nZXRUaW1lKCk7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjb25zdHJhaW50ID09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWUuZ2V0VGltZSgpID09IGNvbnN0cmFpbnQ7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjb25zdHJhaW50ID09ICdzdHJpbmcnKSByZXR1cm4gdmFsdWUuZ2V0VGltZSgpID09IChuZXcgRGF0ZShjb25zdHJhaW50KSkuZ2V0VGltZSgpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlID09IGNvbnN0cmFpbnRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICA7XHJcbiAgXHJcbiAgICAgICAgICB9LFxyXG4gIFxyXG4gIFxyXG4gICAgICAgICAgJGV4aXN0czogZnVuY3Rpb24gKHZhbHVlLCBjb25zdHJhaW50LCBwYXJlbnRLZXkpIHtcclxuICAgICAgICAgICAgcmV0dXJuICh2YWx1ZSAhPSB1bmRlZmluZWQpID09IChjb25zdHJhaW50ICYmIHRydWUpO1xyXG4gICAgICAgICAgfSxcclxuICBcclxuICAgICAgICAgICRkZWVwRXF1YWxzOiBmdW5jdGlvbiAodmFsdWUsIGNvbnN0cmFpbnQpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBfID09ICd1bmRlZmluZWQnIHx8IHR5cGVvZiBfLmlzRXF1YWwgPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUpID09IEpTT04uc3RyaW5naWZ5KGNvbnN0cmFpbnQpOyAvL1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgIHJldHVybiBfLmlzRXF1YWwodmFsdWUsIGNvbnN0cmFpbnQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgICB9LFxyXG4gIFxyXG4gICAgICAgICAgJG5vdDogZnVuY3Rpb24gKHZhbHVlcywgY29uc3RyYWludCkge1xyXG4gICAgICAgICAgICByZXR1cm4gIXRoaXMuX3NhdGlzZmllcyh2YWx1ZXMsIGNvbnN0cmFpbnQpO1xyXG4gIFxyXG4gICAgICAgICAgfSxcclxuICBcclxuICAgICAgICAgICRuZTogZnVuY3Rpb24gKHZhbHVlcywgY29uc3RyYWludCkge1xyXG4gICAgICAgICAgICByZXR1cm4gIXRoaXMuX3NhdGlzZmllcyh2YWx1ZXMsIGNvbnN0cmFpbnQpO1xyXG4gICAgICAgICAgfSxcclxuICBcclxuICAgICAgICAgICRub3I6IGZ1bmN0aW9uICh2YWx1ZXMsIGNvbnN0cmFpbnQsIHBhcmVudEtleSkge1xyXG4gICAgICAgICAgICByZXR1cm4gIXRoaXMuJG9yKHZhbHVlcywgY29uc3RyYWludCwgcGFyZW50S2V5KTtcclxuICAgICAgICAgIH0sXHJcbiAgXHJcbiAgICAgICAgICAkYW5kOiBmdW5jdGlvbiAodmFsdWVzLCBjb25zdHJhaW50LCBwYXJlbnRLZXkpIHtcclxuICBcclxuICAgICAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KGNvbnN0cmFpbnQpKSB7XHJcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTG9naWMgJGFuZCB0YWtlcyBhcnJheSBvZiBjb25zdHJhaW50IG9iamVjdHNcIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjb25zdHJhaW50Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgdmFyIHJlcyA9IHRoaXMuX3NhdGlzZmllcyh2YWx1ZXMsIGNvbnN0cmFpbnRbaV0sIHBhcmVudEtleSk7XHJcbiAgICAgICAgICAgICAgaWYgKCFyZXMpIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgIH0sXHJcbiAgXHJcbiAgICAgICAgICAvLyBJZGVudGljYWwgdG8gJGluLCBidXQgYWxsb3dzIGZvciBkaWZmZXJlbnQgc2VtYW50aWNzXHJcbiAgICAgICAgICAkb3I6IGZ1bmN0aW9uICh2YWx1ZXMsIGNvbnN0cmFpbnQsIHBhcmVudEtleSkge1xyXG4gIFxyXG4gICAgICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkodmFsdWVzKSkge1xyXG4gICAgICAgICAgICAgIHZhbHVlcyA9IFt2YWx1ZXNdO1xyXG4gICAgICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgICAgIGZvciAodmFyIHYgPSAwOyB2IDwgdmFsdWVzLmxlbmd0aDsgdisrKSB7XHJcbiAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjb25zdHJhaW50Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fc2F0aXNmaWVzKHZhbHVlc1t2XSwgY29uc3RyYWludFtpXSwgcGFyZW50S2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICBcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgfSxcclxuICBcclxuICAgICAgICAgIC8qKlxyXG4gICAgICAgICAgICogcmV0dXJucyB0cnVlIGlmIGFsbCBvZiB0aGUgdmFsdWVzIGluIHRoZSBhcnJheSBhcmUgbnVsbFxyXG4gICAgICAgICAgICogQHBhcmFtIHZhbHVlc1xyXG4gICAgICAgICAgICogQHJldHVybnMge2Jvb2xlYW59XHJcbiAgICAgICAgICAgKi9cclxuICAgICAgICAgICRudWxsOiBmdW5jdGlvbiAodmFsdWVzKSB7XHJcbiAgICAgICAgICAgIHZhciByZXN1bHQ7XHJcbiAgICAgICAgICAgIGlmICh2YWx1ZXMgPT09ICcnIHx8IHZhbHVlcyA9PT0gbnVsbCB8fCB2YWx1ZXMgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodmFsdWVzKSkge1xyXG4gICAgICAgICAgICAgIGZvciAodmFyIHYgPSAwOyB2IDwgdmFsdWVzLmxlbmd0aDsgdisrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXRoaXMuJG51bGwodmFsdWVzW3ZdKSkge1xyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgfSxcclxuICBcclxuICBcclxuICAgICAgICAgIC8qKlxyXG4gICAgICAgICAgICogcmV0dXJucyB0cnVlIGlmIGFueSBvZiB0aGUgdmFsdWVzIGFyZSBrZXlzIG9mIHRoZSBjb25zdHJhaW50XHJcbiAgICAgICAgICAgKiBAcGFyYW0gdmFsdWVzXHJcbiAgICAgICAgICAgKiBAcGFyYW0gY29uc3RyYWludFxyXG4gICAgICAgICAgICogQHJldHVybnMge2Jvb2xlYW59XHJcbiAgICAgICAgICAgKi9cclxuICAgICAgICAgICRpbjogZnVuY3Rpb24gKHZhbHVlcywgY29uc3RyYWludCkge1xyXG4gICAgICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkoY29uc3RyYWludCkpIHRocm93IG5ldyBFcnJvcihcIiRpbiByZXF1aXJlcyBhbiBhcnJheSBvcGVyYW5kXCIpO1xyXG4gICAgICAgICAgICB2YXIgcmVzdWx0ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGlmICghQXJyYXkuaXNBcnJheSh2YWx1ZXMpKSB7XHJcbiAgICAgICAgICAgICAgdmFsdWVzID0gW3ZhbHVlc107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZm9yICh2YXIgdiA9IDA7IHYgPCB2YWx1ZXMubGVuZ3RoOyB2KyspIHtcclxuICAgICAgICAgICAgICB2YXIgdmFsID0gdmFsdWVzW3ZdO1xyXG4gICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY29uc3RyYWludC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbnN0cmFpbnQuaW5kZXhPZih2YWwpID49IDAgfHwgdGhpcy5fc2F0aXNmaWVzKHZhbCwgY29uc3RyYWludFtpXSkpIHtcclxuICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgICB9LFxyXG4gIFxyXG4gICAgICAgICAgJGxpa2VJOiBmdW5jdGlvbiAodmFsdWVzLCBjb25zdHJhaW50KSB7XHJcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZXMudG9Mb3dlckNhc2UoKS5pbmRleE9mKGNvbnN0cmFpbnQpID49IDA7XHJcbiAgICAgICAgICB9LFxyXG4gIFxyXG4gICAgICAgICAgJGxpa2U6IGZ1bmN0aW9uICh2YWx1ZXMsIGNvbnN0cmFpbnQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHZhbHVlcy5pbmRleE9mKGNvbnN0cmFpbnQpID49IDA7XHJcbiAgICAgICAgICB9LFxyXG4gIFxyXG4gICAgICAgICAgJHN0YXJ0c1dpdGg6IGZ1bmN0aW9uICh2YWx1ZXMsIGNvbnN0cmFpbnQpIHtcclxuICAgICAgICAgICAgaWYgKCF2YWx1ZXMpIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgcmV0dXJuIHZhbHVlcy5zdGFydHNXaXRoKGNvbnN0cmFpbnQpO1xyXG4gICAgICAgICAgfSxcclxuICBcclxuICAgICAgICAgICRlbmRzV2l0aDogZnVuY3Rpb24gKHZhbHVlcywgY29uc3RyYWludCkge1xyXG4gICAgICAgICAgICBpZiAoIXZhbHVlcykgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICByZXR1cm4gdmFsdWVzLmVuZHNXaXRoKGNvbnN0cmFpbnQpO1xyXG4gICAgICAgICAgfSxcclxuICBcclxuICAgICAgICAgICRlbGVtTWF0Y2g6IGZ1bmN0aW9uICh2YWx1ZXMsIGNvbnN0cmFpbnQsIHBhcmVudEtleSkge1xyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHZhbHVlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgIGlmIChRdWVyeS5saHMuX3Jvd3NhdGlzZmllcyh2YWx1ZXNbaV0sIGNvbnN0cmFpbnQpKSByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICB9LFxyXG4gIFxyXG4gICAgICAgICAgJGNvbnRhaW5zOiBmdW5jdGlvbiAodmFsdWVzLCBjb25zdHJhaW50KSB7XHJcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZXMuaW5kZXhPZihjb25zdHJhaW50KSA+PSAwO1xyXG4gICAgICAgICAgfSxcclxuICBcclxuICAgICAgICAgICRuaW46IGZ1bmN0aW9uICh2YWx1ZXMsIGNvbnN0cmFpbnQpIHtcclxuICAgICAgICAgICAgcmV0dXJuICF0aGlzLiRpbih2YWx1ZXMsIGNvbnN0cmFpbnQpO1xyXG4gICAgICAgICAgfSxcclxuICBcclxuICAgICAgICAgICRyZWdleDogZnVuY3Rpb24gKHZhbHVlcywgY29uc3RyYWludCkge1xyXG4gICAgICAgICAgICB2YXIgcmVzdWx0ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlcykpIHtcclxuICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHZhbHVlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbnN0cmFpbnQudGVzdCh2YWx1ZXNbaV0pKSB7XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHJldHVybiBjb25zdHJhaW50LnRlc3QodmFsdWVzKTtcclxuICBcclxuICAgICAgICAgIH0sXHJcbiAgXHJcbiAgICAgICAgICAkZ3RlOiBmdW5jdGlvbiAodmFsdWVzLCByZWYpIHtcclxuICBcclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWVzKSkge1xyXG4gICAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAgICAgICByZXR1cm4gdmFsdWVzLmV2ZXJ5KGZ1bmN0aW9uKHYpIHsgcmV0dXJuIHNlbGYuJGd0ZSh2LCByZWYpfSlcclxuICAgICAgICAgICAgfVxyXG4gIFxyXG4gICAgICAgICAgICByZXR1cm4gIXRoaXMuJG51bGwodmFsdWVzKSAmJiB2YWx1ZXMgPj0gdGhpcy5yZXNvbHZlKHJlZilcclxuICAgICAgICAgIH0sXHJcbiAgXHJcbiAgICAgICAgICAkZ3Q6IGZ1bmN0aW9uICh2YWx1ZXMsIHJlZikge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZXMpKSB7XHJcbiAgICAgICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgICAgICAgIHJldHVybiB2YWx1ZXMuZXZlcnkoZnVuY3Rpb24odikgeyByZXR1cm4gc2VsZi4kZ3QodiwgcmVmKX0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuICF0aGlzLiRudWxsKHZhbHVlcykgJiYgdmFsdWVzID4gdGhpcy5yZXNvbHZlKHJlZik7XHJcbiAgICAgICAgICB9LFxyXG4gIFxyXG4gICAgICAgICAgJGx0OiBmdW5jdGlvbiAodmFsdWVzLCByZWYpIHtcclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWVzKSkge1xyXG4gICAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAgICAgICByZXR1cm4gdmFsdWVzLmV2ZXJ5KGZ1bmN0aW9uKHYpIHsgcmV0dXJuIHNlbGYuJGx0KHYsIHJlZil9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiAhdGhpcy4kbnVsbCh2YWx1ZXMpICYmIHZhbHVlcyA8IHRoaXMucmVzb2x2ZShyZWYpO1xyXG4gICAgICAgICAgfSxcclxuICBcclxuICAgICAgICAgICRsdGU6IGZ1bmN0aW9uICh2YWx1ZXMsIHJlZikge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZXMpKSB7XHJcbiAgICAgICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgICAgICAgIHJldHVybiB2YWx1ZXMuZXZlcnkoZnVuY3Rpb24odikgeyByZXR1cm4gc2VsZi4kbHRlKHYsIHJlZil9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiAhdGhpcy4kbnVsbCh2YWx1ZXMpICYmIHZhbHVlcyA8PSB0aGlzLnJlc29sdmUocmVmKTtcclxuICAgICAgICAgIH0sXHJcbiAgXHJcbiAgXHJcbiAgICAgICAgICAkYmVmb3JlOiBmdW5jdGlvbiAodmFsdWVzLCByZWYpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiByZWYgPT09ICdzdHJpbmcnKSByZWYgPSBEYXRlLnBhcnNlKHJlZik7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsdWVzID09PSAnc3RyaW5nJykgdmFsdWVzID0gRGF0ZS5wYXJzZSh2YWx1ZXMpO1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy4kbHRlKHZhbHVlcywgcmVmKVxyXG4gICAgICAgICAgfSxcclxuICBcclxuICAgICAgICAgICRhZnRlcjogZnVuY3Rpb24gKHZhbHVlcywgcmVmKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgcmVmID09PSAnc3RyaW5nJykgcmVmID0gRGF0ZS5wYXJzZShyZWYpO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlcyA9PT0gJ3N0cmluZycpIHZhbHVlcyA9IERhdGUucGFyc2UodmFsdWVzKTtcclxuICBcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGd0ZSh2YWx1ZXMsIHJlZilcclxuICAgICAgICAgIH0sXHJcbiAgXHJcbiAgICAgICAgICAkdHlwZTogZnVuY3Rpb24gKHZhbHVlcywgcmVmKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0eXBlb2YgdmFsdWVzID09IHJlZjtcclxuICAgICAgICAgIH0sXHJcbiAgXHJcbiAgICAgICAgICAkYWxsOiBmdW5jdGlvbiAodmFsdWVzLCByZWYpIHtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiJGFsbCBub3QgaW1wbGVtZW50ZWRcIilcclxuICAgICAgICAgIH0sXHJcbiAgXHJcbiAgICAgICAgICAkc2l6ZTogZnVuY3Rpb24gKHZhbHVlcywgcmVmKSB7XHJcbiAgICAgICAgICAgIHJldHVybiAodHlwZW9mIHZhbHVlcyA9PSAnb2JqZWN0JyAmJiAodmFsdWVzLmxlbmd0aCA9PSByZWYgfHwgT2JqZWN0LmtleXModmFsdWVzKS5sZW5ndGggPT0gcmVmKSApO1xyXG4gICAgICAgICAgfSxcclxuICBcclxuICAgICAgICAgICRtb2Q6IGZ1bmN0aW9uICh2YWx1ZXMsIHJlZikge1xyXG4gICAgICAgICAgICByZXR1cm4gdmFsdWVzICUgcmVmWzBdID09IHJlZlsxXVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgICRlcXVhbDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy4kZXEoYXJndW1lbnRzKTtcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICAkYmV0d2VlbjogZnVuY3Rpb24gKHZhbHVlcywgcmVmKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9zYXRpc2ZpZXModmFsdWVzLCB7JGd0OiByZWZbMF0sICRsdDogcmVmWzFdfSlcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICByZXNvbHZlOiBmdW5jdGlvbiAocmVmKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgcmVmID09PSAnb2JqZWN0Jykge1xyXG4gICAgICAgICAgICAgIGlmIChyZWZbXCIkZGF0ZVwiXSkgcmV0dXJuIERhdGUucGFyc2UocmVmW1wiJGRhdGVcIl0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHJlZjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgXHJcbiAgICAvLyBQcm92aWRlIG1lYW5zIHRvIHBhcnNlIGRvdCBub3RhdGlvbiBmb3IgZGVlcCBNb25nbyBxdWVyaWVzLCBvcHRpb25hbCBmb3IgcGVyZm9ybWFuY2VcclxuICAgIFF1ZXJ5LnVuZG90ID0gZnVuY3Rpb24gKG9iaiwga2V5KSB7XHJcbiAgICAgIHZhciBrZXlzID0ga2V5LnNwbGl0KCcuJyksIHN1YiA9IG9iajtcclxuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBrZXlzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgc3ViID0gc3ViW2tleXNbaV1dXHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHN1YjtcclxuICAgIH07XHJcbiAgXHJcbiAgICBRdWVyeS5saHMucmhzLiRlcXVhbCA9IFF1ZXJ5Lmxocy5yaHMuJGVxO1xyXG4gICAgUXVlcnkubGhzLnJocy4kYW55ID0gUXVlcnkubGhzLnJocy4kb3I7XHJcbiAgICBRdWVyeS5saHMucmhzLiRhbGwgPSBRdWVyeS5saHMucmhzLiRhbmQ7XHJcbiAgXHJcbiAgICBRdWVyeS5zYXRpc2ZpZXMgPSBmdW5jdGlvbiAocm93LCBjb25zdHJhaW50cywgZ2V0dGVyKSB7XHJcbiAgICAgIHJldHVybiB0aGlzLmxocy5fcm93c2F0aXNmaWVzKHJvdywgY29uc3RyYWludHMsIGdldHRlcik7XHJcbiAgICB9XHJcbiAgXHJcbiAgICBBcnJheS5wcm90b3R5cGUucXVlcnkgPSBmdW5jdGlvbiAocSkge1xyXG4gICAgICByZXR1cm4gUXVlcnkucXVlcnkodGhpcywgcSk7XHJcbiAgICB9XHJcbiAgXHJcbiAgICAvL1RoaXMgYWxsb3dzIGEgcXVlcnkgb2JqZWN0IHdpdGggcmVnZXggdmFsdWVzIHRvIGJlIHNlcmlhbGl6ZWQgdG8gSlNPTlxyXG4gICAgLy9odHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzEyMDc1OTI3L3NlcmlhbGl6YXRpb24tb2YtcmVnZXhwXHJcbiAgICAvL0hvd2V2ZXIsIGl0IGRvZXNuJ3Qgc29sdmUgdGhlIHByb2JsZW0gb2YgcGFyc2luZyB0aGVtIGJhY2sgdG8gcmVnZXggb24gaW5wdXRcclxuICAgIFJlZ0V4cC5wcm90b3R5cGUudG9KU09OID0gUmVnRXhwLnByb3RvdHlwZS50b1N0cmluZztcclxuICBcclxuICAgIGlmICh0eXBlb2YgbW9kdWxlICE9ICd1bmRlZmluZWQnKSBtb2R1bGUuZXhwb3J0cyA9IFF1ZXJ5O1xyXG4gICAgZWxzZSBpZiAodHlwZW9mIGRlZmluZSAhPSAndW5kZWZpbmVkJyAmJiBkZWZpbmUuYW1kKSAgIGRlZmluZSgncXVlcnknLCBbXSwgZnVuY3Rpb24gKCkge1xyXG4gICAgICByZXR1cm4gUXVlcnk7XHJcbiAgICB9KVxyXG4gICAgZWxzZSBpZiAodHlwZW9mIHdpbmRvdyAhPSAndW5kZWZpbmVkJykgd2luZG93LlF1ZXJ5ID0gUXVlcnk7XHJcbiAgICBlbHNlIGlmICh0eXBlb2YgR0xPQkFMICE9IHVuZGVmaW5lZCAmJiBHTE9CQUwuZ2xvYmFsKSBHTE9CQUwuZ2xvYmFsLlF1ZXJ5ID0gUXVlcnk7XHJcbiAgXHJcbiAgICByZXR1cm4gUXVlcnk7XHJcbiAgfSkodGhpcyk7IiwiZXhwb3J0IGZ1bmN0aW9uIGdlbmVyYXRlTW9uZ29RdWVyeShxdWVyeSkge1xyXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzLCByZWopID0+IHtcclxuICAgIGlmIChxdWVyeS5ydWxlcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgcmVzKHt9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHZhciBvYmogPSB7fTtcclxuXHJcbiAgICAgIHZhciBtdWx0aSA9IFtdO1xyXG5cclxuICAgICAgZm9yICh2YXIgbyA9IDA7IG8gPCBxdWVyeS5ydWxlcy5sZW5ndGg7IG8rKykge1xyXG4gICAgICAgIG11bHRpLnB1c2gocmVnZWxnZW5lcmllcnVuZyhxdWVyeS5ydWxlc1tvXSkpO1xyXG4gICAgICB9XHJcbiAgICAgIFByb21pc2UuYWxsKG11bHRpKS50aGVuKGRhdGEgPT4ge1xyXG4gICAgICAgIGlmIChxdWVyeS5jb25kaXRpb24gPT09IFwiYW5kXCIpIHtcclxuICAgICAgICAgIG9ialtcIiRhbmRcIl0gPSBkYXRhO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBvYmpbXCIkb3JcIl0gPSBkYXRhO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXMob2JqKTtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfSk7XHJcbn1cclxuXHJcbi8vWydlcXVhbHMnLCBcImRvZXNuYHQgZXF1YWxcIiAsJ2NvbnRhaW5zJywgJ2RvZXNuYHQgY29udGFpbnMnLCdzdGFydCB3aXRoJywnZG9lc25gdCBzdGFydCB3aXRoJywnZW5kcyB3aXRoJywnZG9lc25gdCBlbmRzIHdpdGgnLCdleGlzdHMnLCdkb2VzbmB0ICBleGlzdHMnLCdpbicsJ25vdCBpbicsJ2FycmF5IGNvbnRhaW5zIGFsbCcsJz4nLCc+PScsJzwnLCc8PScsJ2hhcyB0eXBlJywnZG9lc25gdCBoYXMgdHlwZScsJ3JlZ2V4J11cclxuZnVuY3Rpb24gcmVnZWxnZW5lcmllcnVuZyhydWxlKSB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXMsIHJlaikgPT4ge1xyXG4gICAgaWYgKHR5cGVvZiBydWxlLmNvbmRpdGlvbiAhPT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICB2YXIgb2JqID0ge307XHJcbiAgICAgIHZhciBtdWx0aSA9IFtdO1xyXG4gICAgICBmb3IgKHZhciBvID0gMDsgbyA8IHJ1bGUucnVsZXMubGVuZ3RoOyBvKyspIHtcclxuICAgICAgICBtdWx0aS5wdXNoKHJlZ2VsZ2VuZXJpZXJ1bmcocnVsZS5ydWxlc1tvXSkpO1xyXG4gICAgICB9XHJcbiAgICAgIFByb21pc2UuYWxsKG11bHRpKS50aGVuKGRhdGEgPT4ge1xyXG4gICAgICAgIGlmIChydWxlLmNvbmRpdGlvbiA9PT0gXCJhbmRcIikge1xyXG4gICAgICAgICAgb2JqW1wiJGFuZFwiXSA9IGRhdGE7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIG9ialtcIiRvclwiXSA9IGRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJlcyhvYmopO1xyXG4gICAgICB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHZhciBvYmogPSB7fTtcclxuICAgICAgc3dpdGNoIChydWxlLm9wZXJhdG9yKSB7XHJcbiAgICAgICAgY2FzZSBcImVxdWFsc1wiOlxyXG4gICAgICAgICAgb2JqW3J1bGUuZmllbGRdID0gcnVsZS52YWx1ZTtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJkb2VzbmB0IGVxdWFsXCI6XHJcbiAgICAgICAgICBvYmpbcnVsZS5maWVsZF0gPSBydWxlLnZhbHVlO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSBcImNvbnRhaW5zXCI6XHJcbiAgICAgICAgICBvYmpbcnVsZS5maWVsZF0gPSBydWxlLnZhbHVlO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSBcImRvZXNuYHQgY29udGFpbnNcIjpcclxuICAgICAgICAgIG9ialtydWxlLmZpZWxkXSA9IHJ1bGUudmFsdWU7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIFwic3RhcnQgd2l0aFwiOlxyXG4gICAgICAgICAgb2JqW3J1bGUuZmllbGRdID0gcnVsZS52YWx1ZTtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJkb2VzbmB0IHN0YXJ0IHdpdGhcIjpcclxuICAgICAgICAgIG9ialtydWxlLmZpZWxkXSA9IHJ1bGUudmFsdWU7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIFwiZW5kcyB3aXRoXCI6XHJcbiAgICAgICAgICBvYmpbcnVsZS5maWVsZF0gPSBydWxlLnZhbHVlO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSBcImRvZXNuYHQgZW5kcyB3aXRoXCI6XHJcbiAgICAgICAgICBvYmpbcnVsZS5maWVsZF0gPSBydWxlLnZhbHVlO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSBcImV4aXN0c1wiOlxyXG4gICAgICAgICAgb2JqW3J1bGUuZmllbGRdID0gcnVsZS52YWx1ZTtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJkb2VzbmB0ICBleGlzdHNcIjpcclxuICAgICAgICAgIG9ialtydWxlLmZpZWxkXSA9IHJ1bGUudmFsdWU7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIFwiaW5cIjpcclxuICAgICAgICAgIG9ialtydWxlLmZpZWxkXSA9IHJ1bGUudmFsdWU7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIFwibm90IGluXCI6XHJcbiAgICAgICAgICBvYmpbcnVsZS5maWVsZF0gPSBydWxlLnZhbHVlO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSBcImFycmF5IGNvbnRhaW5zIGFsbFwiOlxyXG4gICAgICAgICAgb2JqW3J1bGUuZmllbGRdID0gcnVsZS52YWx1ZTtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCI+XCI6XHJcbiAgICAgICAgICBvYmpbcnVsZS5maWVsZF0gPSBydWxlLnZhbHVlO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSBcIj49XCI6XHJcbiAgICAgICAgICBvYmpbcnVsZS5maWVsZF0gPSBydWxlLnZhbHVlO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSBcIjxcIjpcclxuICAgICAgICAgIG9ialtydWxlLmZpZWxkXSA9IHJ1bGUudmFsdWU7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIFwiPD1cIjpcclxuICAgICAgICAgIG9ialtydWxlLmZpZWxkXSA9IHJ1bGUudmFsdWU7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIFwiaGFzIHR5cGVcIjpcclxuICAgICAgICAgIG9ialtydWxlLmZpZWxkXSA9IHJ1bGUudmFsdWU7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIFwiZG9lc25gdCBoYXMgdHlwZVwiOlxyXG4gICAgICAgICAgb2JqW3J1bGUuZmllbGRdID0gcnVsZS52YWx1ZTtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJyZWdleFwiOlxyXG4gICAgICAgICAgb2JqW3J1bGUuZmllbGRdID0gcnVsZS52YWx1ZTtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICAgIHJlcyhvYmopO1xyXG4gICAgfVxyXG4gIH0pO1xyXG59XHJcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSBcIm1ldGVvci9tb25nb1wiO1xyXG52YXIgXyA9IHJlcXVpcmUoXCJ1bmRlcnNjb3JlXCIpO1xyXG52YXIgbW9uZ29kYiA9IHJlcXVpcmUoXCJtb25nb2RiXCIpO1xyXG52YXIgY2xpZW50ID0gbW9uZ29kYi5Nb25nb0NsaWVudDtcclxudmFyIHVybCA9IHByb2Nlc3MuZW52Lk1PTkdPX1VSTDtcclxudmFyIGRiO1xyXG52YXIgbXAgPSByZXF1aXJlKFwicGFyc2UtbW9uZ28tdXJsXCIpO1xyXG52YXIgY29ubmVjdGlvbnMgPSB7fTtcclxuXHJcbmZ1bmN0aW9uIGxvYWRJbml0aWFsKGFyZ0NvbGxlY3Rpb24sIGFyZ1N1YnNjcmlwdGlvbiwgYXJnUGlwZWxpbmUsIGNsaWVudE5hbWUpIHtcclxuICBhcmdDb2xsZWN0aW9uLmFnZ3JlZ2F0ZShhcmdQaXBlbGluZSkuZm9yRWFjaChkb2MgPT4ge1xyXG4gICAgaWYgKCFhcmdTdWJzY3JpcHRpb24uX2lkc1tkb2MuX2lkXSkge1xyXG4gICAgICBhcmdTdWJzY3JpcHRpb24uYWRkZWQoY2xpZW50TmFtZSwgZG9jLl9pZCwgZG9jKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGFyZ1N1YnNjcmlwdGlvbi5jaGFuZ2VkKGNsaWVudE5hbWUsIGRvYy5faWQsIGRvYyk7XHJcbiAgICB9XHJcblxyXG4gICAgYXJnU3Vic2NyaXB0aW9uLl9pZHNbZG9jLl9pZF0gPSBhcmdTdWJzY3JpcHRpb24uX2l0ZXJhdGlvbjtcclxuICB9LCB7fSk7IC8vIHJlbW92ZSBkb2N1bWVudHMgbm90IGluIHRoZSByZXN1bHQgYW55bW9yZVxyXG5cclxuICBfLmVhY2goYXJnU3Vic2NyaXB0aW9uLl9pZHMsIChpdGVyYXRpb24sIGtleSkgPT4ge1xyXG4gICAgaWYgKGl0ZXJhdGlvbiAhPSBhcmdTdWJzY3JpcHRpb24uX2l0ZXJhdGlvbikge1xyXG4gICAgICBkZWxldGUgYXJnU3Vic2NyaXB0aW9uLl9pZHNba2V5XTtcclxuICAgICAgYXJnU3Vic2NyaXB0aW9uLnJlbW92ZWQoY2xpZW50TmFtZSwga2V5KTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgYXJnU3Vic2NyaXB0aW9uLl9pdGVyYXRpb24rKztcclxufVxyXG52YXIgbG9hZEluaXRpYWxPYnNlcnZlID0gTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChcclxuICAoYXJnU3Vic2NyaXB0aW9uLCBhcmdDb2xsZWN0aW9uLCBhcmdQaXBlbGluZSwgY2xpZW50TmFtZSkgPT4ge1xyXG4gICAgYXJnQ29sbGVjdGlvbi5hZ2dyZWdhdGUoYXJnUGlwZWxpbmUsIHt9KS5mb3JFYWNoKGRvYyA9PiB7XHJcbiAgICAgIGlmICghYXJnU3Vic2NyaXB0aW9uLl9pZHNbZG9jLl9pZF0pIHtcclxuICAgICAgICBhcmdTdWJzY3JpcHRpb24uYWRkZWQoY2xpZW50TmFtZSwgZG9jLl9pZCwgZG9jKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhcmdTdWJzY3JpcHRpb24uY2hhbmdlZChjbGllbnROYW1lLCBkb2MuX2lkLCBkb2MpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBhcmdTdWJzY3JpcHRpb24uX2lkc1tkb2MuX2lkXSA9IGFyZ1N1YnNjcmlwdGlvbi5faXRlcmF0aW9uO1xyXG4gICAgfSwge30pOyAvLyByZW1vdmUgZG9jdW1lbnRzIG5vdCBpbiB0aGUgcmVzdWx0IGFueW1vcmVcclxuXHJcbiAgICBfLmVhY2goYXJnU3Vic2NyaXB0aW9uLl9pZHMsIChpdGVyYXRpb24sIGtleSkgPT4ge1xyXG4gICAgICBpZiAoaXRlcmF0aW9uICE9IGFyZ1N1YnNjcmlwdGlvbi5faXRlcmF0aW9uKSB7XHJcbiAgICAgICAgZGVsZXRlIGFyZ1N1YnNjcmlwdGlvbi5faWRzW2tleV07XHJcbiAgICAgICAgYXJnU3Vic2NyaXB0aW9uLnJlbW92ZWQoY2xpZW50TmFtZSwga2V5KTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgYXJnU3Vic2NyaXB0aW9uLl9pdGVyYXRpb24rKztcclxuICB9XHJcbik7XHJcbnZhciBsb2FkSW5pdGlhbE9ic2VydmVNYWluID0gTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChcclxuICAoYXJnU3Vic2NyaXB0aW9uLCBhcmdDb2xsZWN0aW9uLCBhcmdQaXBlbGluZSwgY2xpZW50TmFtZSwgbWF0Y2gpID0+IHtcclxuICAgIHZhciB0ZW1wID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShhcmdQaXBlbGluZSkpO1xyXG4gICAgdGVtcC51bnNoaWZ0KHtcclxuICAgICAgJG1hdGNoOiBtYXRjaFxyXG4gICAgfSk7XHJcbiAgICBhcmdDb2xsZWN0aW9uLmFnZ3JlZ2F0ZSh0ZW1wLCB7fSkuZm9yRWFjaChkb2MgPT4ge1xyXG4gICAgICBpZiAoIWFyZ1N1YnNjcmlwdGlvbi5faWRzW2RvYy5faWRdKSB7XHJcbiAgICAgICAgYXJnU3Vic2NyaXB0aW9uLmFkZGVkKGNsaWVudE5hbWUsIGRvYy5faWQsIGRvYyk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYXJnU3Vic2NyaXB0aW9uLmNoYW5nZWQoY2xpZW50TmFtZSwgZG9jLl9pZCwgZG9jKTtcclxuICAgICAgfVxyXG4gICAgICBhcmdTdWJzY3JpcHRpb24uX2lkc1tkb2MuX2lkXSA9IGFyZ1N1YnNjcmlwdGlvbi5faXRlcmF0aW9uO1xyXG4gICAgfSwge30pOyAvLyByZW1vdmUgZG9jdW1lbnRzIG5vdCBpbiB0aGUgcmVzdWx0IGFueW1vcmVcclxuICAgIF8uZWFjaChhcmdTdWJzY3JpcHRpb24uX2lkcywgKGl0ZXJhdGlvbiwga2V5KSA9PiB7XHJcbiAgICAgIGFyZ1N1YnNjcmlwdGlvbi5faWRzW2tleV0gPSBhcmdTdWJzY3JpcHRpb24uX2l0ZXJhdGlvbjtcclxuICAgIH0pO1xyXG4gICAgLypcclxuICAgIF8uZWFjaChhcmdTdWJzY3JpcHRpb24uX2lkcywgKGl0ZXJhdGlvbiwga2V5KSA9PiB7XHJcbiAgICAgICAgaWYgKGl0ZXJhdGlvbiAhPSBhcmdTdWJzY3JpcHRpb24uX2l0ZXJhdGlvbikge1xyXG4gICAgICAgICAgICBkZWxldGUgYXJnU3Vic2NyaXB0aW9uLl9pZHNba2V5XTtcclxuICAgICAgICAgICAgYXJnU3Vic2NyaXB0aW9uLnJlbW92ZWQoY2xpZW50TmFtZSwga2V5KTtcclxuICAgICAgICB9XHJcbiAgICB9KTsqL1xyXG5cclxuICAgIGFyZ1N1YnNjcmlwdGlvbi5faXRlcmF0aW9uKys7XHJcbiAgfVxyXG4pO1xyXG5cclxudmFyIGNyZWF0ZU9ic2VydmVyID0gTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChcclxuICAoXHJcbiAgICBtYWluQ29sbGVjdGlvbixcclxuICAgIGFyZ1N1YnNjcmlwdGlvbixcclxuICAgIGFyZ1BpcGVsaW5lLFxyXG4gICAgYXJnQ2xpZW50TmFtZSxcclxuICAgIHN1YmNvbGxlY3Rpb25cclxuICApID0+IHtcclxuICAgIGlmIChzdWJjb2xsZWN0aW9uICE9PSBudWxsKSB7XHJcbiAgICAgIHZhciB0ZW1wU3ViY29sbGVjdGlvbnMgPSBzdWJjb2xsZWN0aW9uLndhdGNoKFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICAkbWF0Y2g6IHt9XHJcbiAgICAgICAgfVxyXG4gICAgICBdKTtcclxuICAgICAgdGVtcFN1YmNvbGxlY3Rpb25zLm9uKFwiY2hhbmdlXCIsICgpID0+IHtcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICB0eXBlb2YgYXJnU3Vic2NyaXB0aW9uLnRpbWVvdXRlcnNbbWFpbkNvbGxlY3Rpb24uX25hbWVdICE9PVxyXG4gICAgICAgICAgXCJ1bmRlZmluZWRcIlxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgY2xlYXJUaW1lb3V0KGFyZ1N1YnNjcmlwdGlvbi50aW1lb3V0ZXJzW21haW5Db2xsZWN0aW9uLl9uYW1lXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFyZ1N1YnNjcmlwdGlvbi50aW1lb3V0ZXJzW21haW5Db2xsZWN0aW9uLl9uYW1lXSA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgbG9hZEluaXRpYWxPYnNlcnZlKFxyXG4gICAgICAgICAgICBhcmdTdWJzY3JpcHRpb24sXHJcbiAgICAgICAgICAgIG1haW5Db2xsZWN0aW9uLFxyXG4gICAgICAgICAgICBhcmdQaXBlbGluZSxcclxuICAgICAgICAgICAgYXJnQ2xpZW50TmFtZVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9LCA1MDApO1xyXG4gICAgICB9KTtcclxuICAgICAgYXJnU3Vic2NyaXB0aW9uLm9ic2VydmVySGFuZGxlcy5wdXNoKHRlbXBTdWJjb2xsZWN0aW9ucyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB2YXIgdGVtcE1haW5Db2xsZWN0aW9uID0gbWFpbkNvbGxlY3Rpb24ud2F0Y2goW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgICRtYXRjaDoge31cclxuICAgICAgICB9XHJcbiAgICAgIF0pO1xyXG4gICAgICB0ZW1wTWFpbkNvbGxlY3Rpb24ub24oXCJjaGFuZ2VcIiwgZGFzID0+IHtcclxuICAgICAgICBpZiAoZGFzLm9wZXJhdGlvblR5cGUgPT09IFwiZGVsZXRlXCIpIHtcclxuICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgdHlwZW9mIGFyZ1N1YnNjcmlwdGlvbi5faWRzW2Rhcy5kb2N1bWVudEtleS5faWRdICE9PSBcInVuZGVmaW5lZFwiXHJcbiAgICAgICAgICApIHtcclxuICAgICAgICAgICAgZGVsZXRlIGFyZ1N1YnNjcmlwdGlvbi5faWRzW2Rhcy5kb2N1bWVudEtleS5faWRdO1xyXG4gICAgICAgICAgICBhcmdTdWJzY3JpcHRpb24ucmVtb3ZlZChhcmdDbGllbnROYW1lLCBkYXMuZG9jdW1lbnRLZXkuX2lkKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICB0eXBlb2YgYXJnU3Vic2NyaXB0aW9uLnRpbWVvdXRlcnNbbWFpbkNvbGxlY3Rpb24uX25hbWVdICE9PVxyXG4gICAgICAgICAgICBcInVuZGVmaW5lZFwiXHJcbiAgICAgICAgICApIHtcclxuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KGFyZ1N1YnNjcmlwdGlvbi50aW1lb3V0ZXJzW21haW5Db2xsZWN0aW9uLl9uYW1lXSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBhcmdTdWJzY3JpcHRpb24udGltZW91dGVyc1ttYWluQ29sbGVjdGlvbi5fbmFtZV0gPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgbG9hZEluaXRpYWxPYnNlcnZlTWFpbihcclxuICAgICAgICAgICAgICBhcmdTdWJzY3JpcHRpb24sXHJcbiAgICAgICAgICAgICAgbWFpbkNvbGxlY3Rpb24sXHJcbiAgICAgICAgICAgICAgYXJnUGlwZWxpbmUsXHJcbiAgICAgICAgICAgICAgYXJnQ2xpZW50TmFtZSxcclxuICAgICAgICAgICAgICBkYXMuZG9jdW1lbnRLZXlcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH0sIDUwMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFyZ1N1YnNjcmlwdGlvbi50aW1lb3V0ZXJzW21haW5Db2xsZWN0aW9uLl9uYW1lXSA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgbG9hZEluaXRpYWxPYnNlcnZlKFxyXG4gICAgICAgICAgICBhcmdTdWJzY3JpcHRpb24sXHJcbiAgICAgICAgICAgIG1haW5Db2xsZWN0aW9uLFxyXG4gICAgICAgICAgICBhcmdQaXBlbGluZSxcclxuICAgICAgICAgICAgYXJnQ2xpZW50TmFtZVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9LCA1MDApO1xyXG4gICAgICB9KTtcclxuICAgICAgYXJnU3Vic2NyaXB0aW9uLm9ic2VydmVySGFuZGxlcy5wdXNoKHRlbXBNYWluQ29sbGVjdGlvbik7XHJcbiAgICB9XHJcbiAgfVxyXG4pO1xyXG5cclxuZnVuY3Rpb24gY29ubmVjdE9yR2V0Q29ubmVjdGlvbihhcmdTdWJzY3JpcHRpb24pIHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoIE1ldGVvci5iaW5kRW52aXJvbm1lbnQoKHJlcywgcmVqKSA9PiB7XHJcbiAgICBcclxuICAgIGlmKGFyZ1N1YnNjcmlwdGlvbi5fc2Vzc2lvbi5tb25nb0NsaWVudCA9PT0gbnVsbCl7XHJcbiAgICAgIFxyXG4gICAgICAgIGNsaWVudC5jb25uZWN0KFxyXG4gICAgICAgICAgICB1cmwsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICB1c2VOZXdVcmxQYXJzZXI6IHRydWUsXHJcbiAgICAgICAgICAgICAgcmVjb25uZWN0VHJpZXM6IDYwLFxyXG4gICAgICAgICAgICAgIHJlY29ubmVjdEludGVydmFsOiAxMDAwLFxyXG4gICAgICAgICAgICAgIGJ1ZmZlck1heEVudHJpZXM6IDMwMDAwMFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBmdW5jdGlvbihlcnIsIGNsaWVudCkge1xyXG4gICAgICAgICAgICAgICBhcmdTdWJzY3JpcHRpb24uX3Nlc3Npb24ubW9uZ29DbGllbnQgPSBjbGllbnQ7XHJcbiAgICAgICAgICAgICAgcmVzKGNsaWVudCk7XHJcblxyXG4gICAgICAgIH0pO1xyXG4gICAgfWVsc2V7XHJcbiAgICAgICAgcmVzKGFyZ1N1YnNjcmlwdGlvbi5fc2Vzc2lvbi5tb25nb0NsaWVudCk7XHJcbiAgICB9XHJcbn0pXHJcbilcclxufTtcclxuXHJcbmZ1bmN0aW9uIHN0YXJ0R29Vc2UoYXJnU3Vic2NyaXB0aW9uLGFyZ0NvbGxlY3Rpb24sYXJnUGlwZWxpbmUsIGFyZ0NsaWVudE5hbWUsY2xpZW50KXtcclxuXHJcblxyXG5cclxuXHJcblxyXG4gICAgYXJnU3Vic2NyaXB0aW9uLmlrcmNsaWVudCA9IGNsaWVudDtcclxuICAgIGFyZ1N1YnNjcmlwdGlvbi5vYnNlcnZlckhhbmRsZXMgPSBbXTtcclxuICAgIGFyZ1N1YnNjcmlwdGlvbi50aW1lb3V0ZXJzID0ge307XHJcbiAgICBhcmdTdWJzY3JpcHRpb24uZGJJa3IgPSBjbGllbnRbXCJkYlwiXShtcCh1cmwpLmRiTmFtZSk7XHJcbiAgICB2YXIgY2xpZW50TmFtZTtcclxuICAgIGlmIChhcmdDbGllbnROYW1lID09PSBudWxsKSB7XHJcbiAgICAgIGNsaWVudE5hbWUgPSBhcmdDb2xsZWN0aW9uLl9uYW1lO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY2xpZW50TmFtZSA9IGFyZ0NsaWVudE5hbWU7XHJcbiAgICB9XHJcbiAgICBhcmdTdWJzY3JpcHRpb24uX2lkcyA9IHt9O1xyXG4gICAgYXJnU3Vic2NyaXB0aW9uLl9pdGVyYXRpb24gPSAxO1xyXG4gICAgYXJnU3Vic2NyaXB0aW9uLnJlYWR5KCk7XHJcbiAgICBsb2FkSW5pdGlhbChcclxuICAgICAgYXJnU3Vic2NyaXB0aW9uLmRiSWtyLmNvbGxlY3Rpb24oYXJnQ29sbGVjdGlvbi5fbmFtZSksXHJcbiAgICAgIGFyZ1N1YnNjcmlwdGlvbixcclxuICAgICAgYXJnUGlwZWxpbmUsXHJcbiAgICAgIGNsaWVudE5hbWVcclxuICAgICk7XHJcbiAgICBjcmVhdGVPYnNlcnZlcihcclxuICAgICAgYXJnU3Vic2NyaXB0aW9uLmRiSWtyLmNvbGxlY3Rpb24oYXJnQ29sbGVjdGlvbi5fbmFtZSksXHJcbiAgICAgIGFyZ1N1YnNjcmlwdGlvbixcclxuICAgICAgYXJnUGlwZWxpbmUsXHJcbiAgICAgIGNsaWVudE5hbWUsXHJcbiAgICAgIG51bGxcclxuICAgICk7XHJcbiAgICBhcmdQaXBlbGluZS5tYXAoc3RhZ2UgPT4ge1xyXG4gICAgICBpZiAoc3RhZ2UuJGxvb2t1cCkge1xyXG4gICAgICAgIGNyZWF0ZU9ic2VydmVyKFxyXG4gICAgICAgICAgYXJnU3Vic2NyaXB0aW9uLmRiSWtyLmNvbGxlY3Rpb24oYXJnQ29sbGVjdGlvbi5fbmFtZSksXHJcbiAgICAgICAgICBhcmdTdWJzY3JpcHRpb24sXHJcbiAgICAgICAgICBhcmdQaXBlbGluZSxcclxuICAgICAgICAgIGNsaWVudE5hbWUsXHJcbiAgICAgICAgICBhcmdTdWJzY3JpcHRpb24uZGJJa3IuY29sbGVjdGlvbihzdGFnZS4kbG9va3VwLmZyb20pXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHdhdGNoQ2xpZW50UmVhZHkoYXJnU3Vic2NyaXB0aW9uLGFyZ0NvbGxlY3Rpb24sYXJnUGlwZWxpbmUsYXJnQ2xpZW50TmFtZSl7XHJcbiAgICBpZiggYXJnU3Vic2NyaXB0aW9uLl9zZXNzaW9uLm1vbmdvQ2xpZW50ICE9PSBudWxsKXtcclxuICAgICAgICBzdGFydEdvVXNlKGFyZ1N1YnNjcmlwdGlvbixhcmdDb2xsZWN0aW9uLGFyZ1BpcGVsaW5lLGFyZ0NsaWVudE5hbWUsYXJnU3Vic2NyaXB0aW9uLl9zZXNzaW9uLm1vbmdvQ2xpZW50KTtcclxuICAgIH1lbHNle1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCk9PntcclxuICAgICAgICAgICAgd2F0Y2hDbGllbnRSZWFkeShhcmdTdWJzY3JpcHRpb24sYXJnQ29sbGVjdGlvbixhcmdQaXBlbGluZSxhcmdDbGllbnROYW1lKVxyXG4gICAgICAgIH0sNTAwKTtcclxuICAgIH1cclxufVxyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBJa3JSZWFjdGl2ZUFnZ3JlZ2F0ZShhcmdTdWJzY3JpcHRpb24sXHJcbiAgICBhcmdDb2xsZWN0aW9uLFxyXG4gICAgYXJnUGlwZWxpbmUgPSBbXSxcclxuICAgIGFyZ0NsaWVudE5hbWUpe1xyXG5cclxuICAgICAgICBpZih0eXBlb2YgYXJnU3Vic2NyaXB0aW9uLl9zZXNzaW9uLmNsb3NlV2F0Y2hlciA9PT0gXCJ1bmRlZmluZWRcIil7XHJcbiAgICAgICAgICAgIGFyZ1N1YnNjcmlwdGlvbi5fc2Vzc2lvbi5jbG9zZVdhdGNoZXIgPSB0cnVlO1xyXG4gICAgICAgICAgICBhcmdTdWJzY3JpcHRpb24uX3Nlc3Npb24ubW9uZ29DbGllbnQgPSBudWxsO1xyXG5cclxuICAgICAgICAgICAgYXJnU3Vic2NyaXB0aW9uLl9zZXNzaW9uLnNvY2tldC5vbihcclxuICAgICAgICAgICAgICAgIFwiY2xvc2VcIixcclxuICAgICAgICAgICAgICAgIE1ldGVvci5iaW5kRW52aXJvbm1lbnQoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgIGlmKGFyZ1N1YnNjcmlwdGlvbi5fc2Vzc2lvbi5tb25nb0NsaWVudCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGFyZ1N1YnNjcmlwdGlvbi5fc2Vzc2lvbi5tb25nb0NsaWVudC5jbG9zZSgpO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgY29ubmVjdE9yR2V0Q29ubmVjdGlvbihhcmdTdWJzY3JpcHRpb24pLnRoZW4oY2xpZW50ID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgICBzdGFydEdvVXNlKGFyZ1N1YnNjcmlwdGlvbixhcmdDb2xsZWN0aW9uLGFyZ1BpcGVsaW5lLGFyZ0NsaWVudE5hbWUsY2xpZW50KTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIHdhdGNoQ2xpZW50UmVhZHkoYXJnU3Vic2NyaXB0aW9uLGFyZ0NvbGxlY3Rpb24sYXJnUGlwZWxpbmUsYXJnQ2xpZW50TmFtZSlcclxuICAgICAgICB9IFxyXG4gICAgICAgXHJcblxyXG4gICAgICAgICAgYXJnU3Vic2NyaXB0aW9uLm9uU3RvcCgoKSA9PiB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgdmFyIHByb21BcnIgPSBbXTtcclxuICAgICAgICAgICAgICBpZiAodHlwZW9mIGFyZ1N1YnNjcmlwdGlvbi5vYnNlcnZlckhhbmRsZXMgIT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICAgICAgICAgIGZvciAodmFyIHQgPSAwOyB0IDwgYXJnU3Vic2NyaXB0aW9uLm9ic2VydmVySGFuZGxlcy5sZW5ndGg7IHQrKykge1xyXG4gICAgICAgICAgICAgICAgICBwcm9tQXJyLnB1c2goYXJnU3Vic2NyaXB0aW9uLm9ic2VydmVySGFuZGxlc1t0XS5jdXJzb3IuY2xvc2UoKSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgY29uc29sZS5sb2coYXJnU3Vic2NyaXB0aW9uLm9ic2VydmVySGFuZGxlc1t0XS5jdXJzb3IpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIFByb21pc2UuYWxsKHByb21BcnIpLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgICAgIGlmICh0eXBlb2YgYXJnU3Vic2NyaXB0aW9uLnRpbWVvdXRlcnMgIT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICAgICAgICAgIGZvciAodmFyIGEgaW4gYXJnU3Vic2NyaXB0aW9uLnRpbWVvdXRlcnMpIHtcclxuICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBhcmdTdWJzY3JpcHRpb24udGltZW91dGVyc1thXSAhPT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dChhcmdTdWJzY3JpcHRpb24udGltZW91dGVyc1thXSk7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgYXJnU3Vic2NyaXB0aW9uLm9ic2VydmVySGFuZGxlcyA9IFtdO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgXHJcbn07IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcclxuaW1wb3J0IHsgTW9uZ28gfSBmcm9tIFwibWV0ZW9yL21vbmdvXCI7XHJcbnZhciBfID0gcmVxdWlyZShcInVuZGVyc2NvcmVcIik7XHJcbnZhciBtb25nb2RiID0gcmVxdWlyZShcIm1vbmdvZGJcIik7XHJcbnZhciBjbGllbnQgPSBtb25nb2RiLk1vbmdvQ2xpZW50O1xyXG52YXIgdXJsID0gcHJvY2Vzcy5lbnYuTU9OR09fVVJMO1xyXG52YXIgZGI7XHJcbnZhciBtcCA9IHJlcXVpcmUoXCJwYXJzZS1tb25nby11cmxcIik7XHJcbnZhciBjb25uZWN0aW9ucyA9IHt9O1xyXG5cclxuZnVuY3Rpb24gbG9hZEluaXRpYWwoYXJnQ29sbGVjdGlvbiwgYXJnU3Vic2NyaXB0aW9uLCBhcmdQaXBlbGluZSwgY2xpZW50TmFtZSkge1xyXG4gIGFyZ0NvbGxlY3Rpb24ucmF3Q29sbGVjdGlvbigpLmFnZ3JlZ2F0ZShhcmdQaXBlbGluZSwgeyBhbGxvd0Rpc2tVc2U6IHRydWUgfSkuZm9yRWFjaChkb2MgPT4ge1xyXG5cclxuICAgIGlmICghYXJnU3Vic2NyaXB0aW9uLl9pZHNbZG9jLl9pZF0pIHtcclxuICAgICAgYXJnU3Vic2NyaXB0aW9uLmFkZGVkKGNsaWVudE5hbWUsIGRvYy5faWQsIGRvYyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhcmdTdWJzY3JpcHRpb24uY2hhbmdlZChjbGllbnROYW1lLCBkb2MuX2lkLCBkb2MpO1xyXG4gICAgfVxyXG5cclxuICAgIGFyZ1N1YnNjcmlwdGlvbi5faWRzW2RvYy5faWRdID0gYXJnU3Vic2NyaXB0aW9uLl9pdGVyYXRpb247XHJcbiAgfSwge30pOyAvLyByZW1vdmUgZG9jdW1lbnRzIG5vdCBpbiB0aGUgcmVzdWx0IGFueW1vcmVcclxuXHJcbiAgXHJcbiAgXy5lYWNoKGFyZ1N1YnNjcmlwdGlvbi5faWRzLCAoaXRlcmF0aW9uLCBrZXkpID0+IHtcclxuICAgIGlmIChpdGVyYXRpb24gIT0gYXJnU3Vic2NyaXB0aW9uLl9pdGVyYXRpb24pIHtcclxuICAgICAgZGVsZXRlIGFyZ1N1YnNjcmlwdGlvbi5faWRzW2tleV07XHJcbiAgICAgIGFyZ1N1YnNjcmlwdGlvbi5yZW1vdmVkKGNsaWVudE5hbWUsIGtleSk7XHJcbiAgICB9XHJcbiAgfSk7XHJcbiAgYXJnU3Vic2NyaXB0aW9uLl9pdGVyYXRpb24rKztcclxufVxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIElrclJlYWN0aXZlQWdncmVnYXRlTG9jKGFyZ1N1YnNjcmlwdGlvbixcclxuICBhcmdDb2xsZWN0aW9uLFxyXG4gIGFyZ1BpcGVsaW5lID0gW10sXHJcbiAgYXJnQ2xpZW50TmFtZSkge1xyXG5cclxuICBhcmdTdWJzY3JpcHRpb24uX2lkcyA9IHt9O1xyXG4gIGFyZ1N1YnNjcmlwdGlvbi5faXRlcmF0aW9uID0gMTtcclxuICBhcmdTdWJzY3JpcHRpb24ucmVhZHkoKTtcclxuICB2YXIgbXlBcmcgPSBhcmdDb2xsZWN0aW9uLmZpbmQoe30sIHt9KS5vYnNlcnZlQ2hhbmdlcyh7XHJcbiAgICBhZGRlZDogKGRhdGEpID0+IHtcclxuICAgICAgbG9hZEluaXRpYWwoYXJnQ29sbGVjdGlvbiwgYXJnU3Vic2NyaXB0aW9uLCBhcmdQaXBlbGluZSwgYXJnQ2xpZW50TmFtZSlcclxuICAgIH0sXHJcbiAgICBjaGFuZ2VkOiAoZGF0YSkgPT4ge1xyXG4gICAgICBsb2FkSW5pdGlhbChhcmdDb2xsZWN0aW9uLCBhcmdTdWJzY3JpcHRpb24sIGFyZ1BpcGVsaW5lLCBhcmdDbGllbnROYW1lKVxyXG4gICAgfSxcclxuICAgIGVycm9yOiAoZXJyKSA9PiB7XHJcbiAgICAgIHRocm93IGVycjtcclxuICAgIH1cclxuICB9KTtcclxuXHJcblxyXG5cclxuXHJcbiAgYXJnU3Vic2NyaXB0aW9uLm9uU3RvcCgoKSA9PiB7XHJcbiAgICBteUFyZy5zdG9wKCk7XHJcbiAgfSk7XHJcblxyXG59OyIsImV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZU5ld0lkKCkge1xyXG4gICAgdmFyIE9iamVjdElkID0gcmVxdWlyZSgnbW9uZ29kYicpLk9iamVjdElEXHJcbiAgICB2YXIgaWQgPSBuZXcgT2JqZWN0SWQoKTtcclxuICAgIHJldHVybiBpZC50b0hleFN0cmluZygpXHJcbn0iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHtcclxuICAgIFVzZXJzLENoYWxhbmdlc30gZnJvbSAnLi4vY29sbGVjdGlvbnMvaW5kZXgnO1xyXG5pbXBvcnQgeyBJa3JSZWFjdGl2ZUFnZ3JlZ2F0ZSB9IGZyb20gJy4uL2xpYk1vZHVsZXMvcmVhY3RpdmVhZ2dyZWdhdGUnO1xyXG5pbXBvcnQgeyBnZW5lcmF0ZUZpbHRlciwgZ2VuZXJhdGVTb3J0aW5nIH0gZnJvbSAnLi4vbGliTW9kdWxlcy9kYXRhZ3JpZG1vbmdvaGVscGVyJztcclxuaW1wb3J0ICogYXMgRnV0dXJlIGZyb20gJ2ZpYmVycy9mdXR1cmUnO1xyXG5cclxuLyoqXHJcbiAqICBBbGxnZW1laW5cclxuICovXHJcbk1ldGVvci5wdWJsaXNoKCdjaGFsbGFuZ2UnLCBmdW5jdGlvbiAoY2hhbGxhbmdlKSB7XHJcbiAgICBjb25zdCBmdXQgPSBuZXcgRnV0dXJlKCk7XHJcbiAgICB2YXIgZGF0YSA9IENoYWxhbmdlcy5pbnNlcnQoe1xyXG4gICAgICAgIGNoYWxsYW5nZTpjaGFsbGFuZ2UsXHJcbiAgICAgICAgc3RhdGU6bWFrZWlkKDIwKSxcclxuICAgICAgICB0b2tlbjpcIlwiXHJcbiAgICB9KTtcclxuICAgIGRhdGEudG9Qcm9taXNlKCkudGhlbigoZCk9PntcclxuICAgXHJcbiAgICAgICAgdGhpcy5vblN0b3AoKCk9PntcclxuICAgICAgICAgICBcclxuICAgICAgICAgICAgQ2hhbGFuZ2VzLnJlbW92ZSh7IF9pZDpkfSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGZ1dC5yZXR1cm4oQ2hhbGFuZ2VzLmNvbGxlY3Rpb24uZmluZCh7XCJfaWRcIjpkfSx7ZmllbGRzOnt0b2tlbjoxLGNoYWxsYW5nZToxfX0pKTtcclxuXHJcbiAgICB9KTtcclxuICAgIHJldHVybiBmdXQud2FpdCgpO1xyXG59KTtcclxuXHJcbmZ1bmN0aW9uIG1ha2VpZChsZW5ndGgpIHtcclxuICAgIHZhciByZXN1bHQgICAgICAgICAgID0gJyc7XHJcbiAgICB2YXIgY2hhcmFjdGVycyAgICAgICA9ICdBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSc7XHJcbiAgICB2YXIgY2hhcmFjdGVyc0xlbmd0aCA9IGNoYXJhY3RlcnMubGVuZ3RoO1xyXG4gICAgZm9yICggdmFyIGkgPSAwOyBpIDwgbGVuZ3RoOyBpKysgKSB7XHJcbiAgICAgICByZXN1bHQgKz0gY2hhcmFjdGVycy5jaGFyQXQoTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogY2hhcmFjdGVyc0xlbmd0aCkpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxuIH0iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xyXG5pbXBvcnQgeyBVc2VycywgQ2hhbGFuZ2VzLCBFdmVudHMgfSBmcm9tIFwiLi4vY29sbGVjdGlvbnMvaW5kZXhcIjtcclxuaW1wb3J0IHsgSWtyUmVhY3RpdmVBZ2dyZWdhdGUgfSBmcm9tIFwiLi4vbGliTW9kdWxlcy9yZWFjdGl2ZWFnZ3JlZ2F0ZVwiO1xyXG5pbXBvcnQge1xyXG4gIGdlbmVyYXRlRmlsdGVyLFxyXG4gIGdlbmVyYXRlU29ydGluZ1xyXG59IGZyb20gXCIuLi9saWJNb2R1bGVzL2RhdGFncmlkbW9uZ29oZWxwZXJcIjtcclxuaW1wb3J0ICogYXMgRnV0dXJlIGZyb20gXCJmaWJlcnMvZnV0dXJlXCI7XHJcblxyXG5NZXRlb3IucHVibGlzaChcImV2ZW50c1wiLCBmdW5jdGlvbihzdGFydCwgZW5kLCB1c2VySWRzKSB7XHJcbiAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIEV2ZW50cy5maW5kKHt9KTtcclxufSk7XHJcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XHJcbmltcG9ydCB7IFVzZXJzIH0gZnJvbSBcIi4uL2NvbGxlY3Rpb25zL2luZGV4XCI7XHJcbmltcG9ydCB7IElrclJlYWN0aXZlQWdncmVnYXRlIH0gZnJvbSBcIi4uL2xpYk1vZHVsZXMvcmVhY3RpdmVhZ2dyZWdhdGVcIjtcclxuaW1wb3J0IHsgSWtyUmVhY3RpdmVBZ2dyZWdhdGVMb2MgfSBmcm9tICcuLi9saWJNb2R1bGVzL3JlYWN0aXZlYWdncmVnYXRlTG9jJztcclxuXHJcbmltcG9ydCB7XHJcbiAgZ2VuZXJhdGVGaWx0ZXIsXHJcbiAgZ2VuZXJhdGVTb3J0aW5nXHJcbn0gZnJvbSBcIi4uL2xpYk1vZHVsZXMvZGF0YWdyaWRtb25nb2hlbHBlclwiO1xyXG5cclxuLyoqXHJcbiAqICBBbGxnZW1laW5cclxuICovXHJcbk1ldGVvci5wdWJsaXNoKFwibWVcIiwgZnVuY3Rpb24oKSB7XHJcbiAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBcclxuICB2YXIgYXJyQWdncmVnYXRlID0gW1xyXG4gICAge1xyXG4gICAgICAkbWF0Y2g6IHtcclxuICAgICAgICBfaWQ6IHRoaXMudXNlcklkXHJcbiAgICAgIH1cclxuICAgIH1cclxuICBdO1xyXG5cclxuICBJa3JSZWFjdGl2ZUFnZ3JlZ2F0ZSh0aGlzLCBVc2Vyc1tcIl9jb2xsZWN0aW9uXCJdLCBhcnJBZ2dyZWdhdGUsIFwibWVcIik7XHJcbn0pO1xyXG5cclxuTWV0ZW9yLnB1Ymxpc2goXCJ1c2VyT25saW5lXCIsIGZ1bmN0aW9uKCkge1xyXG4gIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgdmFyIGFyckFnZ3JlZ2F0ZSA9IFtcclxuICAgIHtcclxuICAgICAgJG1hdGNoOiB7XHJcbiAgICAgICAgXCJzdGF0dXMub25saW5lXCI6IHRydWVcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIF07XHJcbiAgSWtyUmVhY3RpdmVBZ2dyZWdhdGUodGhpcywgVXNlcnNbXCJfY29sbGVjdGlvblwiXSwgYXJyQWdncmVnYXRlLCBcInVzZXJPbmxpbmVcIik7XHJcbn0pO1xyXG5cclxuXHJcblxyXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHtcclxuICAgIG1vbmdvVGVhbXN9IGZyb20gJy4uL2NvbGxlY3Rpb25zL2luZGV4JztcclxuaW1wb3J0IHsgSWtyUmVhY3RpdmVBZ2dyZWdhdGUgfSBmcm9tICcuLi9saWJNb2R1bGVzL3JlYWN0aXZlYWdncmVnYXRlJztcclxuaW1wb3J0IHsgSWtyUmVhY3RpdmVBZ2dyZWdhdGVMb2MgfSBmcm9tICcuLi9saWJNb2R1bGVzL3JlYWN0aXZlYWdncmVnYXRlTG9jJztcclxuaW1wb3J0IHsgZ2VuZXJhdGVGaWx0ZXIsIGdlbmVyYXRlU29ydGluZyB9IGZyb20gJy4uL2xpYk1vZHVsZXMvZGF0YWdyaWRtb25nb2hlbHBlcic7XHJcblxyXG5NZXRlb3IucHVibGlzaCgndGVhbXNJZmluaXR5U3Jjb2xsJywgZnVuY3Rpb24gKHNraXAsIGxpbWl0LGZpbHRlcik6IGFueSB7XHJcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgdmFyIGFyckFnZ3JlZ2F0ZSA9IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiJG1hdGNoXCI6IHt9XHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgICRncm91cDoge1xyXG4gICAgICAgICAgICAgICAgXCJfaWRcIjogbnVsbCxcclxuICAgICAgICAgICAgICAgIFwiY291bnRcIjoge1xyXG4gICAgICAgICAgICAgICAgICAgIFwiJHN1bVwiOiAxLjBcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBcImRhdGFcIjoge1xyXG4gICAgICAgICAgICAgICAgICAgIFwiJHB1c2hcIjogXCIkJFJPT1RcIlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgICR1bndpbmQ6IHtcclxuICAgICAgICAgICAgICAgIFwicGF0aFwiOiBcIiRkYXRhXCJcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICAkYWRkRmllbGRzOiB7XHJcbiAgICAgICAgICAgICAgICBcImRhdGEuY291bnRcIjoge1xyXG4gICAgICAgICAgICAgICAgICAgIFwiJGFkZFwiOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiJGNvdW50XCJcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgJHJlcGxhY2VSb290OiB7XHJcbiAgICAgICAgICAgICAgICBcIm5ld1Jvb3RcIjogXCIkZGF0YVwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgXCIkc2tpcFwiOiBza2lwXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiJGxpbWl0XCI6IGxpbWl0XHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgICRzb3J0OiB7XHJcbiAgICAgICAgICAgICAgICBcInRpdGxlXCI6IDEgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHsgXHJcbiAgICAgICAgICAgIFwiJGxvb2t1cFwiIDoge1xyXG4gICAgICAgICAgICAgICAgXCJmcm9tXCIgOiBcInVzZXJzXCIsIFxyXG4gICAgICAgICAgICAgICAgXCJsb2NhbEZpZWxkXCIgOiBcImxlYWRlclwiLCBcclxuICAgICAgICAgICAgICAgIFwiZm9yZWlnbkZpZWxkXCIgOiBcIl9pZFwiLCBcclxuICAgICAgICAgICAgICAgIFwiYXNcIiA6IFwibGVhZGVyTGlzdFwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHsgXHJcbiAgICAgICAgICAgIFwiJGxvb2t1cFwiIDoge1xyXG4gICAgICAgICAgICAgICAgXCJmcm9tXCIgOiBcInVzZXJzXCIsIFxyXG4gICAgICAgICAgICAgICAgXCJsb2NhbEZpZWxkXCIgOiBcIm1lbWJlclwiLCBcclxuICAgICAgICAgICAgICAgIFwiZm9yZWlnbkZpZWxkXCIgOiBcIl9pZFwiLCBcclxuICAgICAgICAgICAgICAgIFwiYXNcIiA6IFwibWVtYmVyTGlzdFwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICBdXHJcbiAgICBpZihmaWx0ZXIgIT09IFwiXCIpe1xyXG5cclxuICAgICAgICB2YXIgYW5kID0gZmlsdGVyLnNwbGl0KFwiIFwiKTtcclxuICAgICAgICB2YXIgb2JqID0ge1xyXG4gICAgICAgICAgICBcIiRhbmRcIjpbXVxyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IodmFyIGwgPSAwOyBsIDwgYW5kLmxlbmd0aDtsKyspe1xyXG4gICAgICAgICAgICB2YXIgcmVnID0gbmV3IFJlZ0V4cChcIi4qXCIrYW5kW2xdK1wiLipcIixcImlcIilcclxuICAgICAgICAgICAgb2JqW1wiJGFuZFwiXS5wdXNoKHsgJG9yOiBbIHsgXCJ0aXRsZVwiOiByZWcgfSwgeyBcImRlc2NyaXB0aW9uXCI6IHJlZyB9IF0gfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICBcclxuICAgICAgICBhcnJBZ2dyZWdhdGVbMF1bXCIkbWF0Y2hcIl0gPSBvYmo7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIElrclJlYWN0aXZlQWdncmVnYXRlKHRoaXMsIG1vbmdvVGVhbXMsIGFyckFnZ3JlZ2F0ZSwgXCJ0ZWFtc0lmaW5pdHlTcmNvbGxcIik7XHJcbn0pOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQge1xyXG4gICAgVXNlcnN9IGZyb20gJy4uL2NvbGxlY3Rpb25zL2luZGV4JztcclxuaW1wb3J0IHsgSWtyUmVhY3RpdmVBZ2dyZWdhdGUgfSBmcm9tICcuLi9saWJNb2R1bGVzL3JlYWN0aXZlYWdncmVnYXRlJztcclxuaW1wb3J0IHsgSWtyUmVhY3RpdmVBZ2dyZWdhdGVMb2MgfSBmcm9tICcuLi9saWJNb2R1bGVzL3JlYWN0aXZlYWdncmVnYXRlTG9jJztcclxuaW1wb3J0IHsgZ2VuZXJhdGVGaWx0ZXIsIGdlbmVyYXRlU29ydGluZyB9IGZyb20gJy4uL2xpYk1vZHVsZXMvZGF0YWdyaWRtb25nb2hlbHBlcic7XHJcblxyXG4vKlxyXG5cclxuSW5maW5pdHkgU2Nyb2xsXHJcblxyXG4qL1xyXG5NZXRlb3IucHVibGlzaCgndXNlcklmaW5pdHlTcmNvbGwnLCBmdW5jdGlvbiAoc2tpcCwgbGltaXQsZmlsdGVyKTogYW55IHtcclxuICAgIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICB2YXIgYXJyQWdncmVnYXRlID0gW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgXCIkbWF0Y2hcIjoge31cclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBcIl9pZFwiOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgXCJjb3VudFwiOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgXCIkc3VtXCI6IDEuMFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIFwiZGF0YVwiOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgXCIkcHVzaFwiOiBcIiQkUk9PVFwiXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgJHVud2luZDoge1xyXG4gICAgICAgICAgICAgICAgXCJwYXRoXCI6IFwiJGRhdGFcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgICRhZGRGaWVsZHM6IHtcclxuICAgICAgICAgICAgICAgIFwiZGF0YS5jb3VudFwiOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgXCIkYWRkXCI6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCIkY291bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICAkcmVwbGFjZVJvb3Q6IHtcclxuICAgICAgICAgICAgICAgIFwibmV3Um9vdFwiOiBcIiRkYXRhXCJcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBcIiRza2lwXCI6IHNraXBcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgXCIkbGltaXRcIjogbGltaXRcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgJHNvcnQ6IHtcclxuICAgICAgICAgICAgICAgIFwiZW1haWxzLmFkZHJlc3NcIjogMSBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIF1cclxuXHJcbiAgICBpZihmaWx0ZXIgIT09IFwiXCIpe1xyXG5cclxuICAgICAgICB2YXIgYW5kID0gZmlsdGVyLnNwbGl0KFwiIFwiKTtcclxuICAgICAgICB2YXIgb2JqID0ge1xyXG4gICAgICAgICAgICBcIiRhbmRcIjpbXVxyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IodmFyIGwgPSAwOyBsIDwgYW5kLmxlbmd0aDtsKyspe1xyXG4gICAgICAgICAgICB2YXIgcmVnID0gbmV3IFJlZ0V4cChcIi4qXCIrYW5kW2xdK1wiLipcIixcImlcIilcclxuICAgICAgICAgICAgb2JqW1wiJGFuZFwiXS5wdXNoKHsgJG9yOiBbIHsgXCJlbWFpbHMuYWRkcmVzc1wiOiByZWcgfSwgeyBcInByb2ZpbGUuZmlyc3ROYW1lXCI6IHJlZyB9LCB7IFwicHJvZmlsZS5sYXN0TmFtZVwiOiByZWcgfSBdIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgXHJcbiAgICAgICAgYXJyQWdncmVnYXRlWzBdW1wiJG1hdGNoXCJdID0gb2JqO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBJa3JSZWFjdGl2ZUFnZ3JlZ2F0ZSh0aGlzLCBVc2Vycy5jb2xsZWN0aW9uLCBhcnJBZ2dyZWdhdGUsIFwidXNlcklmaW5pdHlTcmNvbGxcIik7XHJcbn0pO1xyXG4vKipcclxuICogIFVzZXJzXHJcbiAqL1xyXG5NZXRlb3IucHVibGlzaCgndXNlcnNHcmlkJywgZnVuY3Rpb24gKHNraXAsIGxpbWl0LCBzb3J0LCBmaWx0ZXIpOiBhbnkge1xyXG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHZhciBhcnJBZ2dyZWdhdGUgPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBcIiRtYXRjaFwiOiB7fVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIFwiX2lkXCI6IG51bGwsXHJcbiAgICAgICAgICAgICAgICBcImNvdW50XCI6IHtcclxuICAgICAgICAgICAgICAgICAgICBcIiRzdW1cIjogMS4wXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgXCJkYXRhXCI6IHtcclxuICAgICAgICAgICAgICAgICAgICBcIiRwdXNoXCI6IFwiJCRST09UXCJcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgLy8gU3RhZ2UgM1xyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgJHVud2luZDoge1xyXG4gICAgICAgICAgICAgICAgXCJwYXRoXCI6IFwiJGRhdGFcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICAvLyBTdGFnZSA0XHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICAkYWRkRmllbGRzOiB7XHJcbiAgICAgICAgICAgICAgICBcImRhdGEuY291bnRcIjoge1xyXG4gICAgICAgICAgICAgICAgICAgIFwiJGFkZFwiOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiJGNvdW50XCJcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIC8vIFN0YWdlIDUgTGFzdCBzdGFnZSBmb3IgdGhlIGNvdW50IGZ1bmN0aW9uXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICAkcmVwbGFjZVJvb3Q6IHtcclxuICAgICAgICAgICAgICAgIFwibmV3Um9vdFwiOiBcIiRkYXRhXCJcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBcIiRza2lwXCI6IHNraXBcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgXCIkbGltaXRcIjogbGltaXRcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgJHNvcnQ6IHt9XHJcbiAgICAgICAgfVxyXG4gICAgXTtcclxuICAgIGFyckFnZ3JlZ2F0ZVswXVtcIiRtYXRjaFwiXSA9IGdlbmVyYXRlRmlsdGVyKGZpbHRlciwgbnVsbCk7XHJcbiAgICBhcnJBZ2dyZWdhdGVbN11bXCIkc29ydFwiXSA9IGdlbmVyYXRlU29ydGluZyhzb3J0KTtcclxuICAgIElrclJlYWN0aXZlQWdncmVnYXRlKHRoaXMsIFVzZXJzLmNvbGxlY3Rpb24sIGFyckFnZ3JlZ2F0ZSwgXCJ1c2Vyc0dyaWRcIilcclxufSk7XHJcbk1ldGVvci5wdWJsaXNoKCdzZWFyY2hVc2VyJywgZnVuY3Rpb24gKHNlYXJjaCkge1xyXG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHZhciBhcnJBZ2dyZWdhdGUgPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBcIiRtYXRjaFwiOiB7ICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIFwicHJvZmlsZS5uYW1lXCI6IG5ldyBSZWdFeHAoXCIuKlwiICsgc2VhcmNoICsgXCIuKlwiLCAnaScpICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBcIiRsaW1pdFwiOiAyMC4wXHJcbiAgICAgICAgfVxyXG4gICAgXTtcclxuICAgIElrclJlYWN0aXZlQWdncmVnYXRlKHRoaXMsIFVzZXJzLmNvbGxlY3Rpb24sIGFyckFnZ3JlZ2F0ZSwgXCJzZWFyY2hVc2VyXCIpO1xyXG59KTsiLCJpbXBvcnQgKiBhcyBGdXR1cmUgZnJvbSAnZmliZXJzL2Z1dHVyZSc7XHJcbmltcG9ydCAqIGFzICBuZWVkbGUgZnJvbSAnbmVlZGxlJztcclxuaW1wb3J0IHsgVXNlcnMgfSBmcm9tICcuLi9jb2xsZWN0aW9ucyc7XHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJztcclxuXHJcblxyXG52YXIgZ29vZ2xlQ2xpZW50SWQgPSBcIjI4NzE1MzA2MDc1OC1vMjkwNjMzbDA0cWxqM3Vhb25kbWtoM2FjNTZzOTJubC5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbVwiOy8vM01WRzk2XzdZTTJzSTl3VDVsUGlIa2t6eTluRndBVjdxNEptejFlX1Noemd6cks0WXRQS2NJWHRFTWtBdWhORThUSV9TM0ZFZ3NGZVRfUDB5OXhFblxyXG52YXIgZ29vZ2xlU2VjcmV0ID0gXCJEMS1aRE4zTFNRZTFScnB2R0NqekhCaDBcIjsgLy81RDBGOUVGQTQ3NjVCMjFGRURFNjQ3QjIzNzMxMzQwQjNERDE0MTE5NDk0RDFCMzFBM0EyNDU1QjU2NEMyRTUxXHJcbnZhciBnb29nbGVDYWxsYmFja1VybCA9IFwiaHR0cHM6Ly9jdHN0ZXN0LmNvZGUtZ2FyYWdlLXNvbHV0aW9ucy5kZS9hcGkvZ29vZ2xlL2NhbGxiYWNrXCI7IC8vaHR0cHM6Ly9kZXZtaXJhLmlrci1hcHBzLmRlL2FwaS9zYWxlc2ZvcmNlL2NhbGxiYWNrXHJcbnZhciBnb29nbGVMb2dpblVybCA9IFwiaHR0cHM6Ly9hY2NvdW50cy5nb29nbGUuY29tL28vb2F1dGgyL2F1dGhcIjsgLy9odHRwczovL2xvZ2luLnNhbGVzZm9yY2UuY29tXHJcbnZhciBzY29wZUdvb2dsZSA9IFwiZW1haWwgcHJvZmlsZVwiO1xyXG5cclxuXHJcbmRlY2xhcmUgdmFyIFJlc3RpdnVzO1xyXG5cclxudmFyIEFwaSA9IG5ldyBSZXN0aXZ1cyh7XHJcbiAgICB1c2VEZWZhdWx0QXV0aDogdHJ1ZSxcclxuICAgIHByZXR0eUpzb246IGZhbHNlXHJcbn0pO1xyXG4vKlxyXG5BcGkuYWRkUm91dGUoJ2dvb2dsZS9sb2dpbicsIHsgYXV0aFJlcXVpcmVkOiBmYWxzZSB9LCB7XHJcbiAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgc3RhdGUgPSB0aGlzLnF1ZXJ5UGFyYW1zLnN0YXRlO1xyXG5cclxuICAgICAgIHZhciB0ZW1wRGF0YSA9IENoYWxhbmdlcy5maW5kT25lKHsgY2hhbGxhbmdlOiBzdGF0ZSB9KTtcclxuICAgICAgIGlmKHR5cGVvZiB0ZW1wRGF0YSA9PT0gXCJ1bmRlZmluZWRcIil7XHJcbiAgICAgICAgcmV0dXJuIFwiRXJyb3I6IE5vdCB2YWxpZCBQYXJhbWV0ZXJcIlxyXG4gICAgICAgfVxyXG5cclxuICAgICAgICB2YXIgY2ggPSBDaGFsYW5nZXMuZmluZE9uZSh7IGNoYWxsYW5nZTogc3RhdGUgfSkuc3RhdGU7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBjaCA9PT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgICAgICByZXR1cm4gXCJFcnJvcjogTm90IHZhbGlkIFBhcmFtZXRlclwiXHJcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlb2Ygc3RhdGUgPT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICAgICAgcmV0dXJuIFwiRXJyb3I6IE5vdCB2YWxpZCBQYXJhbWV0ZXJcIlxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciB1cmwgPSBnb29nbGVMb2dpblVybCArIFwiXCI7XHJcbiAgICAgICAgICAgIHVybCA9IHVybCArIFwiP3Jlc3BvbnNlX3R5cGU9Y29kZVwiO1xyXG4gICAgICAgICAgICB1cmwgPSB1cmwgKyBcIiZjbGllbnRfaWQ9XCIgKyBnb29nbGVDbGllbnRJZDtcclxuICAgICAgICAgICAgdXJsID0gdXJsICsgXCImcmVkaXJlY3RfdXJpPVwiICsgZ29vZ2xlQ2FsbGJhY2tVcmw7XHJcbiAgICAgICAgICAgIHVybCA9IHVybCArIFwiJmRpc3BsYXk9XCIgKyBcInRvdWNoXCI7XHJcbiAgICAgICAgICAgIHVybCA9IHVybCArIFwiJnNjb3BlPVwiICsgc2NvcGVHb29nbGU7XHJcbiAgICAgICAgICAgIHVybCA9IHVybCArIFwiJnN0YXRlPVwiICsgY2g7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgc3RhdHVzQ29kZTogMzAyLFxyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAndGV4dC9wbGFpbicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0xvY2F0aW9uJzogdXJsXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgYm9keTogJ0xvY2F0aW9uOiAnICsgdXJsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59KTtcclxuXHJcbkFwaS5hZGRSb3V0ZSgnZ29vZ2xlL2NhbGxiYWNrJywgeyBhdXRoUmVxdWlyZWQ6IGZhbHNlIH0sIHtcclxuICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBjb2RlID0gdGhpcy5xdWVyeVBhcmFtcy5jb2RlO1xyXG4gICAgICAgIHZhciBzdGF0ZSA9IHRoaXMucXVlcnlQYXJhbXMuc3RhdGU7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgY29kZSA9PT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgICAgICByZXR1cm4gXCJFcnJvcjogTm90IHZhbGlkIFBhcmFtZXRlclwiXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0eXBlb2Ygc3RhdGUgPT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICAgICAgcmV0dXJuIFwiRXJyb3I6IE5vdCB2YWxpZCBQYXJhbWV0ZXJcIlxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgZnV0ID0gbmV3IEZ1dHVyZSgpO1xyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0ge1xyXG4gICAgICAgICAgICBncmFudF90eXBlOiBcImF1dGhvcml6YXRpb25fY29kZVwiLFxyXG4gICAgICAgICAgICBjbGllbnRfaWQ6IGdvb2dsZUNsaWVudElkLFxyXG4gICAgICAgICAgICBjbGllbnRfc2VjcmV0OiBnb29nbGVTZWNyZXQsXHJcbiAgICAgICAgICAgIHJlZGlyZWN0X3VyaTogZ29vZ2xlQ2FsbGJhY2tVcmwsXHJcbiAgICAgICAgICAgIGNvZGU6IGNvZGVcclxuICAgICAgICB9O1xyXG5cclxuXHJcbiAgICAgICAgbmVlZGxlLnBvc3QoXCJodHRwczovL29hdXRoMi5nb29nbGVhcGlzLmNvbS90b2tlbj9ncmFudF90eXBlPWF1dGhvcml6YXRpb25fY29kZSZjb2RlPVwiICsgY29kZSArIFwiJmNsaWVudF9pZD1cIiArIGdvb2dsZUNsaWVudElkICsgXCImY2xpZW50X3NlY3JldD1cIiArIGdvb2dsZVNlY3JldCArIFwiJnJlZGlyZWN0X3VyaT1cIiArIGdvb2dsZUNhbGxiYWNrVXJsLCBKU09OLnN0cmluZ2lmeShib2R5KSwge1xyXG5cclxuICAgICAgICB9LCBNZXRlb3IuYmluZEVudmlyb25tZW50KGZ1bmN0aW9uIChlcnIsIGRhdGE6IGFueSkgeyBcclxuXHJcbiAgICAgICAgICAgIHZhciBteVRva2VuRGF0YSA9IGRhdGEuYm9keTtcclxuXHJcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coIGRhdGEuYm9keSk7XHJcblxyXG4gICAgICAgICAgICBuZWVkbGUuZ2V0KCdodHRwczovL29wZW5pZGNvbm5lY3QuZ29vZ2xlYXBpcy5jb20vdjEvdXNlcmluZm8nLCB7XHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiBcIkJlYXJlciBcIiArIGRhdGEuYm9keS5hY2Nlc3NfdG9rZW5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgTWV0ZW9yLmJpbmRFbnZpcm9ubWVudCgoZXJyb3IsIHJlc3BvbnNlKSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGVycm9yID09PSBudWxsICYmIHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGRhdCA9IFVzZXJzLmZpbmRPbmUoeyBcInNlcnZpY2VzLmdvb2dsZS5lbWFpbFwiOiByZXNwb25zZS5ib2R5LmVtYWlsIH0gKTtcclxuICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBkYXQgIT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UuYm9keVsndG9rZW4nXSA9IG15VG9rZW5EYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBVc2Vycy51cGRhdGUoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJfaWRcIjogZGF0Ll9pZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCIkc2V0XCI6IHsgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwicGljdHVyZVwiOiByZXNwb25zZS5ib2R5LnBpY3R1cmUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwic2VydmljZXNcIjp7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImdvb2dsZVwiOiByZXNwb25zZS5ib2R5IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHN0YW1wZWRMb2dpblRva2VuID0gQWNjb3VudHNbXCJfZ2VuZXJhdGVTdGFtcGVkTG9naW5Ub2tlblwiXSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBBY2NvdW50c1tcIl9pbnNlcnRMb2dpblRva2VuXCJdKGRhdC5faWQsIHN0YW1wZWRMb2dpblRva2VuKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENoYWxhbmdlcy51cGRhdGUoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJzdGF0ZVwiOiBzdGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCIkc2V0XCI6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9rZW46IHN0YW1wZWRMb2dpblRva2VuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgZnV0LnJldHVybih7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXNDb2RlOiAzMDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICd0ZXh0L2h0bWwnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9keTpgPGRpdj5Mb2dpbiBzdWNjZXNzZnVsPC9kaXY+PHNjcmlwdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5jbG9zZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NjcmlwdD5gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pOyAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENoYWxhbmdlcy51cGRhdGUoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJzdGF0ZVwiOiBzdGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCIkc2V0XCI6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9rZW46IFwiUGVybWlzc2lvbiBEZW5pZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZ1dC5yZXR1cm4oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzQ29kZTogMzAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAndGV4dC9odG1sJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvZHk6YDxkaXY+UGVybWlzc2lvbiBEZW5pZWQ8L2Rpdj48c2NyaXB0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93LmNsb3NlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2NyaXB0PmBcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7ICAgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBmdXQucmV0dXJuKHsgZXJyOiB0cnVlLCBkYXRhOiBudWxsIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHJldHVybiBmdXQud2FpdCgpO1xyXG4gICAgfVxyXG59KTsqLyIsImltcG9ydCAqIGFzIEZ1dHVyZSBmcm9tIFwiZmliZXJzL2Z1dHVyZVwiO1xyXG5pbXBvcnQgKiBhcyBuZWVkbGUgZnJvbSBcIm5lZWRsZVwiO1xyXG5pbXBvcnQgeyBVc2VycywgQ2hhbGFuZ2VzLCBTeW5jZXIgfSBmcm9tIFwiLi4vY29sbGVjdGlvbnNcIjtcclxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcclxuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tIFwibWV0ZW9yL2FjY291bnRzLWJhc2VcIjtcclxuY29uc3Qgand0ID0gcmVxdWlyZShcImpzb253ZWJ0b2tlblwiKTtcclxuaW1wb3J0IHsgZ2V0UGhvdG9Gcm9tSWQgfSBmcm9tIFwiLi4vbGliTW9kdWxlcy9vZmZpY2UzNjVcIjtcclxuY29uc3QgY3JlZGVudGlhbHMgPSB7XHJcbiAgY2xpZW50OiB7XHJcbiAgICBpZDogXCI1OWJjMjI2ZC0wOGI0LTQyMDQtYTY4ZC00ZDRiODhmNWQxYWVcIiwgLy85ZDUyZTk5OC1iMzdkLTRlNjgtOWFjYS0xZjQ5MTMzZWZiZTZcclxuICAgIHNlY3JldDogXCJCc2FFWVhhaHdQdkhjd0Y5cDUxWjNDb3M/TV1mRmQ6PVwiIC8vbU1qLk5jbm8xbHVFQEoxVEZGc2M6S2E2Z1kzZUBWYUdcclxuICB9LFxyXG4gIGF1dGg6IHtcclxuICAgIHRva2VuSG9zdDogXCJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb21cIixcclxuICAgIGF1dGhvcml6ZVBhdGg6IFwiMWY5YTE0OGQtMTgzYy00MDljLThmNmItNzc4YmU0M2I1YTgyL29hdXRoMi92Mi4wL2F1dGhvcml6ZVwiLFxyXG4gICAgdG9rZW5QYXRoOiBcIjFmOWExNDhkLTE4M2MtNDA5Yy04ZjZiLTc3OGJlNDNiNWE4Mi9vYXV0aDIvdjIuMC90b2tlblwiXHJcbiAgfVxyXG59O1xyXG5jb25zdCBvYXV0aDIgPSByZXF1aXJlKFwic2ltcGxlLW9hdXRoMlwiKS5jcmVhdGUoY3JlZGVudGlhbHMpO1xyXG5cclxudmFyIHNjb3BlQmFja2VuZCA9XHJcbiAgXCJvcGVuaWQgb2ZmbGluZV9hY2Nlc3MgZW1haWwgcHJvZmlsZSBHcm91cC5SZWFkLkFsbCBHcm91cE1lbWJlci5SZWFkLkFsbCBVc2VyLlJlYWQuQWxsIENhbGVuZGFycy5SZWFkV3JpdGUuU2hhcmVkIEZpbGVzLlJlYWRXcml0ZSBNYWlsLlNlbmRcIjtcclxuXHJcbmRlY2xhcmUgdmFyIFJlc3RpdnVzO1xyXG5cclxudmFyIEFwaSA9IG5ldyBSZXN0aXZ1cyh7XHJcbiAgdXNlRGVmYXVsdEF1dGg6IHRydWUsXHJcbiAgcHJldHR5SnNvbjogZmFsc2VcclxufSk7XHJcblxyXG5BcGkuYWRkUm91dGUoXHJcbiAgXCJvZmZpY2UzNjUvcHJvZmlsZXBob3RvXCIsXHJcbiAgeyBhdXRoUmVxdWlyZWQ6IGZhbHNlIH0sXHJcbiAge1xyXG4gICAgZ2V0OiBmdW5jdGlvbigpIHtcclxuICAgICAgdmFyIGlkID0gdGhpcy5xdWVyeVBhcmFtcy5pZDtcclxuICAgICAgY29uc3QgZnV0ID0gbmV3IEZ1dHVyZSgpO1xyXG4gICAgICB2YXIgdXNlclBob3RvVXJsID0gVXNlcnMuZmluZE9uZSh7IF9pZDogaWQgfSk7XHJcbiAgICAgIGlmICh0eXBlb2YgdXNlclBob3RvVXJsICE9PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgZ2V0UGhvdG9Gcm9tSWQoaWQpLnRoZW4oKGRhdGE6IGFueSkgPT4ge1xyXG4gICAgICAgICAgLy8gICAgICAgICAgdGhpcy5yZXMuY29udGVudFR5cGUoXCJpbWFnZS9qcGVnXCIpO1xyXG5cclxuICAgICAgICAgIGlmIChkYXRhLmVycm9yID09PSAyMikge1xyXG4gICAgICAgICAgICBjb25zdCBpbWcgPSBCdWZmZXIuZnJvbShcclxuICAgICAgICAgICAgICBgLzlqLzRBQVFTa1pKUmdBQkFRRUFaQUJrQUFELzJ3QkRBQVlFQlFZRkJBWUdCUVlIQndZSUNoQUtDZ2tKQ2hRT0R3d1FGeFFZR0JjVUZoWWFIU1VmR2hzakhCWVdJQ3dnSXlZbktTb3BHUjh0TUMwb01DVW9LU2ovMndCREFRY0hCd29JQ2hNS0NoTW9HaFlhS0Nnb0tDZ29LQ2dvS0Nnb0tDZ29LQ2dvS0Nnb0tDZ29LQ2dvS0Nnb0tDZ29LQ2dvS0Nnb0tDZ29LQ2dvS0Nnb0tDai93Z0FSQ0FFT0FRNERBU0lBQWhFQkF4RUIvOFFBR2dBQkFBTUJBUUVBQUFBQUFBQUFBQUFBQUFNRUJRSUJCdi9FQUJjQkFRRUJBUUFBQUFBQUFBQUFBQUFBQUFBQkFnUC8yZ0FNQXdFQUFoQURFQUFBQWZzeDJ3QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBWE5ETnlwdFJtNXpSUm14YTR3ZVBvS3Vwa3BJOXdBQUFBQUFBQUFCcFFhMktHTkFBQUFjNCsxSFpoT3VldVFBQUFBQUFBQjZiRmc0NkJRQUFBQU15anI1SFRJYWdBQUFBQUFDU1BUaThPV3dEd2VnSGg2ODlBSWNUZnlOWnJqcEFBQUFBQUFKTnFuZjU2OHhOekNUanhZM0s5cS9ZeFF6cXZrNzNObUEwcUhUUGwvTzBwYjlPNDUzNTVKSDJ5QUFBQUFBQkx0WUc1aXkxYlRGcldRQlFBSFBRb1hlaUtsdk5xZ091UUFBQUFBQmFqclU5YzlCS0FBVTRyTkZGTEtBQWprR1JWK2d4dDVnRzRBQUFBQTFzblZ6YmhYNTJ3NDdVUW5XWmJzMlVaYmd5YkY2dVdGV2VPd29DaGZvV1pvNjVBQUFBQVR3RDZDblQxdVdxV2hRdmdTZ0FBQUt0cktzazBZZVNiRTZoM0ExQUFBQUFBRzNpYVdiZkhQUng2ZEVaSXd1TlorZ1oraG1pSlplT3d4dGZCMW53ZElBQUFBQUFPam1mMlNOVlR1Y3RZY2x6dmNzMXJOZkZ4aDJ6UHRZK3h6dFRKM3FSUFo1NXphK1ZvUmRKVVRRNmdBQUFBQ1NUWHphdHYxem9pWEsxOHpXMUF6UUtuTjFaSElTZ01QY3p0VFE5cTJzbkhaYzZoOUJCck9LNjU2UUFCM3hwUmM3T1d3R2JjanNsbEpRQUFBQUhQUXk5U0hpeXlKUUt1UjlEamJ6WEc0Qjd2Wm1yem9aMEJISUFBQUFBQUFDT1FBQUtsdnhQbjNmSGJJOU5hMTU3eDBDZ0FBQUFBQUFBQUFBQVpsSFl4K21mLy9FQUNZUUFBSUJBZ1lCQlFFQkFBQUFBQUFBQUFFQ0F3QVJCQkFTSURCQUlSTVVJakV6STNELzJnQUlBUUVBQVFVQy93QVdFVG12YnRYdDY5dFh0elJnZWlwSGFqaExVcUt2QThLbW5RcDE0SXJjYkFNSlk5QjZtSFRVM0k2NmxJc2VuQ3RvK1hGTDU2UThubXhBdkYwby93Qk9hWDgrbERFTGJMN2I3U0xpWk5CNkNJWEtpeTBYWTFmT09KbXptVFdHVXFjdFJyRE1TMVRvWDZPRXprR2w2U0ptcElsWGFSZW53OU1wVTFoUjR5ay9Ubmpjb1FiaXBZdGRSeEt2Q1FEVFlmeW9zS25rMERveGZuejRyNzZFVU9yb3NvYXBZaW5QQW1wdUI1MUZERVVqcS9ES21odVhEZm51WmdvWjJsSzRldlFXbWlaS2ltdndZb2ZIbHd4L25Va2dTbE9vWkhWWG8zSVVEWThTdFFSa29YM1lvK09XRjlEZmRUclVCc2VTWStNUGU5RTJFamEyNW81U2xHektzVnp5U2VYakZoSklFcVNRdjBZVGVQbElCeW5ONWVqaFQ0eVpndEFnNU9kS3U1WTFCSm42aTN5UGdIeWVqQzJsOHBEZDREYVNzUitXVUg2MWlUYU9zT2J4MWlXc25RQUpvUXZYdDJwSDBtcElReGlpQ1pUaThXVUEvcFRLR0h0L0tpd1pnS2VKM2IwSG94T09WRkxVa0FGZldjdnlsVVdYWTBLc2ZiclNLRUd4L2pKbXlocWVDaUxjTVVlc2dCUm5JMmxjT3VwK1RGTFVEWGoyU1Jod3dLbmNvMU1xNlJzeEIxTkd1aGVRaTRUK1V1MmROUzdzS3ZqWkkybFlvOVBQSW10WVczVHJwZllQSlVhUnMwL0xvTXQ5MklXNmJNTXQzN3JqUzJlSFcwZmR4UytjaDkvWGV4QXZGWC8veEFBYkVRQUNBZ01CQUFBQUFBQUFBQUFBQUFBQkVRQXdFQ0JBVVAvYUFBZ0JBd0VCUHdIeUZGRkZGWU9nOEpwRU9GaFdEd1JVZWthUFEzQ3BaR3h5dUk1SGdHZi94QUFoRVFBQ0FRUUNBZ01BQUFBQUFBQUFBQUFCQWdBUUVTQXdFakVoVUVCQlVmL2FBQWdCQWdFQlB3SDFCYWNqT1JuSXdOc1k1QTIrRXVrNkYwc1lzNmhhZ2EwdUkycHhuZURTVGZEaWNWT2JZZFRrWmUrQzk2T29jaE80b3RvYkRoQ0xWVFRjVXY0Z28wVTBCQXpMVmI4cmVxMURZRTFHZythcWZxckgwQ3oveEFBcEVBQUJBZ1FGQlFBQ0F3QUFBQUFBQUFBQkFCRVFJQ0ZBQWpBeFVXRVNJakpCY1ZDaGNJR1IvOW9BQ0FFQkFBWS9BdjRXMFdvWGwrbDVmcGFyMFZVWFhkUUtneUtVS3JiOVdMWExZcmkxYzZETllwclFad08vNEkyZUg3bjRyTVlqcnJuc3FhV05FQkR5TW13a3FJNmxGeThLZXJIRkVpR3dXNWxxdXhWZ1RIRjlzS0lHSEszT1RWVU5Fd2hUM1pZZmxnTEY4VkJZMVRqVFByb01tbFZYQ3FaUEZyVk1ORjNGZTA0VFl0Y2dITytRM0tmU1BhdytwOFpKVkpORjI0bkhLcUpnTTdpRGltNVRBRnQ4MWdIZFU4WU9VK2Z3dUNueGYxbTl3T0UraXE2KzF5cTJJenF3TmtSR3BWREFsUERwTWZJUmUyTG9ReFJ3ek52WTBDMFhwZEdQWGVEaWlmVXdNUkJpdkpNSU9TRjZYam0wVmF5RkFTdXRTbUV2eVNvWFovaXJrOEpoSVNuMnplcGZKZVV4bllKaEtNR0ZObXNVeDBNM001eFM4K2s1OGpZZE9MeUUzMllDVjdGL2N6N1N2dGZFU2ZiNEdJRitZZi9FQUNrUUFRQUJBd0lHQWdJQ0F3QUFBQUFBQUFFUkFDRXhFRUVnTUVCUllYR0JrYUd4VUhEQjBlSC8yZ0FJQVFFQUFUOGgvcGJFdVBOcU53TmNuYVAxUU1mQTFtNDk5VmRQOGprYklPYS9XNmtvUHowOENEd08zTGhCSTBuZldIK0NFQWFwbVdUcFBORzd6b1BWZEdZRHZhc2M3MUJuby93WFAvRzZPN3g0U0hjcVR2d1E3bFNkK0FtV0cxR2NydWhpbjJyd1FSVGlzdDlsSzNYVlFYMmFyR01KVWNpMExZb0hCZW1oeGdHK2hnNTdLU0dISjBHSHRyN1MwdnNlUnE4eDVIaEFRSktKdW84TlFRdzZROS9iWDhsMEVxdU55dk1oT2hSUmcxZGZrZVNUQUVvRTJxQ2VBMFFBWDNVc3F1ZWhVOUFIYjhkQ2tQOEFZVUVBR0RvRDRNMXVoK3ZQdlhJR0tSaS9TenNlR2hML0FJNUNTUTFNbTY1emhFKzdQSE1IQlVWM3dLM3ZpS1hMUXA3TEc1UTdYdTVIcVRIT21oM2FSaEV1eFViQlhaMWJ3OGxJU0ZvbUNCd1hOZzl5dnJnb2xzUHZpL011ZGtjczBJSk1WZHptMUU1STkzZm11VGl5aXR6WGVPMmhOWUNsWDZjKzFaN2FFQnVGS3lwR0J0emJpWWJsWThUdlN6c3ZaU2V3N2RESS9FYzZOaE1YMDlSdDBYcnJPdUdpalpKUEdrKzdVblQ4VkwzYWRTLzJkY0s1NzFjaXdYcFNMbHYwVU91R3pxeThwaW1FWWM2ZnBmdmhDUUc3R2lETzF0TEZ6MExJejZwUGI3YTh2M3E3SkRSS3lYcWxidEJBbDlXWEN4b3p3TkhxZXFFOEJVQ0xkc0ZmSEpta3U3NXJJTDR2VVJubUx3Zm1ybGVvQVFFR3FzZThWNG9JNFhOeFBiamhLRlp1cWIwTWttb0ZwcmZYeXBFZ2g1S2RvWmFNQkJ3ZURLdnZITllUNmFpamV6aHZLMnhwU0YrTnd6TkVPQTRWdmlLRUJ6U2JBMUx4aHhYWXg0NFViMk9ISFhkaFhlZVRubkU1MmFTSC9rOFVqR0x1RUlCbHRRaWJjSUx0M2J4MElJd0dIaXRiTjNEY0dPdElKRFhoVGdnbmU3cm9DNzIxTTk1UVFBeDEzb0Y5UC8vYUFBd0RBUUFDQUFNQUFBQVErKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrMEVlZWE4KysrKysrKysrKzA4ODg4OE8wKysrKysrKys4MTg4ODg4OGUrKysrKysrKzU4NDg4MDg4LzhBdnZ2dnZ2dnRKL3AzRHNhUGZQdnZ2dnZ2cWZYZlBQUEQrZnZ2dnZ2dnVoZlBPTWRQUExHdnZ2dnZ2dnZmUFB2M3RmUE92dnZ2dnZ2TG5QUFBQUE9kUFB2dnZ2dnZyUE1QRDkrUEwvdnZ2dnZ2dU9meVA5TlUzMVBQdnZ2dm9ML0hQUExYUFBIN08vUHZxZlBPZlBQUFBQUEVmUFBmdnAvUFBQUFBQUFBQTFBQUDlQTi9QUFBQUFBQUFBQUFBQRlAveEFBZUVRRUFBZ0lEQVFFQkFBQUFBQUFBQUFBQkFCRVFJU0F3TVVGUlVQL2FBQWdCQXdFQlB4RCtRSmxKU1VqK2V3ZmVTWDFoekZQU0Z2UVB2U05YZ0N3L1dHMFJJWGNTK2wvSWx3SzRoVVdqb0M0RmNMT0tWczUrb3RaUlpSS1R5RG54ek5TeElYWEpkUTBiaTMwTGZFTjVmU0RCdUEzSHpIbUlyRFJFVmpya1dnQmdmYzBaOFFiTVA0NEJibDNyb05heVB1VHErNUx5R3U4VXovL0VBQjhSQVFBQ0FnTUJBUUVCQUFBQUFBQUFBQUVBRVNFeEVDQXdRVkZoVVAvYUFBZ0JBZ0VCUHhEL0FDQU5SbC9TRVAxZ2prOC9pZG5YODgzT2U3czhXQm53WnJ4UmFsYmltMCtKdzJFRTFBQXdVYklaUEFNTUZHeUtyYjFVNFlSYWZCUUxZaXowRUxxVlcrUi9KYmg3NndGMXlKcGxpbjJWRk1TdWRIZEJLWWk0aGNkamJITEUybmZnYkw0cUJjRit4RlRLdlhBeXZpb1VzUkluQ2JIRzhFS1k1Y1FpcmdqcnRWZzNGWGNNNGkxK09SbjJMZStGVFg3RXByaEREQnZtb3ZuRExIT2U2cGYzbjdPYm12TTVHbTROOExiZnU3Si8vOFFBS2hBQkFBRUNBd1lIQVFFQkFBQUFBQUFBQVJFQUlURkJjUkFnUUZGaGdUQ1JvYkhCMGZEaDhYRC8yZ0FJQVFFQUFUOFEvd0NLZ3FBS3VSVVJDNXZzcDkrbENyN1VPTGcwbDgxK1A5VUFaK3FQdWo1UDRNNHAyT3JpQjc4VWNUdGNJdStxSUFCNXBLOTk4QkFJNGlUVW1qUVdlMzFWZ2djQmNkSGh4RG1qWk9iMTl2RFFpeFExblQvRlBYaFNZSnVRNExrZlBpbjVaTFBKeWFNdUVSNFNMcEE5NS9rVmw0b21saExVdzlQYmcrcTQ4elFBQUlDeDQwb3pJZWNlendmNlhNOGVETHo4R0pWRUFHQXpOeFFKVURtMS9xVU13Q2RkcWdTb0hXdjlTaG1BTHJ1Q2JJSzBhRVpCVUhFakU0R0V0akZZRlh6bU9YT0NKcVU0eGlsNTBJZzhpbDRyVmRwcHVQTEYwUG1nZzU3Qk1zU0RnNjFJczhuSjBkaVZLUjZOZXR3RlM3Q2twaGt6cktsZUVtN01lVDJwRUJFaEVoSGdQUnZuWmxTc2tBbzBibnBzZ3JoMEowTTZOQkF5SmpReTNYNW14RWtxUms5WTdPSlU2K1ZPRG81N0dRTVFOREgzOU52NlhONEJiQ2tTWVAwMFpwQVVIS1NheXFJUWtTbGs1TlFxSThqRFF5ckx3Rkwxa2tsTGpNM0VsTlA3UVlRVUJXVkJxaVlXQkhUblRPRlNxdUt2QXlORVlFUFFqYmJ4Y0xXRXp6bC9ucndKNjFiZ1lqNEtPMEFBT2h3RWJjTUhNMGFrRVpzWXZxKy9IRnltSlJ3WElvSXFONVFLc0JkYVVFamlqQjU1MWhsNWc4Nm5BcmlxeWR2QUpnRVNFYzZpV2NSNmN1M2pHQUx1dmI0MlczVnhjam02R2RZNlRiTzZyK0t0aVo4bnUxSEVtVEo5VUhkS2tzcHFmN1JBcGhHRWRlVFJ2azV4Zk1UOGVNTFowRTZOL3VzcVZsWUNxWkdDOWhIbHRtd1RtUzlndDYwZWxOSDdTdWw2Z3gzRUdVNHJEOU5OUWVRYkJvbUZHYXRBVHM0K214WUwwTTRZYllUdDFZYUVmTDR5a3l3eWNzbnQ5MFpRVVNKZ2xJQ0lGeGdCajhlUm5RU0crbjZJSjFjdkZpT0JnNFEvdjNUbEhBeWJ2SS91ZCtXeCtBVXEwZ2JEWWNqTHgwZWF1M0RSeXAwZUlIUm9LUzRYQURCT1JSNGlXSzJJaTJBL1poVHpnalF6ZjNyTlk4Z2tCbHJnVVJVRGdjRHIxZUJ1MUtTZHJmRzBwM28zRFFSUUJ5U3Nxc3hrZ094ZjFuZ3BITjRHai9ucnRBTDdoTGpYWDRTbllJQ1RJWnl3ZTlJREJiQllEbFgrOVU3cVpuWmNNSDEyTEJlaFlVd1JEYU9IQldoU3JwUldyd1V6bzdRT2ZuRzFkRzdCeUJnS2ExdWc1a0wvQUhaK0RvMitvZloyR0ZRTlJ5aFk5TmwzYXBDNWhoOWR0aGdsMk94ajhjQzlDZklMUnMyT2dmMmlHNWQzMVVRVVlBYkpGaFhPaGtrcHhOOGNRdlBwU0JOU0JTQU9oc0JWVURCalpGOXF6Mkl3dUs1QkRzQU9mUW9jVGVVdTg1b000S0FwY29ja1hWWXBBRE5pU3hrWVZnanBMNUttNUp6aDdLVWtDSmlKRDRsMXVNVllOV28vUjJ3ZHMrOUdCQmdCQnRlQWxZb3ppM3hRbjNpMVFiczdYVXBDRjUxK00rcUdFeE1xNHJ6ZDJUN0FsU3BNajVSUkVraVNPMkdBOVM1bzVWYldhbnMvZEkwQmhFaFBCY3JQK0lPdEVTSEFOa2JBWGlSWTVyaDYwa0d0NlhOeSs2bmVuZHpyQk9qNlB4NVZQVE41cGw2ZTI3Z1FPQ1hOZVpVWklQbjFOODlMa1R5TTJnN2dQUGRFcFNsRE5mbzk2Z09VdXZOemZGR2lTaE9sTlQ4NWttVCs2N3h1ZG1TTVV6TitCVjEyREY4L2JkdUFrd0NWWHBVVlhGSnZFNWE5ZkhhUkJ2eW42cE1pQkNPZVI2NzF2b3RPK0o1N290eWdEcTFoRmtOMENzcEVzQjA2dWJ3SU9jbTRuUjVqeW9tTDdzOEVyNU0vdnR1ekpTTW1yWStlTlpoSWtKU040dERxWlBsdVRNWm5SdzlPT2lWWXkxUDU3YllZWW1FOHBhSVJBQURqaVE0c0huSHN1ei8vMlE9PWAsXHJcbiAgICAgICAgICAgICAgXCJiYXNlNjRcIlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBmdXQucmV0dXJuKHtcclxuICAgICAgICAgICAgICBzdGF0dXNDb2RlOiAyMDAsXHJcbiAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogZGF0YS5jb250ZW50VHlwZVxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgYm9keTogaW1nXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY29uc3QgaW1nID0gQnVmZmVyLmZyb20oZGF0YS5kYXRhLCBcImJhc2U2NFwiKTtcclxuICAgICAgICAgICAgZnV0LnJldHVybih7XHJcbiAgICAgICAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxyXG4gICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IGRhdGEuY29udGVudFR5cGVcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIGJvZHk6IGltZ1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBmdXQucmV0dXJuKHsgZXJyOiBcIlBlcm1pc3Npb24gZGVuaWVkXCIgfSk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIGZ1dC53YWl0KCk7XHJcbiAgICB9XHJcbiAgfVxyXG4pO1xyXG5cclxuQXBpLmFkZFJvdXRlKFxyXG4gIFwib2ZmaWNlMzY1L2JhY2tsb2dpblwiLFxyXG4gIHsgYXV0aFJlcXVpcmVkOiBmYWxzZSB9LFxyXG4gIHtcclxuICAgIGdldDogZnVuY3Rpb24oKSB7XHJcbiAgICAgIHZhciBzdGF0ZSA9IHRoaXMucXVlcnlQYXJhbXMuc3RhdGU7XHJcblxyXG4gICAgICBpZiAoc3RhdGUgPT09IFwiYmFja2xvZ2luXCIpIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgc3RhdHVzQ29kZTogMzAyLFxyXG4gICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcInRleHQvcGxhaW5cIixcclxuICAgICAgICAgICAgTG9jYXRpb246IGdldEF1dGhVcmxCYWNrKHN0YXRlKVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGJvZHk6IFwiTG9jYXRpb246IFwiICsgZ2V0QXV0aFVybEJhY2soc3RhdGUpXHJcbiAgICAgICAgfTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gXCJFcnJvcjogTm90IHZhbGlkIFBhcmFtZXRlclwiO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4pO1xyXG5cclxuQXBpLmFkZFJvdXRlKFxyXG4gIFwib2ZmaWNlMzY1L2xvZ2luXCIsXHJcbiAgeyBhdXRoUmVxdWlyZWQ6IGZhbHNlIH0sXHJcbiAge1xyXG4gICAgZ2V0OiBmdW5jdGlvbigpIHtcclxuICAgICAgdmFyIHN0YXRlID0gdGhpcy5xdWVyeVBhcmFtcy5zdGF0ZTtcclxuICAgICAgdmFyIHRlbXBEYXRhID0gQ2hhbGFuZ2VzLmZpbmRPbmUoeyBjaGFsbGFuZ2U6IHN0YXRlIH0pO1xyXG4gICAgICBpZiAodHlwZW9mIHRlbXBEYXRhID09PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgcmV0dXJuIFwiRXJyb3I6IE5vdCB2YWxpZCBQYXJhbWV0ZXJcIjtcclxuICAgICAgfVxyXG5cclxuICAgICAgdmFyIGNoID0gQ2hhbGFuZ2VzLmZpbmRPbmUoeyBjaGFsbGFuZ2U6IHN0YXRlIH0pLnN0YXRlO1xyXG4gICAgICBpZiAodHlwZW9mIGNoID09PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgcmV0dXJuIFwiRXJyb3I6IE5vdCB2YWxpZCBQYXJhbWV0ZXJcIjtcclxuICAgICAgfSBlbHNlIGlmICh0eXBlb2Ygc3RhdGUgPT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICByZXR1cm4gXCJFcnJvcjogTm90IHZhbGlkIFBhcmFtZXRlclwiO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBzdGF0dXNDb2RlOiAzMDIsXHJcbiAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwidGV4dC9wbGFpblwiLFxyXG4gICAgICAgICAgICBMb2NhdGlvbjogZ2V0QXV0aFVybChjaClcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBib2R5OiBcIkxvY2F0aW9uOiBcIiArIGdldEF1dGhVcmwoY2gpXHJcbiAgICAgICAgfTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuKTtcclxuXHJcbkFwaS5hZGRSb3V0ZShcclxuICBcImNiXCIsXHJcbiAgeyBhdXRoUmVxdWlyZWQ6IGZhbHNlIH0sXHJcbiAge1xyXG4gICAgZ2V0OiBmdW5jdGlvbigpIHtcclxuICAgICAgY29uc3QgZnV0ID0gbmV3IEZ1dHVyZSgpO1xyXG5cclxuICAgICAgdmFyIGNvZGUgPSB0aGlzLnF1ZXJ5UGFyYW1zLmNvZGU7XHJcbiAgICAgIHZhciBzdGF0ZSA9IHRoaXMucXVlcnlQYXJhbXMuc3RhdGU7XHJcbiAgICAgIGlmICh0eXBlb2YgY29kZSA9PT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgIHJldHVybiBcIkVycm9yOiBOb3QgdmFsaWQgUGFyYW1ldGVyXCI7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKHR5cGVvZiBzdGF0ZSA9PT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgIHJldHVybiBcIkVycm9yOiBOb3QgdmFsaWQgUGFyYW1ldGVyXCI7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChzdGF0ZSA9PT0gXCJiYWNrbG9naW5cIikge1xyXG4gICAgICAgIGdldFRva2VuRnJvbUNvZGVCYWNrbG9naW4oY29kZSkudGhlbih0b2tlbiA9PiB7XHJcbiAgICAgICAgICBmdXQucmV0dXJuKHtcclxuICAgICAgICAgICAgc3RhdHVzQ29kZTogMzAyLFxyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJ0ZXh0L2h0bWxcIlxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBib2R5OiBgPGRpdj5Mb2dpbiBzdWNjZXNzZnVsPC9kaXY+PHNjcmlwdD5cclxuICAgICAgICAgICAgd2luZG93LmNsb3NlKCk7XHJcbiAgICAgICAgPC9zY3JpcHQ+YFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZ2V0VG9rZW5Gcm9tQ29kZShjb2RlKS50aGVuKHRva2VuID0+IHtcclxuICAgICAgICAgIENoYWxhbmdlcy51cGRhdGUoXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBzdGF0ZTogc3RhdGVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgICAgICAgIHRva2VuOiB0b2tlblxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgICAgICAudG9Qcm9taXNlKClcclxuICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgICAgIGZ1dC5yZXR1cm4oe1xyXG4gICAgICAgICAgICAgICAgc3RhdHVzQ29kZTogMzAyLFxyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcInRleHQvaHRtbFwiXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgYm9keTogYDxkaXY+TG9naW4gc3VjY2Vzc2Z1bDwvZGl2PjxzY3JpcHQ+XHJcbiAgICAgICAgICAgIHdpbmRvdy5jbG9zZSgpO1xyXG4gICAgICAgIDwvc2NyaXB0PmBcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiBmdXQud2FpdCgpO1xyXG4gICAgfVxyXG4gIH1cclxuKTtcclxuZnVuY3Rpb24gZ2V0QXV0aFVybChzdGF0ZSkge1xyXG4gIGNvbnN0IHJldHVyblZhbCA9IG9hdXRoMi5hdXRob3JpemF0aW9uQ29kZS5hdXRob3JpemVVUkwoe1xyXG4gICAgcmVkaXJlY3RfdXJpOiBwcm9jZXNzLmVudi5ST09UX1VSTCArIFwiL2FwaS9jYlwiLFxyXG4gICAgc2NvcGU6IFwib3BlbmlkIG9mZmxpbmVfYWNjZXNzIHByb2ZpbGUgVXNlci5SZWFkXCIsXHJcbiAgICBzdGF0ZTogc3RhdGVcclxuICB9KTtcclxuICByZXR1cm4gcmV0dXJuVmFsO1xyXG59XHJcbmZ1bmN0aW9uIGdldEF1dGhVcmxCYWNrKHN0YXRlKSB7XHJcbiAgY29uc3QgcmV0dXJuVmFsID0gb2F1dGgyLmF1dGhvcml6YXRpb25Db2RlLmF1dGhvcml6ZVVSTCh7XHJcbiAgICByZWRpcmVjdF91cmk6IHByb2Nlc3MuZW52LlJPT1RfVVJMICsgXCIvYXBpL2NiXCIsXHJcbiAgICBzY29wZTogc2NvcGVCYWNrZW5kLFxyXG4gICAgc3RhdGU6IHN0YXRlXHJcbiAgfSk7XHJcbiAgcmV0dXJuIHJldHVyblZhbDtcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0VG9rZW5Gcm9tQ29kZShhdXRoX2NvZGUpIHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlcywgcmVqKSA9PiB7XHJcbiAgICBvYXV0aDIuYXV0aG9yaXphdGlvbkNvZGVcclxuICAgICAgLmdldFRva2VuKHtcclxuICAgICAgICBjb2RlOiBhdXRoX2NvZGUsXHJcbiAgICAgICAgcmVkaXJlY3RfdXJpOiBwcm9jZXNzLmVudi5ST09UX1VSTCArIFwiL2FwaS9jYlwiLFxyXG4gICAgICAgIHNjb3BlOiBcIm9wZW5pZCBwcm9maWxlIFVzZXIuUmVhZFwiXHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKHJlc3VsdCA9PiB7XHJcbiAgICAgICAgY29uc3QgdG9rZW4gPSBvYXV0aDIuYWNjZXNzVG9rZW4uY3JlYXRlKHJlc3VsdCk7XHJcbiAgICAgICAgY29uc3QgdXNlciA9IGp3dC5kZWNvZGUodG9rZW4udG9rZW4uaWRfdG9rZW4pO1xyXG5cclxuICAgICAgICB2YXIgdGcgPSBuZXcgUmVnRXhwKFxyXG4gICAgICAgICAgXCIuKlwiICsgdXNlci5wcmVmZXJyZWRfdXNlcm5hbWUudG9Mb3dlckNhc2UoKSArIFwiKi5cIixcclxuICAgICAgICAgIFwiaVwiXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgdmFyIGRhdCA9IFVzZXJzLmZpbmRPbmUoe1xyXG4gICAgICAgICAgbWFpbDogdGdcclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAodHlwZW9mIGRhdCAhPT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgICAgLy9odHRwczovL291dGxvb2sub2ZmaWNlLmNvbS9hcGkvdjIuMC9tZS9waG90b1xyXG5cclxuICAgICAgICAgIHZhciBvcHRpb25zID0ge1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7IGF1dGhvcml6YXRpb246IFwiYmVhcmVyIFwiICsgdG9rZW4udG9rZW4uYWNjZXNzX3Rva2VuIH1cclxuICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgbmVlZGxlLmdldChcclxuICAgICAgICAgICAgXCJodHRwczovL2dyYXBoLm1pY3Jvc29mdC5jb20vdjEuMC9tZS9waG90b3MvMTIweDEyMC8kdmFsdWVcIixcclxuICAgICAgICAgICAgb3B0aW9ucyxcclxuICAgICAgICAgICAgTWV0ZW9yLmJpbmRFbnZpcm9ubWVudCgoZXJyLCByZXNwKSA9PiB7XHJcbiAgICAgICAgICAgICAgZGF0LnBob3RvID1cclxuICAgICAgICAgICAgICAgIFwiZGF0YTpcIiArXHJcbiAgICAgICAgICAgICAgICByZXNwLmhlYWRlcnNbXCJjb250ZW50LXR5cGVcIl0gK1xyXG4gICAgICAgICAgICAgICAgXCI7YmFzZTY0LFwiICtcclxuICAgICAgICAgICAgICAgIHJlc3AuYm9keS50b1N0cmluZyhcImJhc2U2NFwiKTtcclxuXHJcbiAgICAgICAgICAgICAgZm9yICh2YXIgaiBpbiB1c2VyKSB7XHJcbiAgICAgICAgICAgICAgICBkYXRbal0gPSB1c2VyW2pdO1xyXG4gICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgVXNlcnMudXBkYXRlKFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICBfaWQ6IGRhdC5faWRcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICRzZXQ6IGRhdFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgIHZhciBzdGFtcGVkTG9naW5Ub2tlbiA9IEFjY291bnRzW1wiX2dlbmVyYXRlU3RhbXBlZExvZ2luVG9rZW5cIl0oKTtcclxuICAgICAgICAgICAgICBBY2NvdW50c1tcIl9pbnNlcnRMb2dpblRva2VuXCJdKGRhdC5faWQsIHN0YW1wZWRMb2dpblRva2VuKTtcclxuICAgICAgICAgICAgICByZXMoc3RhbXBlZExvZ2luVG9rZW4pO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcmVzKG51bGwpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgfSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldFRva2VuRnJvbUNvZGVCYWNrbG9naW4oYXV0aF9jb2RlKSB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXMsIHJlaikgPT4ge1xyXG4gICAgb2F1dGgyLmF1dGhvcml6YXRpb25Db2RlXHJcbiAgICAgIC5nZXRUb2tlbih7XHJcbiAgICAgICAgY29kZTogYXV0aF9jb2RlLFxyXG4gICAgICAgIHJlZGlyZWN0X3VyaTogcHJvY2Vzcy5lbnYuUk9PVF9VUkwgKyBcIi9hcGkvY2JcIixcclxuICAgICAgICBzY29wZTogc2NvcGVCYWNrZW5kXHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKHJlc3VsdCA9PiB7XHJcbiAgICAgICAgY29uc3QgdG9rZW4gPSBvYXV0aDIuYWNjZXNzVG9rZW4uY3JlYXRlKHJlc3VsdCk7XHJcbiAgICAgICAgY29uc3QgdXNlciA9IGp3dC5kZWNvZGUodG9rZW4udG9rZW4uaWRfdG9rZW4pO1xyXG4gICAgICAgIFN5bmNlci5yZW1vdmUoe30pXHJcbiAgICAgICAgICAudG9Qcm9taXNlKClcclxuICAgICAgICAgIC50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgU3luY2VyLmluc2VydCh0b2tlbi50b2tlbik7XHJcbiAgICAgICAgICAgIHJlcyhudWxsKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEBhcGkge2dldH0gL3VzZXIgUmVxdWVzdCBVc2VyXHJcbiAqIEBhcGlIZWFkZXIge1N0cmluZ30gYXV0aG9yaXphdGlvbiBVc2VycyB1bmlxdWUgYWNjZXNzLWtleS4gYXBpdG9rZW4gbXlBcGlUb2tlblxyXG4gKiBAYXBpTmFtZSBHZXRVc2VyXHJcbiAqIEBhcGlHcm91cCBVc2VyXHJcbiAqICBAYXBpRXhhbXBsZVxyXG4gKiAgI0V4YW1wbGUgUHl0aG9uIENhbGxcclxuICogIGltcG9ydCBodHRwLmNsaWVudFxyXG4gY29ubmVjdGlvbiA9IGh0dHAuY2xpZW50LkhUVFBTQ29ubmVjdGlvbigncHJldHJhZGVjaGVjay5jb2RlLWdhcmFnZS1zb2x1dGlvbnMuZGUnKVxyXG4gaGVhZGVycz17J2F1dGhvcml6YXRpb24nOiAnYXBpdG9rZW4gbXlBcGlUb2tlbicsJ2NvbnRlbnQtVHlwZSc6J2FwcGxpY2F0aW9uL2pzb24nfVxyXG4gY29ubmVjdGlvbi5yZXF1ZXN0KFwiR0VUXCIsIFwiL2FwaS91c2VyXCIse30saGVhZGVycylcclxuIHJlc3BvbnNlID0gY29ubmVjdGlvbi5nZXRyZXNwb25zZSgpXHJcbiBwcmludChyZXNwb25zZS5yZWFkKCkpXHJcbiBjb25uZWN0aW9uLmNsb3NlKCkgICBcclxuICovXHJcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XG5pbXBvcnQgeyBFdmVudHMsIFRlYW1zIH0gZnJvbSBcIi4vY29sbGVjdGlvbnMvaW5kZXhcIjtcbmltcG9ydCB7XG4gIHVwbG9hZERhdGFUb1NwcmVhZHNoZWV0T25lRHJpdmUsXG4gIGNyZWF0ZURhdGFUb1NwcmVhZHNoZWV0T25lRHJpdmVcbn0gZnJvbSBcIi4vbGliTW9kdWxlcy9vZmZpY2UzNjVcIjtcbnZhciBtb21lbnQgPSByZXF1aXJlKFwibW9tZW50XCIpO1xudmFyIHRpbWVvdXRlckluc2VydFNoZWV0O1xudmFyIGZpcnN0UnVuID0gdHJ1ZTtcbk1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgRXZlbnRzLmZpbmQoe30pLm9ic2VydmVDaGFuZ2VzKHtcbiAgICBjaGFuZ2VkOiBNZXRlb3IuYmluZEVudmlyb25tZW50KGZ1bmN0aW9uKGlkLCBmaWVsZHMpIHtcbiAgICAgIC8vY3JlYXRlTmV3RXZlbnRUb1NoZWV0KGlkKTtcbiAgICB9KSxcbiAgICBhZGRlZDogTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChmdW5jdGlvbihpZCwgZmllbGRzKSB7XG4gICAgICBpZiAodHlwZW9mIHRpbWVvdXRlclVwZGF0ZVNoZWV0ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0ZXJVcGRhdGVTaGVldCk7XG4gICAgICB9XG4gICAgICB0aW1lb3V0ZXJVcGRhdGVTaGVldCA9IHNldFRpbWVvdXQoXG4gICAgICAgIE1ldGVvci5iaW5kRW52aXJvbm1lbnQoKCkgPT4ge1xuICAgICAgICAgIGlmIChmaXJzdFJ1biA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgZmlyc3RSdW4gPSBmYWxzZTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY3JlYXRlTmV3RXZlbnRUb1NoZWV0KGlkKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pLFxuICAgICAgICAyMDAwXG4gICAgICApO1xuICAgIH0pLFxuICAgIHJlbW92ZWQ6IE1ldGVvci5iaW5kRW52aXJvbm1lbnQoZnVuY3Rpb24oaWQsIGZpZWxkcykge1xuICAgICAgLy8gY2FsY1RhYmxlRGF0YUZvckV2ZW50cygpO1xuICAgIH0pXG4gIH0pO1xufSk7XG5cbmZ1bmN0aW9uIGNyZWF0ZU5ld0V2ZW50VG9TaGVldChpZCkge1xuICB2YXIgZXYgPSBFdmVudHMuZmluZE9uZSh7IF9pZDogaWQgfSk7XG4gIHZhciBhcnIgPSBbXG4gICAgbW9tZW50KCkuZm9ybWF0KFwiREQuTU0uWVlZWVwiKSxcbiAgICBldi5zdWJqZWN0LFxuICAgIGV2LnVzZXIuZGlzcGxheU5hbWUsXG4gICAgXCJcIixcbiAgICBtb21lbnQoKS5mb3JtYXQoXCJNTU0uWVlZWVwiKSxcbiAgICBldi5faWRcbiAgXTtcblxuICB2YXIgVGVhbURhdGE6IGFueSA9IFRlYW1zLmZpbmQoKS5jdXJzb3IuZmV0Y2goKTtcbiAgZm9yICh2YXIgdCA9IDA7IHQgPCBUZWFtRGF0YS5sZW5ndGg7IHQrKykge1xuICAgIGZvciAodmFyIHUgPSAwOyB1IDwgVGVhbURhdGFbdF0udXNlckxpc3QubGVuZ3RoOyB1KyspIHtcbiAgICAgIGlmIChUZWFtRGF0YVt0XS51c2VyTGlzdFt1XS5pZCA9PT0gZXYudXNlci5pZCkge1xuICAgICAgICBhcnJbM10gPSBUZWFtRGF0YVt0XS5kaXNwbGF5TmFtZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjcmVhdGVEYXRhVG9TcHJlYWRzaGVldE9uZURyaXZlKFxuICAgIFwiMDFSTkpHQkVSWk5GQTZER1pXTTVETDdVS0ZINjJUV0lHRFwiLFxuICAgIFwiZGF0YVwiLFxuICAgIGFycixcbiAgICA2LFxuICAgIGFyci5sZW5ndGhcbiAgKS50aGVuKGRhdGEgPT4ge1xuICAgIGNvbnNvbGUubG9nKGRhdGEpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIHVwZGF0ZUV2ZW50VG9TaGVldChpZCkge1xuICB2YXIgZXYgPSBFdmVudHMuZmluZE9uZSh7IF9pZDogaWQgfSk7XG4gIHZhciBhcnIgPSBbXG4gICAgbW9tZW50KCkuZm9ybWF0KFwiREQuTU0uWVlZWVwiKSxcbiAgICBldi5zdWJqZWN0LFxuICAgIGV2LnVzZXIuZGlzcGxheU5hbWUsXG4gICAgXCJcIixcbiAgICBtb21lbnQoKS5mb3JtYXQoXCJNTU0uWVlZWVwiKSxcbiAgICBldi5faWRcbiAgXTtcblxuICB2YXIgVGVhbURhdGE6IGFueSA9IFRlYW1zLmZpbmQoKS5jdXJzb3IuZmV0Y2goKTtcbiAgZm9yICh2YXIgdCA9IDA7IHQgPCBUZWFtRGF0YS5sZW5ndGg7IHQrKykge1xuICAgIGZvciAodmFyIHUgPSAwOyB1IDwgVGVhbURhdGFbdF0udXNlckxpc3QubGVuZ3RoOyB1KyspIHtcbiAgICAgIGlmIChUZWFtRGF0YVt0XS51c2VyTGlzdFt1XS5pZCA9PT0gZXYudXNlci5pZCkge1xuICAgICAgICBhcnJbM10gPSBUZWFtRGF0YVt0XS5kaXNwbGF5TmFtZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxudmFyIHRpbWVvdXRlclVwZGF0ZVNoZWV0O1xuXG5mdW5jdGlvbiBjYWxjVGFibGVEYXRhRm9yRXZlbnRzKCkge1xuICBpZiAodHlwZW9mIHRpbWVvdXRlclVwZGF0ZVNoZWV0ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRlclVwZGF0ZVNoZWV0KTtcbiAgfVxuICB0aW1lb3V0ZXJVcGRhdGVTaGVldCA9IHNldFRpbWVvdXQoXG4gICAgTWV0ZW9yLmJpbmRFbnZpcm9ubWVudCgoKSA9PiB7XG4gICAgICB2YXIgZGF0YUxpc3QgPSBbW1wiZGF0dW1cIiwgXCJvcnRcIiwgXCJtaXRhcmJlaXRlck5hbWVcIiwgXCJhYnRlaWx1bmdcIl1dO1xuICAgICAgdmFyIFRlYW1EYXRhOiBhbnkgPSBUZWFtcy5maW5kKCkuY3Vyc29yLmZldGNoKCk7XG4gICAgICB2YXIgc3RhcnREYXRlID0gbW9tZW50KClcbiAgICAgICAgLnN0YXJ0T2YoXCJkYXlcIilcbiAgICAgICAgLnRvRGF0ZSgpO1xuICAgICAgdmFyIGVuZERhdGUgPSBtb21lbnQoKVxuICAgICAgICAuYWRkKDYsIFwibW9udGhcIilcbiAgICAgICAgLnRvRGF0ZSgpO1xuXG4gICAgICB2YXIgZXZlbnREYXRhID0gRXZlbnRzLmZpbmQoe1xuICAgICAgICAkYW5kOiBbXG4gICAgICAgICAgeyBzdGFydDogeyAkZ3Q6IHN0YXJ0RGF0ZS50b0lTT1N0cmluZygpIH0gfSxcbiAgICAgICAgICB7IHN0YXJ0OiB7ICRsdDogZW5kRGF0ZS50b0lTT1N0cmluZygpIH0gfVxuICAgICAgICBdXG4gICAgICB9KS5jdXJzb3IuZmV0Y2goKTtcbiAgICAgIGNvbnNvbGUubG9nKGV2ZW50RGF0YSk7XG5cbiAgICAgIHZhciBwcm9tID0gW107XG4gICAgICB3aGlsZSAoc3RhcnREYXRlIDwgZW5kRGF0ZSkge1xuICAgICAgICBmb3IgKHZhciB0ID0gMDsgdCA8IFRlYW1EYXRhLmxlbmd0aDsgdCsrKSB7XG4gICAgICAgICAgZm9yICh2YXIgdSA9IDA7IHUgPCBUZWFtRGF0YVt0XS51c2VyTGlzdC5sZW5ndGg7IHUrKykge1xuICAgICAgICAgICAgcHJvbS5wdXNoKFxuICAgICAgICAgICAgICBzZWFyY2hFdmVudEluTGlzdChcbiAgICAgICAgICAgICAgICBldmVudERhdGEsXG4gICAgICAgICAgICAgICAgVGVhbURhdGFbdF0udXNlckxpc3RbdV0sXG4gICAgICAgICAgICAgICAgbW9tZW50KHN0YXJ0RGF0ZSkuZm9ybWF0KFwiREQuTU0uWVlZWVwiKSxcbiAgICAgICAgICAgICAgICBUZWFtRGF0YVt0XS5kaXNwbGF5TmFtZVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBzdGFydERhdGUgPSBtb21lbnQoc3RhcnREYXRlKVxuICAgICAgICAgIC5hZGQoMSwgXCJkYXlcIilcbiAgICAgICAgICAudG9EYXRlKCk7XG4gICAgICB9XG4gICAgICBjb25zb2xlLmxvZyhwcm9tLmxlbmd0aCk7XG4gICAgICBQcm9taXNlLmFsbChwcm9tKS50aGVuKGRhdGEgPT4ge1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBpZiAoZGF0YVtpXS5vcnQgIT09IFwiS2VpbmUgRGF0ZW4gVm9yaGFuZGVuXCIpIHtcbiAgICAgICAgICAgIHZhciB1byA9IFtdO1xuICAgICAgICAgICAgZm9yICh2YXIgeiBpbiBkYXRhW2ldKSB7XG4gICAgICAgICAgICAgIHVvLnB1c2goZGF0YVtpXVt6XSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBkYXRhTGlzdC5wdXNoKHVvKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdXBsb2FkRGF0YVRvU3ByZWFkc2hlZXRPbmVEcml2ZShcbiAgICAgICAgICBcIjAxUk5KR0JFUlpORkE2REdaV001REw3VUtGSDYyVFdJR0RcIixcbiAgICAgICAgICBcImRhdGFcIixcbiAgICAgICAgICBkYXRhTGlzdCxcbiAgICAgICAgICBkYXRhTGlzdC5sZW5ndGgsXG4gICAgICAgICAgNFxuICAgICAgICApLnRoZW4oZGF0YSA9PiB7XG4gICAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSksXG4gICAgMjAwMFxuICApO1xufVxuXG5mdW5jdGlvbiBzZWFyY2hFdmVudEluTGlzdChldmVudHMsIHVzZXIsIGRhdGUsIGFidGVpbHVuZykge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlcywgcmVqKSA9PiB7XG4gICAgdmFyIG9iaiA9IHtcbiAgICAgIGRhdHVtOiBkYXRlLFxuICAgICAgb3J0OiBcIktlaW5lIERhdGVuIFZvcmhhbmRlblwiLFxuICAgICAgbWl0YXJiZWl0ZXJOYW1lOiB1c2VyLmRpc3BsYXlOYW1lLFxuICAgICAgYWJ0ZWlsdW5nOiBhYnRlaWx1bmdcbiAgICB9O1xuICAgIGZvciAodmFyIG8gPSAwOyBvIDwgZXZlbnRzLmxlbmd0aDsgbysrKSB7XG4gICAgICBpZiAoXG4gICAgICAgIGV2ZW50c1tvXS51c2VyLmlkID09PSB1c2VyLmlkICYmXG4gICAgICAgIG1vbWVudChkYXRlKS5pc1NhbWUobmV3IERhdGUoZXZlbnRzW29dLnN0YXJ0KSwgXCJkYXlcIikgPT09IHRydWVcbiAgICAgICkge1xuICAgICAgICBvYmoub3J0ID0gZXZlbnRzW29dLnN1YmplY3Q7XG4gICAgICB9XG4gICAgfVxuICAgIHJlcyhvYmopO1xuICB9KTtcbn1cbiJdfQ==
